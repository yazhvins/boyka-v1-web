import { expect, test } from '@playwright/test';

test.setTimeout(120_000);

test('a CPU calculation is checked, saved, and can be reopened after a page reload', async ({ page }) => {
  await page.goto('/workspace?tab=workspace');
  await expect(page.getByRole('heading', { name: 'B. Verified Compute Workspace' })).toBeVisible();
  // Cold Windows hosts can spend several seconds importing the reference engine.
  // Keep this UI workflow test from turning host startup time into a false deadline failure.
  await page.getByRole('spinbutton', { name: 'Latency Budget (ms)' }).fill('60000');

  const submission = page.waitForResponse(response =>
    response.request().method() === 'POST' && new URL(response.url()).pathname === '/api/compute/jobs',
  );
  await page.getByRole('button', { name: 'Execute & Verify' }).click();
  const submittedResponse = await submission;
  const submittedBody = await submittedResponse.json() as { run_id?: string };
  expect(submittedResponse.ok(), JSON.stringify(submittedBody)).toBeTruthy();
  expect(submittedResponse.request().postDataJSON()).toMatchObject({
    operation: 'vector_dot',
    payload: { left: [1, 2, 3], right: [4, 5, 6] },
    allowed_backends: ['cpu'],
  });
  const { run_id: runId } = submittedBody;
  if (typeof runId !== 'string' || runId.length === 0) throw new Error('Accepted execution did not return a run ID.');

  let persistedBody: {
    status?: string;
    receipt_sha256?: string;
    response?: { output?: { value?: number }; verification?: { verifier_id?: string } };
  } | undefined;
  const receiptDeadline = Date.now() + 90_000;
  while (Date.now() < receiptDeadline) {
    const persistedResponse = await page.request.get(`/api/compute/runs/${runId}`);
    expect(persistedResponse.ok()).toBeTruthy();
    const currentReceipt = await persistedResponse.json() as NonNullable<typeof persistedBody>;
    persistedBody = currentReceipt;
    if (currentReceipt.status === 'SUCCEEDED') break;
    expect(['RUNNING', 'QUEUED', 'SUBMITTING']).toContain(currentReceipt.status);
    await page.waitForTimeout(250);
  }
  expect(persistedBody).toBeDefined();
  const receipt = persistedBody!;
  expect(receipt.status).toBe('SUCCEEDED');
  expect(receipt.response?.output?.value).toBe(32);
  expect(receipt.response?.verification?.verifier_id).toBe('independent.python.exact');
  const receiptHash = receipt.receipt_sha256;
  if (typeof receiptHash !== 'string' || !/^[a-f0-9]{64}$/.test(receiptHash)) {
    throw new Error('Successful run did not return a valid SHA-256 receipt hash.');
  }
  console.info(`V1_POSTGRES_RECEIPT run_id=${runId} receipt_sha256=${receiptHash}`);

  await expect(page.getByRole('heading', { name: 'Completed & Verified' })).toBeVisible({ timeout: 90_000 });
  await expect(page.getByText('32', { exact: true })).toBeVisible();
  await expect(page.getByText('Actual backend:')).toContainText(/cpu/i);
  await expect(page.getByText(/Verified by independent oracle:/)).toBeVisible();
  await expect(page.getByText('Run and receipt hash were retrieved from the PostgreSQL execution store.')).toBeVisible();

  const runRow = page.getByRole('row').filter({ hasText: runId });
  await expect(runRow).toContainText('Vector dot product (float64)');
  await runRow.getByRole('button', { name: 'Inspect' }).click();
  await expect(page.getByRole('heading', { name: 'Execution Run Details & Evidence' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Verification Evidence' })).toBeVisible();

  await expect(page.getByText('independent.python.exact', { exact: true })).toBeVisible();
  await expect(page.getByText('Receipt SHA-256:')).toBeVisible();
  await expect(page.getByText('0.47 ms')).toHaveCount(0);
  await expect(page.getByText('7c2e...89a1')).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Download Retrieved Record' })).toBeVisible();

  // Rebuild the UI from the service history instead of relying on in-memory run state.
  // This verifies browser reload recovery; it does not simulate an API process restart.
  await page.goto('/workspace?tab=workspace');
  const reloadedRunRow = page.getByRole('row').filter({ hasText: runId });
  await expect(reloadedRunRow).toContainText('Completed & Verified');
  await reloadedRunRow.getByRole('button', { name: 'Inspect' }).click();
  await expect(page.getByRole('heading', { name: 'Execution Run Details & Evidence' })).toBeVisible();
  await expect(page.getByText(runId, { exact: true })).toBeVisible();
  await expect(page.getByText(receiptHash, { exact: true })).toBeVisible();
});

test('an unavailable execution API does not synthesize a run or output', async ({ page }) => {
  await page.route('**/api/compute/jobs', route => route.fulfill({
    status: 503,
    contentType: 'application/json',
    body: JSON.stringify({ error: { code: 'COMPUTE_BACKEND_UNAVAILABLE', message: 'The BOYKA execution API could not be reached.' } }),
  }));
  await page.goto('/workspace?tab=workspace');
  await expect(page.getByRole('heading', { name: 'B. Verified Compute Workspace' })).toBeVisible();
  await page.getByRole('spinbutton', { name: 'Latency Budget (ms)' }).fill('60000');
  await page.getByRole('button', { name: 'Execute & Verify' }).click();
  await expect(page.getByText('The BOYKA execution API could not be reached.')).toBeVisible();
  await expect(page.getByText('Execution Result & Provenance')).toHaveCount(0);
});

test('unavailable history is not presented as an empty execution history', async ({ page }) => {
  await page.route('**/api/compute/history**', route => route.fulfill({
    status: 503,
    contentType: 'application/json',
    body: JSON.stringify({ error: { code: 'HISTORY_UNAVAILABLE', message: 'Execution history could not be retrieved.' } }),
  }));
  await page.goto('/workspace?tab=workspace');
  await expect(page.getByRole('heading', { name: 'B. Verified Compute Workspace' })).toBeVisible();
  await expect(page.getByText('Execution history could not be retrieved.', { exact: true })).toBeVisible();
  await expect(page.getByText('Saved executions could not be checked. Refresh history to retry.')).toBeVisible();
  await expect(page.getByText('No execution records yet. Submit a calculation to generate receipts.')).toHaveCount(0);
});

test('a failed receipt request shows the API error and downloads no placeholder', async ({ page }) => {
  const runId = '0123456789abcdef0123456789abcdef';
  await page.route('**/api/compute/history**', route => route.fulfill({
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify({ runs: [{
      run_id: runId,
      operation: 'vector_dot',
      status: 'SUCCEEDED',
      backend: 'cpu',
      execution_mode: 'LOCAL_CPU',
      persistence_status: 'DURABLE_POSTGRESQL',
      created_at: '2026-10-25T00:00:00Z',
      updated_at: '2026-10-25T00:00:01Z',
      receipt_sha256: 'a'.repeat(64),
      duration_ms: 1,
    }] }),
  }));
  await page.route(`**/api/compute/runs/${runId}`, route => route.fulfill({
    status: 503,
    contentType: 'application/json',
    body: JSON.stringify({ error: { code: 'RECEIPT_STORE_UNAVAILABLE', message: 'Receipt store temporarily unavailable.' } }),
  }));

  await page.goto('/workspace?tab=workspace');
  const runRow = page.getByRole('row').filter({ hasText: runId });
  await expect(runRow).toBeVisible();
  await runRow.getByRole('button', { name: 'Receipt' }).click();
  const receiptError = page.locator('p[role="alert"]');
  await expect(receiptError).toContainText('Receipt store temporarily unavailable.');
  await expect(receiptError).toContainText('No synthetic receipt was downloaded.');
});
