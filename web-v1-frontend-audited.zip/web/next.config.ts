import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  poweredByHeader: false,
  reactStrictMode: true,
  output: 'standalone',
  allowedDevOrigins: [
    'ais-dev-sboczjb2shhifb6l4644nd-756669488148.asia-southeast1.run.app',
    'ais-pre-sboczjb2shhifb6l4644nd-756669488148.asia-southeast1.run.app',
    '*.run.app',
  ],
  experimental: {
    serverActions: { bodySizeLimit: '64kb' }
  }
};

export default nextConfig;
