Founder portal is built from apps/engineering/src/. Canonical reading instructions are in ../LIPUN_READ_FIRST.md.
