import Link from 'next/link';
export default function NotFound() {
  return <main className="mx-auto max-w-2xl space-y-3 p-8"><h1 className="text-xl font-semibold">Page not found</h1><p className="text-sm text-slate-600">The requested BOYKA route does not exist.</p><Link href="/" className="underline">Return to portal</Link></main>;
}
