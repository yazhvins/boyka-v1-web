export default function Loading() {
  return <main className="mx-auto max-w-4xl p-8" role="status" aria-live="polite">Loading BOYKA…</main>;
}
