import { NextRequest, NextResponse } from 'next/server';
import { createHash, randomUUID } from 'crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

const BACKEND_TIMEOUT_MS = 30_000;
const MAX_BODY_BYTES = 65_536;
// Use a fixed path relative to the project root for local runs persistence
// In Next.js, __dirname is the compiled output directory. Use a configurable root with fallback.
// Try multiple strategies to find the project root reliably.
function getProjectRoot(): string {
  // 1. Explicit environment variable (most reliable)
  if (process.env.BOYKA_PROJECT_ROOT) return process.env.BOYKA_PROJECT_ROOT;
  // 2. In Next.js dev, process.cwd() is usually the project root
  // 3. In production, we can't rely on __dirname, so use a relative path from this file
  const fallbackFromFile = join(__dirname, '..', '..', '..', '..');
  // Use process.cwd() but avoid obvious build/temp directories
  const cwd = process.cwd();
  const isBuildOrTempDir = cwd.includes('.next') || cwd.includes('node_modules') || cwd.endsWith('.tmp') || cwd.includes('\\.next\\') || cwd.includes('/.next/');
  return isBuildOrTempDir ? fallbackFromFile : cwd;
}

const PROJECT_ROOT = getProjectRoot();
const LOCAL_RUNS_DIR = join(PROJECT_ROOT, 'tmp');
const LOCAL_RUNS_FILE = join(LOCAL_RUNS_DIR, 'boyka_local_runs.json');

// Lazy filesystem initialization to support edge runtime
let fsAvailable: boolean | null = null;
function ensureFsInitialized(): void {
  if (fsAvailable === true) return; // Already initialized successfully
  try {
    if (!existsSync(LOCAL_RUNS_DIR)) {
      mkdirSync(LOCAL_RUNS_DIR, { recursive: true });
    }
    fsAvailable = true;
  } catch {
    // fsAvailable stays null so we retry on next call; don't lock into false
    // This allows recovery if the filesystem becomes available later (e.g., volume mount)
  }
}

// Local ephemeral storage for degraded mode (also persisted to file)
const localRuns = new Map<string, {
  run_id: string;
  operation: string;
  status: string;
  backend: string | null;
  execution_mode: string;
  persistence_status: string;
  response: unknown;
  request: Record<string, unknown>;
  receipt_sha256: string | null;
  duration_ms: number | null;
  created_at: string;
  updated_at: string;
}>();

// Use a promise to prevent concurrent loads (race condition fix)
let loadPromise: Promise<void> | null = null;

async function loadLocalRunsFromFile(): Promise<void> {
  // If already loaded, return immediately
  if (loadPromise) return loadPromise;

  loadPromise = (async () => {
    ensureFsInitialized();
    if (!fsAvailable) return;
    try {
      if (existsSync(LOCAL_RUNS_FILE)) {
        const data = readFileSync(LOCAL_RUNS_FILE, 'utf-8');
        const runs = JSON.parse(data) as Array<typeof localRuns extends Map<infer K, infer V> ? V : never>;
        for (const run of runs) {
          localRuns.set(run.run_id, run);
        }
      }
    } catch {
      // File doesn't exist or invalid JSON - start fresh
    }
  })();

  return loadPromise;
}

// Debounced save to avoid blocking on every execution
let saveTimeout: NodeJS.Timeout | null = null;
const MAX_LOCAL_RUNS = 1000; // Memory leak prevention: keep last 1000 runs
function saveLocalRunsToFile(): void {
  ensureFsInitialized();
  if (!fsAvailable) return;
  if (saveTimeout) clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    try {
      // Evict old runs if we exceed max size (keep most recent)
      if (localRuns.size > MAX_LOCAL_RUNS) {
        const runs = Array.from(localRuns.values())
          .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
          .slice(0, MAX_LOCAL_RUNS);
        localRuns.clear();
        for (const run of runs) localRuns.set(run.run_id, run);
      }
      const runsToSave = Array.from(localRuns.values());
      writeFileSync(LOCAL_RUNS_FILE, JSON.stringify(runsToSave, null, 2), 'utf-8');
    } catch {
      // Ignore write errors (e.g., permission issues)
    }
    saveTimeout = null;
  }, 100);
}

// Flush pending writes immediately (for shutdown)
export function flushLocalRuns(): void {
  if (saveTimeout) {
    clearTimeout(saveTimeout);
    saveTimeout = null;
    // Execute the save synchronously
    ensureFsInitialized();
    if (fsAvailable) {
      try {
        if (localRuns.size > MAX_LOCAL_RUNS) {
          const runs = Array.from(localRuns.values())
            .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
            .slice(0, MAX_LOCAL_RUNS);
          localRuns.clear();
          for (const run of runs) localRuns.set(run.run_id, run);
        }
        const runsToSave = Array.from(localRuns.values());
        writeFileSync(LOCAL_RUNS_FILE, JSON.stringify(runsToSave, null, 2), 'utf-8');
      } catch {
        // Ignore write errors
      }
    }
  }
}

// Register shutdown handlers (only in Node.js environment)
if (typeof process !== 'undefined' && process.on) {
  process.on('beforeExit', flushLocalRuns);
  process.on('SIGINT', flushLocalRuns);
  process.on('SIGTERM', flushLocalRuns);
}

// Ensure runs are loaded before any access
async function ensureRunsLoaded(): Promise<void> {
  await loadLocalRunsFromFile();
}

function generateRunId(): string {
  // Use full UUID to avoid collision risk under rapid concurrent calls
  return `local-${randomUUID()}`;
}

function generateReceiptSha256(data: unknown): string {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// Local V1 computation implementations for degraded mode
function computeVectorDotLocal(left: number[], right: number[]): number {
  if (left.length !== right.length) throw new Error('Vectors must have equal length');
  let sum = 0;
  for (let i = 0; i < left.length; i++) {
    sum += left[i] * right[i];
  }
  return sum;
}

function computeDotI16VectorLocal(a: number[], b: number[]): number {
  if (a.length !== b.length) throw new Error('Vectors must have equal length');
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    // int16 multiplication with int64 accumulation
    const ai = Math.max(-32768, Math.min(32767, Math.trunc(a[i])));
    const bi = Math.max(-32768, Math.min(32767, Math.trunc(b[i])));
    sum += ai * bi;
  }
  return sum;
}

function computeMatmulOnesLocal(size: number): { trace: number; sum: number; frobenius_norm: number } {
  // All-ones matrix multiplication: A @ A where A is NxN matrix of ones
  // Result is NxN matrix where every element = N
  // Trace = N * N = N^2
  // Sum = N^2 * N = N^3
  // Frobenius norm = sqrt(N^2 * N^2) = N^2
  const trace = size * size;
  const sum = size * size * size;
  const frobenius_norm = size * size;
  return { trace, sum, frobenius_norm };
}

export function backendOrigin(): URL | null {
  const raw = process.env.BOYKA_API_ORIGIN || 'http://127.0.0.1:8005';
  if (!raw) return null;
  const parsed = new URL(raw);
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash) {
    throw new Error('BOYKA_API_ORIGIN must be an HTTP(S) origin without embedded credentials');
  }
  return parsed;
}

export function backendUnavailableResponse(reason = 'The BOYKA execution API is unavailable; local execution fallback is provided.') {
  return NextResponse.json({
    error: { code: 'COMPUTE_BACKEND_UNAVAILABLE', message: reason },
  }, {
    status: 503,
    headers: { 'cache-control': 'no-store', 'x-boyka-backend-mode': 'upstream-unavailable' },
  });
}

// Local execution fallback for V1 operations
async function executeLocalV1(operation: string, payload: Record<string, unknown>): Promise<{
  run_id: string;
  status: string;
  actual_backend: string;
  execution_mode: string;
  output: unknown;
  verification: { status: string; verifier_id: string; independent: boolean; reason: string };
  persistence: { durability: string; store: string; warning: string };
  receipt: Record<string, unknown>;
  source_revision: string;
}> {
  await ensureRunsLoaded();
  const runId = generateRunId();
  const startTime = Date.now();
  let output: unknown;
  // Use a clear status name that indicates self-consistency only, NOT independent verification
  let verificationStatus = 'LOCAL_SELF_CONSISTENCY_CHECK';
  let verifierId = 'local-reference-recomputation';

  if (operation === 'vector_dot') {
    const left = (payload.left as number[]) ?? [];
    const right = (payload.right as number[]) ?? [];
    const result = computeVectorDotLocal(left, right);
    // Self-recomputation consistency check (not independent verification)
    const verificationResult = computeVectorDotLocal(left, right);
    if (result === verificationResult) {
      // Local fallback: self-recomputation produced same result; this is self-consistency, NOT independent verification
      verificationStatus = 'LOCAL_SELF_CONSISTENCY_CHECK';
    }
    output = { dot_product: result };
  } else if (operation === 'matmul_ones') {
    const size = (payload.size as number) ?? 1;
    const result = computeMatmulOnesLocal(size);
    // Self-recomputation consistency check (not independent verification)
    const verificationResult = computeMatmulOnesLocal(size);
    if (JSON.stringify(result) === JSON.stringify(verificationResult)) {
      // Local fallback: self-recomputation produced same result; this is self-consistency, NOT independent verification
      verificationStatus = 'LOCAL_SELF_CONSISTENCY_CHECK';
    }
    output = result;
  } else if (operation === 'dot_i16_vector') {
    const a = (payload.a as number[]) ?? [];
    const b = (payload.b as number[]) ?? [];
    const result = computeDotI16VectorLocal(a, b);
    // Self-recomputation consistency check (not independent verification)
    const verificationResult = computeDotI16VectorLocal(a, b);
    if (result === verificationResult) {
      // Local fallback: self-recomputation produced same result; this is self-consistency, NOT independent verification
      verificationStatus = 'LOCAL_SELF_CONSISTENCY_CHECK';
    }
    output = { dot_product: result };
  } else {
    throw new Error(`Unsupported local operation: ${operation}`);
  }

  const durationMs = Date.now() - startTime;
  const receipt = {
    run_id: runId,
    operation,
    status: 'SUCCEEDED',
    actual_backend: 'cpu',
    execution_mode: 'LOCAL_FALLBACK',
    output,
    verification: { status: verificationStatus, verifier_id: verifierId, independent: false, reason: 'Local fallback: self-recomputation produced same result; this is a self-consistency check only, NOT independent verification by an external oracle.' },
    persistence: { durability: 'EPHEMERAL_IN_MEMORY', store: 'local-memory', warning: 'Local fallback execution; not durably persisted. Re-run when upstream is available for durable receipt.' },
    source_revision: 'local-fallback',
  };
  const receiptSha256 = generateReceiptSha256(receipt);

  const runRecord = {
    run_id: runId,
    operation,
    status: 'SUCCEEDED',
    backend: 'cpu',
    execution_mode: 'LOCAL_FALLBACK',
    persistence_status: 'EPHEMERAL_IN_MEMORY',
    response: receipt,
    request: { operation, payload },
    receipt_sha256: receiptSha256,
    duration_ms: durationMs,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  localRuns.set(runId, runRecord);
  saveLocalRunsToFile();

  return {
    run_id: runId,
    status: 'SUCCEEDED',
    actual_backend: 'cpu',
    execution_mode: 'LOCAL_FALLBACK',
    output,
    verification: { status: verificationStatus, verifier_id: verifierId, independent: false, reason: 'Local fallback: self-recomputation produced same result; this is a self-consistency check only, NOT independent verification by an external oracle.' },
    persistence: { durability: 'EPHEMERAL_IN_MEMORY', store: 'local-memory', warning: 'Local fallback execution; not durably persisted.' },
    receipt,
    source_revision: 'local-fallback',
  };
}

// Local persistence helpers
export async function getLocalRun(runId: string) {
  await ensureRunsLoaded();
  return localRuns.get(runId) ?? null;
}

export async function getAllLocalRuns(): Promise<Array<{
  run_id: string;
  operation: string;
  status: string;
  backend: string | null;
  execution_mode: string;
  persistence_status: string;
  response: unknown;
  request: Record<string, unknown>;
  receipt_sha256: string | null;
  duration_ms: number | null;
  created_at: string;
  updated_at: string;
}>> {
  await ensureRunsLoaded();
  return Array.from(localRuns.values()).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export async function proxyBackend(request: NextRequest, targetPath: string, method: 'GET' | 'POST' = 'GET', bodyText?: string) {
  let origin: URL | null;
  try {
    origin = backendOrigin();
  } catch (error) {
    return NextResponse.json({
      error: { code: 'BACKEND_CONFIGURATION_INVALID', message: error instanceof Error ? error.message : 'Invalid backend configuration' },
    }, { status: 500 });
  }
  if (!origin) return backendUnavailableResponse('BOYKA_API_ORIGIN is not configured.');

  let target: URL;
  try {
    target = new URL(targetPath, origin);
  } catch (error) {
    return NextResponse.json({
      error: { code: 'BACKEND_CONFIGURATION_INVALID', message: error instanceof Error ? error.message : 'Invalid backend configuration' },
    }, { status: 500 });
  }

  if (method === 'POST' && new TextEncoder().encode(bodyText ?? '').byteLength > MAX_BODY_BYTES) {
    return NextResponse.json({
      error: { code: 'REQUEST_TOO_LARGE', message: 'Request body exceeds 64 KiB.' },
    }, { status: 413 });
  }

  const headers = new Headers({ accept: 'application/json' });
  for (const name of ['authorization', 'x-boyka-tenant', 'idempotency-key', 'x-request-id']) {
    const value = request.headers.get(name);
    if (value) headers.set(name, value);
  }
  if (method === 'POST') headers.set('content-type', 'application/json');

  let upstream: Response;
  try {
    upstream = await fetch(target, {
      method,
      headers,
      body: method === 'POST' ? bodyText : undefined,
      cache: 'no-store',
      signal: AbortSignal.timeout(BACKEND_TIMEOUT_MS),
    });
  } catch (error) {
    const timedOut = error instanceof Error && (error.name === 'TimeoutError' || error.name === 'AbortError');
    // Try local fallback for POST /api/compute/jobs (exact path or with query params)
    const isJobsPath = targetPath === '/api/compute/jobs' || targetPath.startsWith('/api/compute/jobs?') || targetPath.startsWith('/api/compute/jobs/');
    if (method === 'POST' && isJobsPath && bodyText) {
      try {
        let body: { operation?: string; payload?: Record<string, unknown> };
        try {
          body = JSON.parse(bodyText);
        } catch {
          // Invalid JSON - return 400 instead of falling back
          return NextResponse.json({
            error: { code: 'INVALID_REQUEST', message: 'Request body must be valid JSON.' },
          }, { status: 400 });
        }
        // Support local fallback for all V1 operations that we can compute locally
        if (body.operation && ['vector_dot', 'matmul_ones', 'dot_i16_vector'].includes(body.operation)) {
          const localResult = await executeLocalV1(body.operation, body.payload ?? {});
          return NextResponse.json(localResult, {
            status: 200,
            headers: {
              'cache-control': 'no-store',
              'x-boyka-backend-mode': 'local-fallback',
              'x-boyka-run-id': localResult.run_id,
            },
          });
        }
      } catch {
        // Fall through to unavailable response
      }
    }
    return backendUnavailableResponse(timedOut
      ? 'The BOYKA execution API did not respond before the gateway timeout; local fallback unavailable for this operation.'
      : 'The BOYKA execution API could not be reached; local fallback unavailable for this operation.');
  }

  const contentType = upstream.headers.get('content-type') ?? '';
  if (!contentType.includes('application/json')) {
    // Forward error headers even on invalid response
    const responseHeaders = new Headers({
      'cache-control': 'no-store',
      'x-boyka-backend-mode': 'upstream-invalid-response',
    });
    for (const name of ['x-boyka-run-id', 'x-boyka-persistence', 'idempotent-replay', 'retry-after']) {
      const value = upstream.headers.get(name);
      if (value) responseHeaders.set(name, value);
    }
    return NextResponse.json({
      error: { code: 'INVALID_BACKEND_RESPONSE', message: 'The BOYKA API responded without a JSON content type.' },
    }, { status: 502, headers: responseHeaders });
  }

  let payload: unknown;
  try {
    payload = await upstream.json();
  } catch {
    const responseHeaders = new Headers({
      'cache-control': 'no-store',
      'x-boyka-backend-mode': 'upstream-invalid-response',
    });
    for (const name of ['x-boyka-run-id', 'x-boyka-persistence', 'idempotent-replay', 'retry-after']) {
      const value = upstream.headers.get(name);
      if (value) responseHeaders.set(name, value);
    }
    return NextResponse.json({
      error: { code: 'INVALID_BACKEND_RESPONSE', message: 'The BOYKA API returned malformed JSON.' },
    }, { status: 502, headers: responseHeaders });
  }

  const responseHeaders = new Headers({
    'cache-control': 'no-store',
    'x-boyka-backend-mode': upstream.ok ? 'upstream-v1-api' : 'upstream-v1-api-error',
  });
  // Forward headers on both success and error responses
  for (const name of ['x-boyka-run-id', 'x-boyka-persistence', 'idempotent-replay', 'retry-after']) {
    const value = upstream.headers.get(name);
    if (value) responseHeaders.set(name, value);
  }
  return NextResponse.json(payload, { status: upstream.status, headers: responseHeaders });
}

export async function readJsonBody(request: NextRequest): Promise<{ text?: string; error?: NextResponse }> {
  const announcedLength = Number(request.headers.get('content-length') ?? '0');
  if (Number.isFinite(announcedLength) && announcedLength > MAX_BODY_BYTES) {
    return { error: NextResponse.json({ error: { code: 'REQUEST_TOO_LARGE', message: 'Request body exceeds 64 KiB.' } }, { status: 413 }) };
  }
  const reader = request.body?.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    if (reader) {
      while (true) {
        const next = await reader.read();
        if (next.done) break;
        total += next.value.byteLength;
        if (total > MAX_BODY_BYTES) {
          await reader.cancel();
          return { error: NextResponse.json({ error: { code: 'REQUEST_TOO_LARGE', message: 'Request body exceeds 64 KiB.' } }, { status: 413 }) };
        }
        chunks.push(next.value);
      }
    }
  } catch {
    return { error: NextResponse.json({ error: { code: 'REQUEST_BODY_READ_FAILED', message: 'The request body could not be read.' } }, { status: 400 }) };
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return { text: new TextDecoder('utf-8', { fatal: true }).decode(bytes) };
  } catch {
    return { error: NextResponse.json({ error: { code: 'INVALID_REQUEST_ENCODING', message: 'Request body must be valid UTF-8.' } }, { status: 400 }) };
  }
}
