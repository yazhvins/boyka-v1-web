import { NextRequest, NextResponse } from 'next/server';
import { proxyBackend, readJsonBody } from '../../../lib/backend';
export const dynamic = 'force-dynamic';
export async function POST(request: NextRequest) {
  const body = await readJsonBody(request);
  if (body.error) return body.error;
  const value = JSON.parse(body.text ?? '{}') as Record<string, unknown>;
  if (typeof value.operation !== 'string' || typeof value.payload !== 'object' || value.payload === null || Array.isArray(value.payload)) {
    return NextResponse.json({ error: { code: 'INVALID_REQUEST', message: 'operation and a JSON object payload are required.' } }, { status: 422 });
  }
  return proxyBackend(request, '/api/compute/jobs', 'POST', body.text);
}
