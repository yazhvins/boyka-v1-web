import { NextRequest, NextResponse } from 'next/server';
import { proxyBackend, getAllLocalRuns } from '../../../lib/backend';
export const dynamic = 'force-dynamic';
export async function GET(request: NextRequest) {
  const raw = request.nextUrl.searchParams.get('limit') ?? '20';
  const limit = Number(raw);
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) {
    return NextResponse.json({ error: { code: 'INVALID_HISTORY_LIMIT', message: 'limit must be an integer from 1 through 100.' } }, { status: 400 });
  }
  // Try upstream first
  const upstreamResponse = await proxyBackend(request, `/api/compute/history?limit=${limit}`);
  if (upstreamResponse.ok) {
    return upstreamResponse;
  }
  // Fallback: return local history
  const localRuns = (await getAllLocalRuns()).slice(0, limit);
  return NextResponse.json(
    { runs: localRuns },
    { status: 200, headers: { 'cache-control': 'no-store', 'x-boyka-backend-mode': 'local-fallback-history' } }
  );
}
