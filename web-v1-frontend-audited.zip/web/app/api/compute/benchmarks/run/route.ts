import { NextRequest } from 'next/server';
import { proxyBackend, readJsonBody } from '../../../../lib/backend';
export const dynamic = 'force-dynamic';
export async function POST(request: NextRequest) {
  const body = await readJsonBody(request);
  return proxyBackend(request, '/api/compute/benchmarks/run', 'POST', body.text);
}
