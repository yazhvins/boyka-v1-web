import { NextRequest, NextResponse } from 'next/server';
import { proxyBackend, readJsonBody } from '../../../../lib/backend';
export const dynamic = 'force-dynamic';
export async function POST(request: NextRequest) {
  const body = await readJsonBody(request);
  if (body.error) return body.error;
  let value: Record<string, unknown>;
  try { value = JSON.parse(body.text ?? '{}') as Record<string, unknown>; }
  catch { return NextResponse.json({ error: { code: 'INVALID_JSON', message: 'The request body must be valid JSON.' } }, { status: 400 }); }
  const validVector = (candidate: unknown) => Array.isArray(candidate) && candidate.length >= 1 && candidate.length <= 256 && candidate.every(x => Number.isInteger(x) && typeof x === 'number' && x >= -32768 && x <= 32767);
  const a = value.a;
  const b = value.b;
  if (!validVector(a) || !validVector(b) || !Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
    return NextResponse.json({ error: { code: 'INVALID_INT16_VECTOR', message: 'a and b must be equal-length vectors (1–256) of signed int16 integers.' } }, { status: 422 });
  }
  return proxyBackend(request, '/api/compute/v2/execute', 'POST', body.text);
}
