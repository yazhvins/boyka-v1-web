import { NextRequest, NextResponse } from 'next/server';
import { proxyBackend, getLocalRun } from '../../../../lib/backend';
export const dynamic = 'force-dynamic';
export async function GET(request: NextRequest, context: { params: Promise<{ runId: string }> }) {
  const { runId } = await context.params;
  // Validate run ID format (32-char hex for upstream, or local-* for local fallback)
  // Local IDs: local-<UUID> (matches generateRunId in backend.ts)
  // UUID format: 8-4-4-4-12 = 36 chars with hyphens (e.g., 123e4567-e89b-12d3-a456-426614174000)
  const isUpstreamId = /^[a-f0-9]{32}$/.test(runId);
  const uuidRegex = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
  const isLocalId = runId.startsWith('local-') && uuidRegex.test(runId.slice(6));
  if (!isUpstreamId && !isLocalId) {
    return NextResponse.json({ error: { code: 'INVALID_RUN_ID', message: 'runId must be a 32-character lowercase hexadecimal identifier or a local fallback ID.' } }, { status: 400 });
  }
  // Check local storage first for local IDs
  if (isLocalId) {
    const localRun = await getLocalRun(runId);
    if (localRun) {
      return NextResponse.json(localRun, { status: 200, headers: { 'cache-control': 'no-store', 'x-boyka-backend-mode': 'local-fallback' } });
    }
    return NextResponse.json({ error: { code: 'RUN_NOT_FOUND', message: 'Local run not found.' } }, { status: 404 });
  }
  // For upstream IDs, try upstream first, then check local as fallback
  const upstreamResponse = await proxyBackend(request, `/api/compute/runs/${runId}`);
  if (upstreamResponse.ok) {
    return upstreamResponse;
  }
  // Check if we have this run locally (unlikely but possible)
  const localRun = await getLocalRun(runId);
  if (localRun) {
    return NextResponse.json(localRun, { status: 200, headers: { 'cache-control': 'no-store', 'x-boyka-backend-mode': 'local-fallback' } });
  }
  return upstreamResponse;
}
