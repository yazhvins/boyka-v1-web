import { NextRequest } from 'next/server';
import { proxyBackend } from '../../../lib/backend';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const resolved = await params;
  const subpath = resolved.path?.join('/') || '';
  return proxyBackend(request, `/api/hardware/${subpath}`);
}
