import { NextRequest } from 'next/server';
import { proxyBackend } from '../../../lib/backend';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const resolved = await params;
  const subpath = resolved.path?.join('/') || '';
  return proxyBackend(request, `/api/v2/${subpath}`, 'GET');
}

export async function POST(request: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  const resolved = await params;
  const subpath = resolved.path?.join('/') || '';
  const bodyText = await request.text();
  return proxyBackend(request, `/api/v2/${subpath}`, 'POST', bodyText);
}
