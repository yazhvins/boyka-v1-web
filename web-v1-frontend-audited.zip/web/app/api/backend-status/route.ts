import { NextResponse } from 'next/server';
import { backendOrigin } from '../../lib/backend';

export const dynamic = 'force-dynamic';

function isDurableReady(persistence?: { backend?: string; status?: string; durability?: string }): boolean {
  return persistence?.status === 'READY'
    && persistence.durability === 'DURABLE'
    && (persistence.backend === 'POSTGRESQL' || persistence.backend === 'SQLITE');
}

export async function GET() {
  const origin = backendOrigin();
  if (!origin) {
    return NextResponse.json({
      connected: false,
      mode: 'UPSTREAM_UNAVAILABLE',
      durability: 'UNAVAILABLE',
      detail: 'No upstream backend origin configured.',
    });
  }

  try {
    // Try the V1 capabilities endpoint first (the known working endpoint)
    const res = await fetch(new URL('/api/compute/capabilities', origin), {
      cache: 'no-store',
      signal: AbortSignal.timeout(2000),
    });
    if (res.ok) {
      const caps = await res.json() as {
        operations?: Array<{
          backends?: Record<string, { execution_allowed?: boolean; status?: string }>;
        }>;
        persistence?: { backend?: string; status?: string; durability?: string };
      };
      // Check for durable storage (PostgreSQL or SQLite) from capabilities response
      const durableReady = isDurableReady(caps.persistence);
      // Also check if CPU is allowed for at least one operation
      const cpuAllowed = caps.operations?.some(op =>
        op.backends?.cpu?.execution_allowed === true
      ) ?? false;

      if (durableReady && cpuAllowed) {
        const backendType = caps.persistence?.backend === 'POSTGRESQL' ? 'DURABLE_POSTGRESQL' : 'DURABLE_SQLITE';
        return NextResponse.json({
          connected: true,
          mode: 'AUTHORITATIVE_V1_DAEMON',
          durability: backendType,
          backend_origin: origin.toString(),
          detail: `V1 API and its ${caps.persistence?.backend} persistence check are ready.`,
        });
      }
      if (cpuAllowed) {
        return NextResponse.json({
          connected: true,
          mode: 'AUTHORITATIVE_V1_DAEMON',
          durability: 'EPHEMERAL_ONLY',
          backend_origin: origin.toString(),
          detail: 'V1 API responded and CPU execution is allowed, but durable persistence was not confirmed.',
        });
      }
      return NextResponse.json({
        connected: false,
        mode: 'UPSTREAM_UNAVAILABLE',
        durability: 'UNAVAILABLE',
        backend_origin: origin.toString(),
        detail: 'V1 API responded, but no operations are executable on CPU; durable execution is unavailable.',
      });
    }
  } catch {
    // Upstream offline or endpoint not available
  }

  // Fallback: try /api/health endpoint if capabilities failed
  try {
    const res = await fetch(new URL('/api/health', origin), {
      cache: 'no-store',
      signal: AbortSignal.timeout(2000),
    });
    if (res.ok) {
      const health = await res.json() as {
        persistence?: { backend?: string; status?: string; durability?: string };
      };
      const durableReady = isDurableReady(health.persistence);
      if (durableReady) {
        const backendType = health.persistence?.backend === 'POSTGRESQL' ? 'DURABLE_POSTGRESQL' : 'DURABLE_SQLITE';
        return NextResponse.json({
          connected: true,
          mode: 'AUTHORITATIVE_V1_DAEMON',
          durability: backendType,
          backend_origin: origin.toString(),
          detail: `V1 API /health endpoint and ${health.persistence?.backend} persistence check are ready.`,
        });
      }
      return NextResponse.json({
        connected: false,
        mode: 'UPSTREAM_UNAVAILABLE',
        durability: 'UNAVAILABLE',
        backend_origin: origin.toString(),
        detail: 'V1 API /health responded, but durable persistence readiness was not confirmed; durable execution is unavailable.',
      });
    }
  } catch {
    // Upstream offline
  }

  return NextResponse.json({
    connected: false,
    mode: 'UPSTREAM_UNAVAILABLE',
    durability: 'UNAVAILABLE',
    backend_origin: origin.toString(),
    detail: 'The V1 API is unreachable. Product execution and receipt retrieval are unavailable.',
  });
}
