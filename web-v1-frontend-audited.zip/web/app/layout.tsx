import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  title: 'BOYKA | Absolute Computing & Intelligence',
  description: 'BOYKA V1 architecture, verified computing runtime, engineering portal, and hardware co-design validation.',
  applicationName: 'BOYKA',
  openGraph: {
    title: 'BOYKA | Absolute Computing & Intelligence',
    description: 'BOYKA V1 architecture, verified computing runtime, engineering portal, and hardware co-design validation.',
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  colorScheme: 'light dark',
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
