export type RegimeType = 'DISCOVERY' | 'EXPERIMENTAL' | 'ENGINEERING' | 'REPEATABLE' | 'SCALE' | 'HIGH_ASSURANCE';
export type MaturityType = 'M0_UNKNOWN' | 'M1_EXPLORATORY' | 'M2_DEFINED' | 'M3_REPEATABLE' | 'M4_MEASURED' | 'M5_CONTROLLED' | 'M6_OPTIMIZING' | 'NOT_ASSESSED' | 'EXPLORATORY';

export interface ManifestDocument {
  source_id: string;
  archive_member: string;
  sha256: string;
  bytes: number;
  pages: number;
  text_extraction_pages: number;
  classification: string;
  confidentiality: string;
  publication_status: string;
  extraction_status: string;
  visual_inspection_status: string;
  visually_inspected_pages: number[];
}

export interface IntakeManifest {
  archive_path: string;
  archive_sha256: string;
  archive_bytes: number;
  documents: ManifestDocument[];
  total_pages: number;
  source_audit_status: string;
  approval_record: string;
}

export interface ThesisStatement {
  statement_id: string;
  source_id: string;
  pages: number[];
  statement_kind: 'PROPOSED_CAPABILITY' | 'REQUIREMENT' | 'ROADMAP_PROJECTION' | 'OWNERSHIP_ASSERTION' | 'EXTERNAL_LANDSCAPE_ASSERTION' | 'ILLUSTRATIVE_EXAMPLE' | 'EXPLICIT_LIMITATION';
  summary: string;
  exact_or_near_quote: string;
  rp01_query_families: string[];
  review_status: 'PENDING_HUMAN_REVIEW' | 'HUMAN_REVIEWED' | 'REJECTED';
  validation_status: 'NOT_INDEPENDENTLY_VALIDATED' | 'VALIDATED';
  external_claim_authorized: boolean;
  numeric_evidence_status?: string;
  external_reference_status?: string;
}

export interface ReviewRequirement {
  statement_id: string;
  source_id: string;
  pages: number[];
  requirement_id: string;
  requirement_summary: string;
  review_layer: 'HUMAN_REVIEW_REQUIREMENT' | 'FUTURE_EXPERIMENT_REQUIREMENT';
  rp01_query_families: string[];
  provenance: string;
  human_authored: boolean;
  experiment_authorized: boolean;
}

export interface AbsenceObservation {
  item: string;
  statement: string;
}

export interface LipunQuestion {
  question_id: string;
  text: string;
  why_needed: string;
}

export interface QueryFamily {
  id: string;
  name: string;
  queries: string[];
  relevance_to_boyka: string;
  classical_roots?: string;
}

export interface RP01Protocol {
  protocol_id: string;
  work_item_id: string;
  status: string;
  infrastructure_only: boolean;
  populate_real_papers: boolean;
  autonomous_conclusions: boolean;
  query_families: QueryFamily[];
}

export interface SchemaInfo {
  name: string;
  title: string;
  required: string[];
  description?: string;
}

export interface GateInfo {
  id: string;
  name: string;
  status: 'GATED' | 'UNASSESSED' | 'NOT_APPROVED_FOR_EXPERIMENT' | 'ACTIVE' | 'APPROVED';
  rationale: string;
  required_evidence: string;
}

export interface EvidenceItem {
  id: string;
  title: string;
  claim_or_summary: string;
  source_type: 'BOYKA_DOCUMENT' | 'ACADEMIC_PAPER' | 'PHYSICAL_LAW' | 'SYSTEM_MEASUREMENT' | 'GOVERNANCE_DECISION';
  source_reference: string;
  exact_quote?: string;
  canonical_id?: string;
  evidence_level: 'E0_UNSUPPORTED' | 'E1_ASSERTION' | 'E2_THEORETICAL' | 'E3_PROTOTYPE' | 'E4_REPRODUCIBLE' | 'E5_PEER_REVIEWED' | 'E6_PRODUCTION';
  limitations: string[];
  contradicting_evidence?: string;
  review_status: 'AWAITING_REVIEW' | 'VERIFIED' | 'FALSIFIED' | 'GATED';
  provenance_trail: string;
}

export type TruthState =
  | 'SOURCE'
  | 'LITERATURE'
  | 'MEASURED'
  | 'DERIVED'
  | 'SIMULATED'
  | 'PROTOTYPE'
  | 'PROPOSED'
  | 'NOT_MEASURED'
  | 'EXTERNAL_VALIDATION_REQUIRED';

// Comprehensive Master Navigation Routes
export type PortalRoute = 
  // Core
  | 'overview'
  | 'journey'
  | 'm2-m50'
  | 'architecture-evolution'
  | 'implementation-status'
  | 'hardware-validation'
  | 'owned-models'
  | 'live-prototype'
  | 'remaining-work'
  // Understand
  | 'boyka-understanding'
  | 'my-assessment'
  | 'problems-opportunities'
  | 'market-competition'
  | 'documents'
  // Think
  | 'research'
  | 'theories'
  | 'first-principles'
  | 'decisions'
  // Build
  | 'technology'
  | 'architecture'
  | 'prototypes'
  | 'experiments'
  | 'results'
  // Create Value
  | 'product'
  | 'customers'
  | 'business'
  | 'economics'
  // Go To Market
  | 'positioning'
  | 'gtm'
  | 'sales'
  | 'partnerships'
  // Build The Company
  | 'company-blueprint'
  | 'leadership'
  | 'ceo-cto'
  | 'stage-leadership-matrix'
  | 'organization'
  | 'people-hiring'
  | 'team-sizing'
  | 'finance-capital'
  | 'fundraising'
  | 'capital-allocation'
  | 'responsibility-graph'
  | 'cto-interaction-map'
  | 'operations'
  | 'security'
  | 'ip-legal'
  | 'risks'
  | 'scale'
  // My Proposal
  | 'if-i-join'
  | 'execution-plan'
  | 'execution'
  | 'company-evolution'
  // Workspace
  | 'workspace-notebook'
  | 'contextual-ai'
  // Advanced
  | 'evidence'
  | 'sources'
  | 'reproducibility'
  | 'audit'
  // New Technical Depth Routes
  | 'architecture-explorer'
  | 'workload-trace'
  | 'decision-trees'
  | 'build-buy-partner'
  | 'failure-scenarios'
  | 'capital-workflow'
  | 'capability-architecture'
  // Legacy aliases
  | 'solutions'
  | 'people'
  | 'company'
  | 'risks-security'
  | 'finance'
  | 'investor'
  | 'audit-system'
  | 'command-center'
  | 'digital-thread'
  | 'source-intake'
  | 'rp01-research'
  | 'ledgers-evidence'
  | 'hypotheses-experiments'
  | 'architecture-gates'
  | 'product-customer'
  | 'economics-finance'
  | 'people-organization'
  | 'execution-engine'
  | 'executive-lenses'
  | 'demonstrations'
  | 'audit-integrity'
  | 'data-room';

export type ExecutiveRole = 
  | 'CEO'
  | 'CTO'
  | 'CFO'
  | 'COO'
  | 'CPO'
  | 'CIO_DATA'
  | 'CISO'
  | 'CMO_GTM'
  | 'CRO_SALES'
  | 'CHIEF_PEOPLE'
  | 'LEGAL_IP'
  | 'BOARD'
  | 'INVESTOR'
  | 'AUDITOR';

export type CompanyStage = 
  | 'FORMATION'
  | 'DISCOVERY'
  | 'VALIDATION'
  | 'PROTOTYPE'
  | 'MVP'
  | 'PILOT'
  | 'EARLY_COMMERCIAL'
  | 'GROWTH'
  | 'SCALE'
  | 'MATURE';

export interface CommentItem {
  id: string;
  author: 'Arun Kumar (Candidate CTO)' | 'Reviewer (local note)' | 'External Reviewer';
  role: string;
  timestamp: string;
  targetType: 'document' | 'theory' | 'architecture' | 'decision' | 'product' | 'blueprint';
  targetId: string;
  text: string;
  reaction?: 'agree' | 'question' | 'challenge' | 'alternative';
  status: 'open' | 'resolved';
  replies?: CommentItem[];
}

export interface ReviewAnnotation {
  id: string;
  documentId: string;
  pageNumber: number;
  selectedText: string;
  myUnderstanding: string;
  assessmentKind: 'AGREE' | 'CHALLENGE' | 'QUESTION' | 'ALTERNATIVE' | 'EVIDENCE_REQUIRED';
  discussionStatus: 'OPEN' | 'RESOLVED';
  createdDate: string;
  comments: CommentItem[];
}

export type ArchitectureLayerId = 
  | 'TASK_WORKLOAD'
  | 'AI_SYSTEM'
  | 'MODEL_ALGORITHM'
  | 'RUNTIME'
  | 'COMPILER'
  | 'KERNEL'
  | 'DEVICE'
  | 'MEMORY'
  | 'INTERCONNECT'
  | 'NODE'
  | 'CLUSTER'
  | 'RACK'
  | 'POWER'
  | 'THERMAL_COOLING';

export interface ArchitectureLayerDetail {
  id: ArchitectureLayerId;
  name: string;
  depthOrder: number;
  purpose: string;
  inputs: string[];
  outputs: string[];
  constraints: string[];
  metrics: { name: string; value: string; unit: string; isMeasured: boolean }[];
  bottlenecks: string[];
  dependencies: string[];
  existingApproaches: string;
  boykaRelevance: string;
  researchBasis: string;
  theoreticalMechanism: string;
  experimentIds: string[];
  nextTechnicalGate: string;
}

export interface WorkloadTraceNode {
  step: 'USER_REQUIREMENT' | 'WORKLOAD' | 'SOFTWARE_BEHAVIOR' | 'PROFILE' | 'BOTTLENECK' | 'ARCHITECTURE_REQUIREMENT' | 'HARDWARE_REQUIREMENT' | 'PHYSICAL_SYSTEM_REQUIREMENT';
  title: string;
  description: string;
  quantifiedParams: string[];
  boykaObservation: string;
  unknownStatus: string;
}

export interface TechnicalFailureScenario {
  id: string;
  title: string;
  category: 'ALGORITHMIC' | 'MEMORY' | 'NETWORK' | 'VERIFIER' | 'RACK_THERMAL' | 'ECONOMIC';
  symptom: string;
  detectionSignal: string;
  diagnosticMethod: string;
  rootCause: string;
  measuredImpact: string;
  containmentProtocol: string;
  decisionGate: string;
  architecturalRedesign: string;
}

export interface SubsystemEvaluation {
  id: string;
  subsystem: string;
  category: 'SOFTWARE' | 'HARDWARE' | 'INFRASTRUCTURE' | 'MANUFACTURING';
  strategicDifferentiation: 'CRITICAL_CORE' | 'HIGH' | 'COMMODITY_SUPPORT' | 'NON_DIFFERENTIATING';
  technicalRequirements: string;
  cotsAlternatives: string[];
  performanceDelta: string;
  integrationComplexity: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
  controlAndIP: string;
  timeToDeploy: string;
  engineeringBurden: string;
  costAssessment: string;
  dependencyRisk: string;
  recommendation: 'BUILD_PROPRIETARY' | 'BUY_OR_RENT_COTS' | 'PARTNER_SPECIALIST' | 'DEFER_GATE';
  gatingCondition: string;
}

export interface ExecutiveDecisionCase {
  id: string;
  title: string;
  dilemmaSummary: string;
  context: string;
  perspectives: {
    ceo: string;
    cto: string;
    product: string;
    finance: string;
    sales: string;
    security: string;
    legal: string;
  };
  informationFlow: string[];
  decisionAuthority: string;
  tradeOffsEvaluated: string[];
  resultingAction: string;
  followUpReviewGate: string;
}

export interface TechnicalCapabilitySpec {
  id: string;
  discipline: string;
  domain: 'AI_ALGORITHMS' | 'SYSTEMS_SOFTWARE' | 'HARDWARE_SILICON' | 'INFRASTRUCTURE_PHYSICS' | 'PRODUCT_OPERATIONS';
  whyRequired: string;
  whenRequiredStage: CompanyStage;
  prerequisiteDependency: string;
  sourcingOption: 'FOUNDER_CORE' | 'FULL_TIME_EMPLOYEE' | 'CONTRACT_SPECIALIST' | 'RESEARCH_COLLABORATOR' | 'PARTNER_VENDOR' | 'NOT_YET_NEEDED';
  hiringTrigger: string;
  persistentJustification: string;
}

export interface FinancingWorkflowStage {
  stageNumber: number;
  name: string;
  objective: string;
  primaryActor: string;
  requiredArtifacts: string[];
  diligenceCriteria: string[];
  fatalRedFlags: string[];
  exitGate: string;
}
