'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Activity, ShieldCheck, Database, Sliders } from 'lucide-react';

interface Packet {
  id: number;
  x: number;
  stage: number; // 0: UMD, 1: KMD, 2: HW_QUEUE, 3: IOMMU, 4: MOESI
  type: 'driver' | 'walk' | 'coherence';
  state: 'M' | 'O' | 'E' | 'S' | 'I' | 'WALK' | 'HIT' | 'CRB';
  label: string;
}

export const CacheCoherenceSimulation: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [submissionPressure, setSubmissionPressure] = useState(3); // Hz
  const [coherenceDomain, setCoherenceDomain] = useState<'heterogeneous' | 'unified'>('heterogeneous');
  
  // Telemetry metrics
  const [activeInflight, setActiveInflight] = useState(20);
  const [umdCredits, setUmdCredits] = useState('H:8 / D:8');
  const [translationMode, setTranslationMode] = useState('SVM Dynamic');
  
  // Packets state
  const [packets, setPackets] = useState<Packet[]>([
    { id: 12, x: 80, stage: 0, type: 'driver', state: 'M', label: 'ID:12 2000' },
    { id: 13, x: 130, stage: 0, type: 'driver', state: 'CRB', label: 'CRB' },
    { id: 14, x: 190, stage: 1, type: 'driver', state: 'E', label: 'IOCTL' },
    { id: 15, x: 250, stage: 1, type: 'driver', state: 'S', label: 'ID:15 3000' },
    { id: 16, x: 320, stage: 2, type: 'driver', state: 'E', label: 'ID:16 2000' },
    { id: 17, x: 370, stage: 2, type: 'driver', state: 'M', label: 'SLOT' },
    { id: 18, x: 440, stage: 3, type: 'walk', state: 'WALK', label: 'WALK' },
    { id: 19, x: 470, stage: 3, type: 'walk', state: 'HIT', label: 'HIT' },
    { id: 20, x: 540, stage: 4, type: 'coherence', state: 'M', label: 'ID:20 2000' },
    { id: 21, x: 580, stage: 4, type: 'coherence', state: 'O', label: 'O' },
  ]);

  const packetIdCounter = useRef(25);

  // Update telemetry based on domain
  useEffect(() => {
    if (coherenceDomain === 'heterogeneous') {
      setUmdCredits('H:8 / D:8');
      setActiveInflight(16 + submissionPressure * 2);
      setTranslationMode('SVM Dynamic');
    } else {
      setUmdCredits('H:16 / D:16');
      setActiveInflight(12 + submissionPressure);
      setTranslationMode('Unified Shared Memory (CXL)');
    }
  }, [coherenceDomain, submissionPressure]);

  // Animation packet mover loop
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setPackets((prev) => {
        // Move existing packets
        const speed = submissionPressure * 2.5;
        let updated = prev
          .map((p) => {
            const nextX = p.x + speed;
            let stage = p.stage;
            let type = p.type;
            let state = p.state;

            if (nextX < 180) {
              stage = 0;
              type = 'driver';
            } else if (nextX < 320) {
              stage = 1;
              type = 'driver';
            } else if (nextX < 440) {
              stage = 2;
              type = 'driver';
            } else if (nextX < 540) {
              stage = 3;
              type = 'walk';
              state = nextX > 480 ? 'HIT' : 'WALK';
            } else {
              stage = 4;
              type = 'coherence';
              const states: Array<'M' | 'O' | 'E' | 'S' | 'I'> = ['M', 'O', 'E', 'S', 'I'];
              state = states[p.id % states.length];
            }
            return { ...p, x: nextX, stage, type, state };
          })
          .filter((p) => p.x < 680);

        // Spawn new packet at left
        if (Math.random() < submissionPressure * 0.15) {
          packetIdCounter.current += 1;
          const newId = packetIdCounter.current;
          const states: Array<'M' | 'O' | 'E' | 'S'> = ['M', 'O', 'E', 'S'];
          updated.push({
            id: newId,
            x: 60,
            stage: 0,
            type: 'driver',
            state: states[newId % states.length],
            label: `ID:${newId}`,
          });
        }

        return updated;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isPlaying, submissionPressure]);

  return (
    <div className="space-y-6">
      {/* Description Header matching Screenshot 367 */}
      <div className="text-xs text-slate-400">
        <p className="max-w-3xl leading-relaxed">
          <strong className="text-slate-200">Cache Coherence states</strong> under varying structural workloads. Adjust the system parameters to monitor queue depths, check for memory page-fault interrupts, and see how the architecture handles workload stalls.
        </p>
      </div>

      {/* Legend directly above visual canvas */}
      <div className="flex flex-wrap items-center gap-6 text-xs text-slate-300">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-blue-500" />
          <span>UMD / KMD Driver Submission</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-amber-400" />
          <span>IOMMU Page Table Walk</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full bg-emerald-500" />
          <span>MOESI Coherence Cache Directory</span>
        </div>
      </div>

      {/* Visual Canvas matching Screenshot 367 */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-[#060a12] p-6 shadow-2xl">
        {/* Play/Pause Button */}
        <div className="absolute right-6 top-6 z-10">
          <button
            type="button"
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-700 bg-slate-800/80 text-slate-300 transition-colors hover:border-slate-500 hover:text-white"
            title={isPlaying ? 'Pause simulation' : 'Resume simulation'}
          >
            {isPlaying ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5 ml-0.5" />}
          </button>
        </div>

        {/* SVG Pipeline Canvas */}
        <div className="relative h-64 w-full">
          <svg className="h-full w-full" viewBox="0 0 740 240" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Background connection rails */}
            <path d="M 60 100 L 680 100" stroke="#1e293b" strokeWidth="6" strokeLinecap="round" />
            <path d="M 60 100 L 680 100" stroke="#0f172a" strokeWidth="2" strokeDasharray="6 6" />

            {/* Block 1: User Mode Driver (UMD) */}
            <g transform="translate(60, 60)">
              <rect width="100" height="80" rx="8" fill="#172554" stroke="#2563eb" strokeWidth="1.5" opacity="0.9" />
              <text x="50" y="24" textAnchor="middle" fill="#93c5fd" fontSize="11" fontWeight="700">User Mode Driver</text>
              <rect x="15" y="38" width="70" height="20" rx="4" fill="#1e3a8a" stroke="#3b82f6" strokeWidth="1" />
              <text x="50" y="52" textAnchor="middle" fill="#bfdbfe" fontSize="10" fontFamily="monospace">UMD Ring Buf</text>
            </g>

            {/* Block 2: Kernel Driver (KMD) */}
            <g transform="translate(180, 60)">
              <rect width="100" height="80" rx="8" fill="#172554" stroke="#2563eb" strokeWidth="1.5" opacity="0.9" />
              <text x="50" y="24" textAnchor="middle" fill="#93c5fd" fontSize="11" fontWeight="700">Kernel Driver</text>
              <rect x="10" y="38" width="80" height="20" rx="4" fill="#1e3a8a" stroke="#3b82f6" strokeWidth="1" />
              <text x="50" y="52" textAnchor="middle" fill="#bfdbfe" fontSize="9" fontFamily="monospace">Doorbell / IOCTL</text>
            </g>

            {/* Block 3: Hardware Queue */}
            <g transform="translate(300, 60)">
              <rect width="100" height="80" rx="8" fill="#042f2e" stroke="#0d9488" strokeWidth="1.5" opacity="0.9" />
              <text x="50" y="24" textAnchor="middle" fill="#5eead4" fontSize="11" fontWeight="700">Hardware Queue</text>
              <rect x="10" y="38" width="80" height="20" rx="4" fill="#134e4a" stroke="#14b8a6" strokeWidth="1" />
              <text x="50" y="52" textAnchor="middle" fill="#ccfbf1" fontSize="9" fontFamily="monospace">Global Compute</text>
            </g>

            {/* Block 4: IOMMU Stage 1/2 */}
            <g transform="translate(420, 80)">
              <rect width="90" height="90" rx="8" fill="#451a03" stroke="#d97706" strokeWidth="1.5" opacity="0.9" />
              <text x="45" y="24" textAnchor="middle" fill="#fde68a" fontSize="10" fontWeight="700">IOMMU Stage 1/2</text>
              <text x="45" y="44" textAnchor="middle" fill="#fef3c7" fontSize="9" fontFamily="monospace">Page Walkers</text>
              <text x="45" y="60" textAnchor="middle" fill="#f59e0b" fontSize="8" fontFamily="monospace">(WALK)</text>
              <text x="45" y="74" textAnchor="middle" fill="#10b981" fontSize="8" fontFamily="monospace">(HIT)</text>
            </g>

            {/* Block 5: MOESI Directory */}
            <g transform="translate(530, 110)">
              <rect width="100" height="90" rx="8" fill="#064e3b" stroke="#059669" strokeWidth="1.5" opacity="0.9" />
              <text x="50" y="24" textAnchor="middle" fill="#a7f3d0" fontSize="11" fontWeight="700">MOESI Directory</text>
              <text x="50" y="46" textAnchor="middle" fill="#6ee7b7" fontSize="10" fontFamily="monospace">Cache Fabric</text>
              <rect x="15" y="58" width="70" height="18" rx="4" fill="#065f46" />
              <text x="50" y="71" textAnchor="middle" fill="#d1fae5" fontSize="9" fontFamily="monospace">M O E S I</text>
            </g>

            {/* Dynamic Animated Tokens */}
            {packets.map((pkt) => {
              let circleColor = '#3b82f6';
              let textColor = '#ffffff';

              if (pkt.type === 'walk') {
                circleColor = pkt.state === 'HIT' ? '#10b981' : '#f59e0b';
              } else if (pkt.type === 'coherence') {
                if (pkt.state === 'M') circleColor = '#ef4444';
                else if (pkt.state === 'O') circleColor = '#f97316';
                else if (pkt.state === 'E') circleColor = '#3b82f6';
                else if (pkt.state === 'S') circleColor = '#10b981';
                else circleColor = '#64748b';
              }

              // Y coordinate aligns with rail or drops into IOMMU/Directory
              let y = 100;
              if (pkt.stage === 3) y = 125;
              if (pkt.stage === 4) y = 155;

              return (
                <g key={pkt.id} transform={`translate(${pkt.x}, ${y})`}>
                  <circle r="11" fill={circleColor} stroke="#ffffff" strokeWidth="1.5" />
                  <text
                    x="0"
                    y="3.5"
                    textAnchor="middle"
                    fill={textColor}
                    fontSize="9"
                    fontWeight="800"
                    fontFamily="monospace"
                  >
                    {pkt.state}
                  </text>
                  <text
                    x="0"
                    y="-14"
                    textAnchor="middle"
                    fill="#94a3b8"
                    fontSize="8"
                    fontFamily="monospace"
                  >
                    {pkt.label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Metrics Bar below canvas (matching Screenshot 367) */}
        <div className="mt-4 grid grid-cols-3 gap-4 border-t border-slate-800/80 pt-5 text-center">
          <div>
            <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400">UMD Credits</p>
            <p className="mt-1 font-mono text-base font-semibold text-slate-100">{umdCredits}</p>
          </div>
          <div>
            <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400">Active Inflight</p>
            <p className="mt-1 font-mono text-base font-semibold text-blue-400">{activeInflight} Jobs</p>
          </div>
          <div>
            <p className="text-[11px] font-medium uppercase tracking-wider text-slate-400">Translation</p>
            <p className="mt-1 font-mono text-base font-semibold text-emerald-400">{translationMode}</p>
          </div>
        </div>
      </div>

      {/* System Controls (matching Screenshot 367) */}
      <div className="rounded-2xl border border-slate-800 bg-[#060a12] p-6 shadow-xl space-y-6">
        {/* Job Submission Pressure Slider */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-300">
            <span>Job Submission Pressure</span>
            <span className="font-mono text-sm text-blue-400">{submissionPressure} Hz</span>
          </div>
          <input
            type="range"
            min={1}
            max={10}
            step={1}
            value={submissionPressure}
            onChange={(e) => setSubmissionPressure(Number(e.target.value))}
            className="h-2 w-full cursor-pointer appearance-none rounded-lg bg-slate-800 accent-blue-500"
          />
        </div>

        {/* Hardware Coherence Domain Toggle Buttons */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-300">
            Hardware Coherence Domain
          </label>
          <div className="mt-3 flex rounded-xl border border-slate-700 bg-slate-900/90 p-1">
            <button
              type="button"
              onClick={() => setCoherenceDomain('heterogeneous')}
              className={`flex-1 rounded-lg py-2.5 text-xs font-semibold transition-all ${
                coherenceDomain === 'heterogeneous'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Heterogeneous
            </button>
            <button
              type="button"
              onClick={() => setCoherenceDomain('unified')}
              className={`flex-1 rounded-lg py-2.5 text-xs font-semibold transition-all ${
                coherenceDomain === 'unified'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Unified SVM
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
