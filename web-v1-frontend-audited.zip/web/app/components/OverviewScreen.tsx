'use client';

import React from 'react';
import {
  Activity,
  ArrowRight,
  CheckCircle2,
  Cpu,
  HardDrive,
  Layers,
  RefreshCw,
  Server,
  ShieldCheck,
  TrendingUp,
  XCircle,
} from 'lucide-react';

type BackendCapability = {
  status?: string;
  execution_allowed?: boolean;
  device_detected?: boolean;
  reason?: string;
};

type Capability = {
  operation: string;
  backends: Record<string, BackendCapability>;
};

interface OverviewScreenProps {
  backendStatus: {
    connected: boolean;
    mode: string;
    durability: string;
    backend_origin?: string;
    detail: string;
  } | null;
  capabilities: Capability[];
  capabilityError?: string;
  historyStats: {
    total: number;
    succeeded: number;
    failed: number;
    ratio: number;
  };
  onNavigate: (view: 'overview' | 'workspace' | 'plan' | 'run-details' | 'benchmarks' | 'engineering' | 'hardware') => void;
  onRefresh: () => void;
}

function backendSummary(capabilities: Capability[], aliases: string[]) {
  const entries = capabilities.flatMap(capability =>
    Object.entries(capability.backends ?? {})
      .filter(([name]) => aliases.includes(name.toLowerCase()))
      .map(([name, value]) => ({ name, value })),
  );
  if (!entries.length) return { label: 'Not exposed', detail: 'No matching backend is listed in the current V1 capability registry.', allowed: false, known: false };
  const allowed = entries.filter(entry => entry.value.execution_allowed === true);
  if (allowed.length) return {
    label: 'Eligible by contract',
    detail: `${[...new Set(allowed.map(entry => entry.name))].join(', ')} is allowed for ${allowed.length} listed operation${allowed.length === 1 ? '' : 's'}. This is eligibility, not a performance claim.`,
    allowed: true,
    known: true,
  };
  const reason = entries.find(entry => entry.value.reason)?.value.reason;
  return {
    label: entries.some(entry => entry.value.status === 'EXPERIMENTAL') ? 'Gated / unvalidated' : 'Not executable',
    detail: reason ?? 'The registry does not currently permit execution on this backend.',
    allowed: false,
    known: true,
  };
}

export const OverviewScreen: React.FC<OverviewScreenProps> = ({
  backendStatus,
  capabilities,
  capabilityError,
  historyStats,
  onNavigate,
  onRefresh,
}) => {
  const cpu = backendSummary(capabilities, ['cpu', 'native_cpp', 'vector_simd']);
  const gpu = backendSummary(capabilities, ['gpu', 'cuda', 'rocm', 'triton']);
  const tpu = backendSummary(capabilities, ['tpu', 'xla']);

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-blue-900/40 bg-blue-950/20 p-5 text-sm text-blue-100 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 rounded bg-blue-500/20 p-2 text-blue-300"><ShieldCheck className="h-5 w-5" /></div>
          <div>
            <div className="flex flex-wrap items-center gap-2 font-semibold">
              <span>BOYKA intelligent-computing system</span>
              <span className="rounded bg-blue-900/70 px-2 py-0.5 font-mono text-[10px] text-blue-200">V1 product · V2 presilicon path</span>
            </div>
            <p className="mt-1 max-w-5xl leading-relaxed text-slate-300">
              Workload contract → capability and policy checks → eligible runtime selection → execution → verification → receipt. CPU, GPU, TPU, provider models, and hardware design are separate resource paths; a resource is shown as usable only when the current BOYKA capability contract allows it.
            </p>
          </div>
        </div>
      </section>

      <section aria-label="Live product status" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400"><span>Execution service</span><Server className="h-4 w-4" /></div>
          <div className="mt-2 text-lg font-bold text-white">{backendStatus ? (backendStatus.connected ? 'Connected' : 'Degraded fallback') : 'Checking'}</div>
          <div className="mt-1 text-xs text-slate-400">{backendStatus?.durability ? `Persistence: ${backendStatus.durability}` : 'Service and persistence status not yet reported.'}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400"><span>Recorded run outcomes</span><Activity className="h-4 w-4" /></div>
          <div className="mt-2 text-lg font-bold text-white">{historyStats.total ? `${historyStats.succeeded} accepted / ${historyStats.total} recent` : 'No run history'}</div>
          <div className="mt-1 text-xs text-slate-400">{historyStats.total ? `${historyStats.failed} not accepted in the recent window` : 'No success rate is inferred before real executions are recorded.'}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400"><span>Accepted-run ratio</span><ShieldCheck className="h-4 w-4" /></div>
          <div className="mt-2 text-lg font-bold text-white">{historyStats.total ? `${historyStats.ratio}%` : '—'}</div>
          <div className="mt-1 text-xs text-slate-400">{historyStats.total ? 'Derived from the recent persisted run list.' : 'Unavailable until run history exists.'}</div>
        </div>
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-4">
          <div className="flex items-center justify-between text-xs text-slate-400"><span>Queue and latency</span><TrendingUp className="h-4 w-4" /></div>
          <div className="mt-2 text-lg font-bold text-white">Not reported</div>
          <div className="mt-1 text-xs text-slate-400">No live queue-depth or latency telemetry is exposed to this view.</div>
        </div>
      </section>

      <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h2 className="flex items-center gap-2 text-base font-semibold text-white"><HardDrive className="h-4 w-4 text-blue-400" />Heterogeneous resource eligibility</h2>
            <p className="mt-0.5 text-xs text-slate-400">Live summary of the authoritative V1 compute capability contract, not a device benchmark.</p>
          </div>
          <button onClick={onRefresh} className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs text-slate-300 transition hover:bg-slate-700">
            <RefreshCw className="h-3.5 w-3.5" />Refresh status
          </button>
        </div>
        {capabilityError ? <p role="status" className="mt-4 rounded-lg border border-amber-800/70 bg-amber-950/30 p-3 text-xs text-amber-200">Capability registry unavailable: {capabilityError}</p> : null}
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {[
            { title: 'CPU and native runtime', icon: Cpu, summary: cpu, accent: 'text-blue-300' },
            { title: 'GPU runtimes', icon: Server, summary: gpu, accent: 'text-emerald-300' },
            { title: 'TPU / XLA runtime', icon: Layers, summary: tpu, accent: 'text-violet-300' },
          ].map(({ title, icon: Icon, summary, accent }) => (
            <article key={title} className="rounded-lg border border-slate-800 bg-slate-950/60 p-4">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-semibold text-white">{title}</h3>
                {summary.allowed ? <CheckCircle2 className={`h-4 w-4 ${accent}`} /> : <XCircle className="h-4 w-4 text-slate-500" />}
              </div>
              <p className={`mt-2 text-xs font-semibold ${summary.allowed ? accent : 'text-amber-300'}`}>{capabilities.length ? summary.label : 'Waiting for registry'}</p>
              <p className="mt-1 text-xs leading-relaxed text-slate-400">{summary.detail}</p>
            </article>
          ))}
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
          Provider-hosted models are remote services, not local accelerator devices. FPGA/ASIC design validation is tracked separately in Hardware Engineering. Discovery or eligibility alone does not establish execution, speedup, energy, or cost.
        </p>
      </section>

      <section>
        <h2 className="mb-3 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">Product and engineering paths</h2>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {[
            { title: 'Compute workspace', icon: Cpu, view: 'workspace' as const, text: 'Submit a registry-supported workload, inspect the selected backend, verifier outcome, and durable receipt.' },
            { title: 'Execution plan', icon: Layers, view: 'plan' as const, text: 'Inspect the supported graph-planning path. Simulated planning views are labelled separately from executed runs.' },
            { title: 'Run details', icon: Server, view: 'run-details' as const, text: 'Review actual run status, execution provenance, verification, and receipt evidence.' },
            { title: 'Benchmarks', icon: TrendingUp, view: 'benchmarks' as const, text: 'Compare only recorded runs and reproducible baselines; no advantage is assumed.' },
            { title: 'Engineering portal', icon: HardDrive, view: 'engineering' as const, text: 'Review architecture decisions, evidence, and current software and hardware gates.' },
            { title: 'Hardware engineering', icon: Layers, view: 'hardware' as const, text: 'Inspect RTL and presilicon work; simulation, FPGA, physical design, and silicon remain distinct gates.' },
          ].map(({ title, icon: Icon, view, text }) => (
            <button key={view} type="button" onClick={() => onNavigate(view)} className="group rounded-xl border border-slate-800 bg-slate-900/60 p-5 text-left transition hover:border-blue-500/50 hover:bg-slate-900">
              <div className="flex items-center justify-between"><span className="rounded-lg bg-blue-500/10 p-2.5 text-blue-400"><Icon className="h-5 w-5" /></span><ArrowRight className="h-4 w-4 text-slate-500 transition group-hover:translate-x-1 group-hover:text-blue-400" /></div>
              <h3 className="mt-3 text-sm font-semibold capitalize text-white">{title}</h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-400">{text}</p>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};
