'use client';

import React, { useState } from 'react';
import { FileText, CheckCircle2, AlertTriangle, Copy, Download, Cpu, ShieldCheck, History, Search } from 'lucide-react';

export interface RunDetailsRecord {
  run_id: string;
  operation: string;
  status: string;
  backend?: string | null;
  actual_backend?: string;
  execution_mode?: string;
  persistence_status?: string;
  request?: unknown;
  output?: unknown;
  plan?: unknown;
  verification?: {
    status?: string;
    verifier_id?: string;
    independent?: boolean;
    reason?: string;
  };
  persistence?: {
    durability?: string;
    store?: string;
    warning?: string;
  };
  receipt?: Record<string, unknown>;
  receipt_sha256?: string | null;
  source_revision?: string;
  duration_ms?: number | null;
  created_at?: string;
  updated_at?: string;
}

interface RunDetailsScreenProps {
  currentRun: RunDetailsRecord | null;
  allRuns: RunDetailsRecord[];
  onSelectRun: (runId: string) => void;
  onDownloadReceipt: (run: RunDetailsRecord) => void;
}

function evidenceValue(value: unknown): string {
  if (value === undefined) return 'UNDEFINED (field not present in API response)';
  if (value === null) return 'NULL (explicitly set to null in API response)';
  if (value === '') return 'EMPTY_STRING (explicitly set to empty string in API response)';
  return typeof value === 'string' ? value : JSON.stringify(value, null, 2);
}

export const RunDetailsScreen: React.FC<RunDetailsScreenProps> = ({ currentRun, allRuns, onSelectRun, onDownloadReceipt }) => {
  const [copyStatus, setCopyStatus] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const displayRun = currentRun || allRuns[0] || null;
  const filteredRuns = allRuns.filter(run => run.run_id.toLowerCase().includes(searchTerm.toLowerCase()) || run.operation.toLowerCase().includes(searchTerm.toLowerCase()));

  const copyRunId = async (runId: string) => {
    await navigator.clipboard.writeText(runId);
    setCopyStatus('Run ID copied');
    setTimeout(() => setCopyStatus(''), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2"><FileText className="h-5 w-5 text-blue-400" />Execution Run Details & Evidence</h1>
          <p className="text-xs text-slate-400 mt-1">Values below come from the stored execution record. Missing measurements and provenance are shown as not reported.</p>
        </div>
        {displayRun && <button onClick={() => onDownloadReceipt(displayRun)} className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 transition"><Download className="h-3.5 w-3.5 text-blue-400" />Download Retrieved Record</button>}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        {displayRun ? (
          <div className="space-y-5">
            <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
                <div>
                  <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500">Execution Run ID</div>
                  <div className="flex items-center gap-2 mt-0.5"><span className="font-mono text-base font-semibold text-white">{displayRun.run_id}</span><button onClick={() => void copyRunId(displayRun.run_id)} className="text-slate-500 hover:text-slate-300 p-1" title="Copy Run ID"><Copy className="h-3.5 w-3.5" /></button>{copyStatus && <span className="text-[10px] text-emerald-400">{copyStatus}</span>}</div>
                </div>
                <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold ${displayRun.status === 'SUCCEEDED' ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/80' : 'bg-amber-950/80 text-amber-300 border border-amber-800/80'}`}>
                  {displayRun.status === 'SUCCEEDED' ? <CheckCircle2 className="h-3.5 w-3.5" /> : <AlertTriangle className="h-3.5 w-3.5" />}{displayRun.status}
                </span>
              </div>

              <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-4 text-xs font-mono">
                {[
                  ['Operation', displayRun.operation],
                  ['Actual Backend', displayRun.actual_backend || displayRun.backend],
                  ['Persistence', displayRun.persistence_status || displayRun.persistence?.durability],
                  ['Source Revision', displayRun.source_revision],
                  ['Execution Duration (ms)', displayRun.duration_ms],
                  ['Execution Mode', displayRun.execution_mode],
                  ['Created At', displayRun.created_at],
                  ['Updated At', displayRun.updated_at],
                ].map(([label, value]) => <div key={String(label)} className="rounded-lg bg-slate-950/60 p-3 border border-slate-800/80"><span className="text-slate-500 block text-[11px]">{label}:</span><span className="text-slate-200 font-medium mt-0.5 block break-all">{evidenceValue(value)}</span></div>)}
              </div>
            </section>

            <div className="grid gap-5 md:grid-cols-2">
              <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2"><Cpu className="h-4 w-4 text-blue-400" />Recorded Request & Output</h3>
                <div><div className="text-[10px] uppercase text-slate-500 mb-1">Request</div><pre className="max-h-48 overflow-auto rounded-lg bg-slate-950 p-3 text-xs font-mono text-slate-300 border border-slate-800/80">{evidenceValue(displayRun.request)}</pre></div>
                <div><div className="text-[10px] uppercase text-slate-500 mb-1">Output</div><pre className="max-h-48 overflow-auto rounded-lg bg-slate-950 p-3 text-xs font-mono text-slate-300 border border-slate-800/80">{evidenceValue(displayRun.output)}</pre></div>
              </section>

              <section className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 space-y-3">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-blue-400" />Verification Evidence</h3>
                <div className="space-y-2 text-xs font-mono">
                  {[
                    ['Status', displayRun.verification?.status],
                    ['Verifier ID', displayRun.verification?.verifier_id],
                    ['Independent', displayRun.verification?.independent],
                    ['Reason', displayRun.verification?.reason],
                    ['Receipt SHA-256', displayRun.receipt_sha256],
                  ].map(([label, value]) => <div key={String(label)} className="border-b border-slate-800 pb-1.5"><span className="text-slate-500">{label}: </span><span className="text-slate-200 break-all">{evidenceValue(value)}</span></div>)}
                </div>
                <div><div className="text-[10px] uppercase text-slate-500 mb-1">Plan</div><pre className="max-h-40 overflow-auto rounded-lg bg-slate-950 p-3 text-xs font-mono text-slate-300 border border-slate-800/80">{evidenceValue(displayRun.plan)}</pre></div>
                <div><div className="text-[10px] uppercase text-slate-500 mb-1">Persisted Receipt</div><pre className="max-h-56 overflow-auto rounded-lg bg-slate-950 p-3 text-xs font-mono text-slate-300 border border-slate-800/80">{evidenceValue(displayRun.receipt)}</pre></div>
              </section>
            </div>
          </div>
        ) : <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-12 text-center text-slate-400">No execution runs were returned by the BOYKA API.</div>}

        <aside className="rounded-xl border border-slate-800 bg-slate-900/70 p-4 flex flex-col space-y-4">
          <div className="flex items-center justify-between"><h3 className="text-sm font-semibold text-white flex items-center gap-2"><History className="h-4 w-4 text-slate-400" />Run History</h3><span className="text-xs font-mono text-slate-500">{allRuns.length} runs</span></div>
          <div className="relative"><Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-500" /><input type="text" placeholder="Search by ID or Op..." value={searchTerm} onChange={event => setSearchTerm(event.target.value)} className="w-full rounded-lg border border-slate-800 bg-slate-950 pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500" /></div>
          <div className="space-y-2 overflow-y-auto max-h-[580px] pr-1">
            {filteredRuns.map(run => <button key={run.run_id} type="button" onClick={() => onSelectRun(run.run_id)} className={`w-full text-left rounded-lg border p-3 transition ${displayRun?.run_id === run.run_id ? 'border-blue-500 bg-blue-950/30' : 'border-slate-800 bg-slate-950/50 hover:border-slate-700 hover:bg-slate-950'}`}>
              <div className="flex items-center justify-between text-xs"><span className="font-mono font-medium text-slate-200">{run.run_id.slice(0, 10)}…</span><span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${run.status === 'SUCCEEDED' ? 'bg-emerald-950 text-emerald-300' : 'bg-amber-950 text-amber-300'}`}>{run.status}</span></div>
              <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400"><span className="truncate max-w-[180px]">{run.operation}</span><span className="text-slate-500 font-mono">{evidenceValue(run.backend || run.actual_backend)}</span></div>
            </button>)}
          </div>
        </aside>
      </div>
    </div>
  );
};
