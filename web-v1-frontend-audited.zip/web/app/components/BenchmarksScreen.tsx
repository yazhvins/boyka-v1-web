'use client';

import React from 'react';
import { BarChart2, ShieldAlert, Clock } from 'lucide-react';

export const BenchmarksScreen: React.FC = () => (
  <section className="space-y-5" aria-labelledby="benchmark-evidence-title">
    <header className="flex items-start gap-3 border-b border-slate-800 pb-4">
      <BarChart2 className="mt-1 h-5 w-5 text-blue-400" aria-hidden="true" />
      <div>
        <h2 id="benchmark-evidence-title" className="text-lg font-semibold text-white">Benchmark evidence</h2>
        <p className="mt-1 text-sm text-slate-400">
          This page shows only reproducible benchmark records. It does not generate sample timings or simulated results.
        </p>
      </div>
    </header>

    <div className="rounded-xl border border-amber-800/70 bg-amber-950/30 p-4 text-sm text-amber-100" role="status">
      <div className="flex items-start gap-3">
        <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" aria-hidden="true" />
        <div>
          <h3 className="font-semibold">No current benchmark run is connected to this screen</h3>
          <p className="mt-1 text-amber-100/80">
            The benchmark API is not implemented in the service yet. Run the repository benchmark workflow and attach its
            raw result, workload identity, environment, verification outcomes, and source hash before presenting measurements here.
          </p>
        </div>
      </div>
    </div>

    <article className="rounded-xl border border-slate-800 bg-slate-900/70 p-5">
      <div className="flex items-center gap-2 text-slate-200">
        <Clock className="h-4 w-4 text-blue-300" aria-hidden="true" />
        <h3 className="font-semibold">Prior adaptive-compute result</h3>
      </div>
      <p className="mt-3 text-sm font-semibold text-amber-300">BASELINE_WINS — REQUIRES_REPRODUCTION</p>
      <p className="mt-2 text-sm leading-6 text-slate-300">
        The preserved report describes two runs, 2,520 observations, and 384 calibration observations. B4 and C each
        reached the 99%-of-optimum threshold in 31 of 60 cases. B4 used fewer nodes on average but had worse reported
        latest latency than C. These observations are not a demonstrated adaptive-compute advantage and must be reproduced
        before they support a product or savings claim.
      </p>
      <p className="mt-3 text-xs text-slate-500">
        No GPU/TPU comparison, energy result, cost saving, or current-source benchmark is implied by this historical finding.
      </p>
    </article>
  </section>
);
