'use client';

import Link from 'next/link';
import { useCallback, useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import { ExecutionGraphSimulation } from '../components/ExecutionGraphSimulation';
import { CacheCoherenceSimulation } from '../components/CacheCoherenceSimulation';
import { OverviewScreen } from '../components/OverviewScreen';
import { ExecutionPlanScreen } from '../components/ExecutionPlanScreen';
import { RunDetailsScreen } from '../components/RunDetailsScreen';
import { BenchmarksScreen } from '../components/BenchmarksScreen';
import { EngineeringPortalScreen } from '../components/EngineeringPortalScreen';
import { HardwareEngineeringScreen } from '../components/HardwareEngineeringScreen';
import {
  GitBranch,
  Layers,
  Cpu,
  ExternalLink,
  Download,
  Calendar,
  CheckCircle2,
  XCircle,
  TrendingUp,
  FileCode,
  ArrowDownToLine,
  RefreshCw,
  FolderTree,
  ChevronDown,
  ChevronRight,
  Clock,
  Timer,
  Activity,
} from 'lucide-react';

type BackendCapability = { status: string; execution_allowed: boolean; device_detected: boolean; reason: string };
type Capability = { operation: string; operation_id: string; version: string; description: string; backends: Record<string, BackendCapability> };
type ApiError = { error?: { code?: string; message?: string; details?: unknown }; detail?: { error?: { code?: string; message?: string } } };
type RunResult = {
  run_id: string;
  operation: string;
  status: string;
  actual_backend?: string;
  execution_mode?: string;
  output?: unknown;
  plan?: unknown;
  verification?: { status?: string; verifier_id?: string; independent?: boolean; reason?: string };
  persistence?: { durability?: string; store?: string; warning?: string };
  receipt?: Record<string, unknown>;
  source_revision?: string;
  error?: { code?: string; message?: string };
};
type PersistedRun = {
  run_id: string;
  operation: string;
  status: string;
  backend?: string | null;
  execution_mode?: string;
  persistence_status?: string;
  response?: RunResult | null;
  request?: Record<string, unknown>;
  receipt_sha256?: string | null;
  duration_ms?: number | null;
  created_at?: string;
  updated_at?: string;
};
type HistoryItem = {
  run_id: string;
  operation: string;
  status: string;
  backend?: string | null;
  execution_mode?: string;
  persistence_status?: string;
  created_at: string;
  updated_at: string;
  receipt_sha256?: string | null;
  duration_ms?: number | null;
};
type BackendStatus = {
  connected: boolean;
  mode: 'AUTHORITATIVE_V1_DAEMON' | 'UPSTREAM_UNAVAILABLE';
  durability: 'DURABLE_POSTGRESQL' | 'UNAVAILABLE';
  backend_origin?: string;
  detail: string;
};

const TERMINAL = new Set(['SUCCEEDED', 'LOCAL_PROVISIONAL_UNVERIFIED', 'FAILED', 'REJECTED', 'CANCELLED', 'TIMED_OUT', 'VERIFICATION_FAILED', 'INTERRUPTED']);

function readableStatus(status?: string) {
  if (!status) return 'Not available';
  const labels: Record<string, string> = {
    SUCCEEDED: 'Completed & Verified',
    LOCAL_PROVISIONAL_UNVERIFIED: 'Provisional (Local Unverified)',
    FAILED: 'Failed',
    REJECTED: 'Rejected',
    CANCELLED: 'Cancelled',
    TIMED_OUT: 'Timed out',
    VERIFICATION_FAILED: 'Verification Failed',
    INTERRUPTED: 'Interrupted',
    QUEUED: 'Queued',
    RUNNING: 'Running',
    SUBMITTING: 'Submitting',
    TESTED: 'Tested locally',
    EXPERIMENTAL: 'Experimental (Disabled)',
    UNAVAILABLE: 'Unavailable',
    PASS: 'Passed',
    FAIL: 'Failed',
  };
  return labels[status] ?? status.toLowerCase().replaceAll('_', ' ').replace(/^\w/, letter => letter.toUpperCase());
}

function readableOperation(operation?: string) {
  if (!operation) return 'Calculation';
  const labels: Record<string, string> = {
    vector_dot: 'Vector dot product (float64)',
    dot_i16_vector: 'Integer dot product (int16/int64)',
    matmul_ones: 'All-ones matrix summary',
  };
  return labels[operation] ?? operation.replaceAll('_', ' ');
}

function operationDescription(operation?: string, description?: string) {
  if (operation === 'vector_dot') return 'Finite numeric vector dot product with independent reference recomputation.';
  if (operation === 'matmul_ones') return 'Exact summary of all-ones matrix multiplication without creating the full matrices.';
  if (operation === 'dot_i16_vector') return 'Hardware-aligned signed int16 dot product with full overflow checking.';
  return description ?? 'Calculation contract provided by BOYKA.';
}

function resultEntries(value: unknown): [string, string][] {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return [['Result', String(value)]];
  return Object.entries(value as Record<string, unknown>).map(([key, entry]) => [
    key.replaceAll('_', ' ').replace(/^\w/, letter => letter.toUpperCase()),
    typeof entry === 'string' ? entry : typeof entry === 'number' || typeof entry === 'boolean' ? String(entry) : JSON.stringify(entry),
  ]);
}

function describeError(payload: ApiError, fallback: string) {
  return payload.error?.message ?? payload.detail?.error?.message ?? payload.error?.code ?? payload.detail?.error?.code ?? fallback;
}

export default function ComputeWorkspacePage() {
  const [backendStatus, setBackendStatus] = useState<BackendStatus | null>(null);
  const [capabilities, setCapabilities] = useState<Capability[]>([]);
  const [capabilityError, setCapabilityError] = useState('');
  const [v2Capabilities, setV2Capabilities] = useState<Capability[]>([]);
  const [v2CapabilityError, setV2CapabilityError] = useState('');
  const [runtime, setRuntime] = useState<'v1' | 'v2' | 'v2-graph'>('v1');
  const [operation, setOperation] = useState<'vector_dot' | 'matmul_ones'>('vector_dot');
  const [left, setLeft] = useState('1, 2, 3');
  const [right, setRight] = useState('4, 5, 6');
  const [graphJson, setGraphJson] = useState(JSON.stringify({
    graph_id: 'customer-graph',
    operations: [{
      op_id: 'dot',
      operation: 'dot_i16_vector',
      candidate_backends: ['cpu'],
      attributes: { a: [1, 2, 3], b: [4, 5, 6] },
    }],
  }, null, 2));
  const [size, setSize] = useState('4');
  const [backendPreference, setBackendPreference] = useState<'auto' | 'cpu' | 'native_cpp' | 'vector_simd'>('auto');
  const [memoryLimit, setMemoryLimit] = useState('268435456');
  const [qualityTarget, setQualityTarget] = useState('1');
  const [latencyBudget, setLatencyBudget] = useState('10000');
  const [monetaryBudget, setMonetaryBudget] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [activeRunId, setActiveRunId] = useState('');
  const [runStatus, setRunStatus] = useState('');
  const [result, setResult] = useState<RunResult | null>(null);
  const [persisted, setPersisted] = useState<PersistedRun | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [historyError, setHistoryError] = useState('');
  const [historyBusy, setHistoryBusy] = useState(false);
  const [historyGrouping, setHistoryGrouping] = useState<'none' | 'date' | 'batch'>('date');
  const [downloadingRunId, setDownloadingRunId] = useState<string | null>(null);
  const [activeScreen, setActiveScreen] = useState<'overview' | 'workspace' | 'plan' | 'run-details' | 'benchmarks' | 'engineering' | 'hardware'>('overview');
  const [inspectedRunId, setInspectedRunId] = useState<string>('');
  const [activeView, setActiveView] = useState<'execution-graph' | 'coherence' | 'workspace'>('workspace');

  const navigateToScreen = useCallback((screen: 'overview' | 'workspace' | 'plan' | 'run-details' | 'benchmarks' | 'engineering' | 'hardware') => {
    setActiveScreen(screen);
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      url.searchParams.set('tab', screen);
      window.history.replaceState({}, '', url.toString());
    }
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const tab = params.get('tab');
      if (tab && ['overview', 'workspace', 'plan', 'run-details', 'benchmarks', 'engineering', 'hardware'].includes(tab)) {
        setActiveScreen(tab as any);
      } else if (window.location.hash) {
        const hash = window.location.hash.replace('#', '');
        if (['overview', 'workspace', 'plan', 'run-details', 'benchmarks', 'engineering', 'hardware'].includes(hash)) {
          setActiveScreen(hash as any);
        }
      }
    }
  }, []);

  const checkBackendStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/backend-status', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        setBackendStatus(data);
      }
    } catch {
      setBackendStatus({
        connected: false,
        mode: 'UPSTREAM_UNAVAILABLE',
        durability: 'UNAVAILABLE',
        detail: 'Backend status could not be checked; product execution is unavailable.',
      });
    }
  }, []);

  const refreshHistory = useCallback(async () => {
    setHistoryBusy(true);
    setHistoryError('');
    try {
      const response = await fetch('/api/compute/history?limit=50', { cache: 'no-store' });
      const body = await response.json();
      if (!response.ok) throw new Error(describeError(body, `History request failed (${response.status})`));
      setHistory(body.runs ?? []);
    } catch (err) {
      setHistoryError(err instanceof Error ? err.message : 'Execution history is unavailable.');
    } finally {
      setHistoryBusy(false);
    }
  }, []);

  const downloadJson = useCallback((filename: string, data: unknown) => {
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, []);

  const downloadItemReceipt = useCallback(async (item: HistoryItem) => {
    setDownloadingRunId(item.run_id);
    try {
      const res = await fetch(`/api/compute/runs/${item.run_id}`, { cache: 'no-store' });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(describeError(body, `Receipt request failed (${res.status})`));
      }
      downloadJson(`receipt-${item.run_id.slice(0, 8)}.json`, body);
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'the execution API could not be reached';
      // Provide synthetic receipt with available metadata when upstream is unavailable
      // NOTE: This is a SYNTHETIC receipt generated from local history metadata, NOT a real persisted receipt.
      // It explicitly reports SYNTHETIC durability to avoid misleading the user about persistence guarantees.
      // The original receipt MAY have been durably persisted in PostgreSQL but cannot be confirmed without upstream API.
      // Include available output from history if present to avoid breaking UI components.
      const syntheticReceipt = {
        run_id: item.run_id,
        operation: item.operation,
        status: item.status,
        backend: item.backend ?? 'UNKNOWN',
        execution_mode: item.execution_mode ?? 'UNKNOWN',
        output: (item as any).output ?? { note: 'Output not available in local history; re-run with upstream API for full receipt.' },
        verification: { status: 'UNAVAILABLE', verifier_id: 'none', independent: false, reason: 'Upstream API unavailable; receipt synthesized from local history metadata. NOT independently verified.' },
        persistence: { durability: 'SYNTHETIC_LOCAL_HISTORY', store: 'local-memory', warning: 'SYNTHETIC RECEIPT: Generated from local history metadata only. NOT cryptographically verified. Original receipt may have been durably persisted in PostgreSQL but cannot be confirmed without upstream API.' },
        receipt_sha256: item.receipt_sha256 ?? null,
        source_revision: 'synthetic-local-history',
        requested_at: new Date().toISOString(),
        original_created_at: item.created_at,
        original_updated_at: item.updated_at,
      };
      downloadJson(`receipt-${item.run_id.slice(0, 8)}-SYNTHETIC-NOT-VERIFIED.json`, syntheticReceipt);
      setHistoryError(`Receipt retrieval failed: ${reason}. Downloaded SYNTHETIC receipt (NOT a real persisted receipt) from local history metadata. Original durability: ${item.receipt_sha256 ? 'DURABLE_POSTGRESQL (may exist but unconfirmed)' : 'EPHEMERAL_IN_MEMORY'}.`);
    } finally {
      setDownloadingRunId(null);
    }
  }, [downloadJson]);

  const downloadAllReceipts = useCallback(() => {
    const exportPayload = {
      schema: 'boyka-execution-history-export/1',
      exported_at: new Date().toISOString(),
      total_runs: history.length,
      runs: history,
    };
    downloadJson(`boyka-history-export-${new Date().toISOString().slice(0, 10)}.json`, exportPayload);
  }, [downloadJson, history]);

  // Last 20 operations in chronological order, derived from persisted run history.
  const trendData = useMemo(() => {
    if (!history.length) return [];
    const recent = [...history].slice(0, 20).reverse();
    let succCount = 0;
    return recent.map((item, idx) => {
      const isSuccess = item.status === 'SUCCEEDED';
      if (isSuccess) succCount += 1;
      const ratio = Math.round((succCount / (idx + 1)) * 100);
      return {
        step: `#${idx + 1}`,
        runId: item.run_id.slice(0, 8),
        fullRunId: item.run_id,
        operation: readableOperation(item.operation),
        rawOperation: item.operation,
        status: item.status,
        succeeded: isSuccess ? 1 : 0,
        failed: isSuccess ? 0 : 1,
        successRatio: ratio,
        failedRatio: 100 - ratio,
        backend: item.backend ?? 'NOT_REPORTED',
        created_at: item.created_at,
      };
    });
  }, [history]);

  const trendStats = useMemo(() => {
    if (!trendData.length) return { total: 0, succeeded: 0, failed: 0, ratio: 0 };
    const total = trendData.length;
    const succeeded = trendData.filter(d => d.succeeded === 1).length;
    const failed = total - succeeded;
    const ratio = Math.round((succeeded / total) * 100);
    return { total, succeeded, failed, ratio };
  }, [trendData]);

  const currentRunRecord = useMemo(() => {
    if (result && (activeRunId === result.run_id || inspectedRunId === result.run_id)) {
      return {
        run_id: result.run_id,
        operation: result.operation,
        status: result.status,
        backend: result.actual_backend,
        actual_backend: result.actual_backend,
        execution_mode: result.execution_mode,
        persistence_status: persisted?.persistence_status,
        output: result.output,
        plan: result.plan,
        verification: result.verification,
        persistence: result.persistence,
        receipt: result.receipt,
        source_revision: result.source_revision,
        request: persisted?.request,
        duration_ms: persisted?.duration_ms,
        receipt_sha256: persisted?.receipt_sha256,
        created_at: persisted?.created_at,
        updated_at: persisted?.updated_at,
      };
    }
    const targetId = inspectedRunId || activeRunId;
    const hist = history.find(h => h.run_id === targetId);
    if (hist) {
      return {
        run_id: hist.run_id,
        operation: hist.operation,
        status: hist.status,
        backend: hist.backend,
        actual_backend: hist.backend ?? undefined,
        execution_mode: hist.execution_mode,
        persistence_status: hist.persistence_status,
        duration_ms: hist.duration_ms,
        receipt_sha256: hist.receipt_sha256,
        created_at: hist.created_at,
        updated_at: hist.updated_at,
      };
    }
    if (history.length > 0) {
      const first = history[0];
      return {
        run_id: first.run_id,
        operation: first.operation,
        status: first.status,
        backend: first.backend,
        actual_backend: first.backend ?? undefined,
        execution_mode: first.execution_mode,
        persistence_status: first.persistence_status,
        duration_ms: first.duration_ms,
        receipt_sha256: first.receipt_sha256,
        created_at: first.created_at,
        updated_at: first.updated_at,
      };
    }
    return null;
  }, [result, activeRunId, inspectedRunId, history, persisted]);

  const getItemDurationMs = useCallback((item: HistoryItem): number | null => {
    // First try explicit duration_ms
    if (typeof item.duration_ms === 'number' && Number.isFinite(item.duration_ms) && item.duration_ms >= 0) {
      return item.duration_ms;
    }
    // Fallback: infer from created_at and updated_at timestamps
    if (item.created_at && item.updated_at) {
      try {
        const created = new Date(item.created_at).getTime();
        const updated = new Date(item.updated_at).getTime();
        if (!isNaN(created) && !isNaN(updated) && updated >= created) {
          return updated - created;
        }
      } catch {
        // Ignore parse errors
      }
    }
    return null;
  }, []);

  const formatDuration = useCallback((ms: number | null): string => {
    if (ms === null) return '—';
    if (!Number.isFinite(ms) || ms < 0) return 'INVALID';
    if (ms < 1) return `${(ms * 1000).toFixed(0)} µs`;
    if (ms < 1000) return `${ms.toFixed(1)} ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(2)} s`;
    return `${(ms / 60000).toFixed(1)} min`;
  }, []);

  // Grouped history by Date or Batch / Operation with comprehensive duration statistics
  const groupedHistory = useMemo(() => {
    if (historyGrouping === 'none') return null;

    type GroupRecord = {
      label: string;
      dateSortKey?: string;
      items: HistoryItem[];
      succeededCount: number;
      failedCount: number;
      totalRuns: number;
      successPercentage: number;
      totalDurationMs: number;
      avgDurationMs: number;
      minDurationMs: number | null;
      maxDurationMs: number | null;
      durations: number[];
    };

    const groups: Record<string, GroupRecord> = {};

    for (const item of history) {
      let groupKey = '';
      let groupLabel = '';
      if (historyGrouping === 'date') {
        try {
          const d = new Date(item.created_at);
          if (isNaN(d.getTime())) {
            groupKey = 'undated';
            groupLabel = 'Recorded Operations';
          } else {
            const todayStr = new Date().toISOString().slice(0, 10);
            const dateStr = d.toISOString().slice(0, 10);
            groupKey = dateStr;
            if (dateStr === todayStr) {
              groupLabel = `Today (${dateStr})`;
            } else {
              groupLabel = d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
            }
          }
        } catch {
          groupKey = 'undated';
          groupLabel = 'Recorded Operations';
        }
      } else {
        // Group by operation / batch
        groupKey = item.operation || 'unknown';
        groupLabel = readableOperation(item.operation);
      }

      if (!groups[groupKey]) {
        groups[groupKey] = {
          label: groupLabel,
          dateSortKey: groupKey,
          items: [],
          succeededCount: 0,
          failedCount: 0,
          totalRuns: 0,
          successPercentage: 0,
          totalDurationMs: 0,
          avgDurationMs: 0,
          minDurationMs: null,
          maxDurationMs: null,
          durations: [],
        };
      }
      groups[groupKey].items.push(item);
      const dur = getItemDurationMs(item);
      if (dur !== null) groups[groupKey].durations.push(dur);
      if (item.status === 'SUCCEEDED') groups[groupKey].succeededCount += 1;
      else groups[groupKey].failedCount += 1;
    }

    // Compute duration statistics and success percentage for each group
    for (const g of Object.values(groups)) {
      g.totalRuns = g.items.length;
      g.successPercentage = g.totalRuns > 0 ? Math.round((g.succeededCount / g.totalRuns) * 100) : 0;
      g.totalDurationMs = g.durations.reduce((acc, v) => acc + v, 0);
      g.avgDurationMs = g.durations.length > 0 ? g.totalDurationMs / g.durations.length : 0;
      g.minDurationMs = g.durations.length > 0 ? Math.min(...g.durations) : null;
      g.maxDurationMs = g.durations.length > 0 ? Math.max(...g.durations) : null;
    }

    return Object.values(groups).sort((a, b) => {
      if (a.dateSortKey && b.dateSortKey) return b.dateSortKey.localeCompare(a.dateSortKey);
      return a.label.localeCompare(b.label);
    });
  }, [history, historyGrouping, getItemDurationMs]);

  useEffect(() => {
    void checkBackendStatus();
  }, [checkBackendStatus]);

  useEffect(() => {
    let active = true;
    fetch('/api/compute/capabilities', { cache: 'no-store' })
      .then(async response => {
        const body = await response.json();
        if (!response.ok) throw new Error(describeError(body, 'Capability service unavailable'));
        return body;
      })
      .then(body => { if (active) setCapabilities(body.operations ?? []); })
      .catch(err => { if (active) setCapabilityError(err instanceof Error ? err.message : 'Capability service unavailable'); });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    let active = true;
    fetch('/api/compute/v2/capabilities', { cache: 'no-store' })
      .then(async response => {
        const body = await response.json();
        if (!response.ok) throw new Error(describeError(body, 'V2 capability service unavailable'));
        return body;
      })
      .then(body => { if (active) setV2Capabilities(body.operations ?? []); })
      .catch(err => { if (active) setV2CapabilityError(err instanceof Error ? err.message : 'V2 capability service unavailable'); });
    return () => { active = false; };
  }, []);

  useEffect(() => { void refreshHistory(); }, [refreshHistory]);

  const selectedCapability = useMemo(() => capabilities.find(item => item.operation === operation), [capabilities, operation]);
  const selectedV2Capability = useMemo(() => v2Capabilities.find(item => item.operation === 'dot_i16_vector'), [v2Capabilities]);
  const visibleCapabilities = runtime === 'v1' ? capabilities : v2Capabilities;

  async function loadRun(runId: string) {
    const response = await fetch(`/api/compute/runs/${runId}`, { cache: 'no-store' });
    const body = await response.json();
    if (!response.ok) throw new Error(describeError(body, `Could not reload run (${response.status})`));
    const row = body as PersistedRun;
    setActiveRunId(runId);
    setRunStatus(row.status);
    setPersisted(row);
    if (row.response && row.response.run_id) setResult(row.response);
    await refreshHistory();
    return row;
  }

  async function openHistory(runId: string) {
    setError('');
    setInspectedRunId(runId);
    setActiveRunId(runId);
    try {
      await loadRun(runId);
      setActiveScreen('run-details');
    }
    catch (err) { setError(err instanceof Error ? err.message : 'Could not open the stored run.'); }
  }

  async function cancelActiveRun() {
    if (!activeRunId || runStatus !== 'QUEUED') return;
    setError('');
    try {
      const response = await fetch(`/api/compute/runs/${activeRunId}/cancel`, { method: 'POST', cache: 'no-store' });
      const body = await response.json();
      if (!response.ok) throw new Error(describeError(body, `Cancellation request failed (${response.status})`));
      await loadRun(activeRunId);
    } catch (err) { setError(err instanceof Error ? err.message : 'Cancellation failed.'); }
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError('');
    setResult(null);
    setPersisted(null);
    setRunStatus('SUBMITTING');
    setActiveRunId('');

    let requestBody: Record<string, unknown>;
    let apiPath: string;

    if (runtime === 'v2-graph') {
      let graph: Record<string, unknown>;
      try { graph = JSON.parse(graphJson) as Record<string, unknown>; }
      catch { setError('Graph must be valid JSON.'); setBusy(false); setRunStatus(''); return; }
      if (!graph || typeof graph !== 'object' || Array.isArray(graph) || !Array.isArray(graph.operations) || graph.operations.length < 1 || graph.operations.length > 64) {
        setError('Graph must be a JSON object with 1–64 operations. Authoritative schema validation is enforced.'); setBusy(false); setRunStatus(''); return;
      }
      const quality = Number(qualityTarget), deadline = Number(latencyBudget);
      if (quality !== 1 || !Number.isFinite(deadline) || deadline <= 0 || deadline > 600000) {
        setError('V2 graph currently enforces exact correctness (quality target 1.0); deadline must be in (0, 600000] ms.'); setBusy(false); setRunStatus(''); return;
      }
      const budget = monetaryBudget.trim() === '' ? undefined : Number(monetaryBudget);
      if (budget !== undefined && (!Number.isFinite(budget) || budget < 0 || budget > 10000)) {
        setError('Monetary budget must be blank when trusted pricing is unavailable.'); setBusy(false); setRunStatus(''); return;
      }
      const memory = Number(memoryLimit);
      if (!Number.isSafeInteger(memory) || memory < 4096 || memory > 1099511627776) {
        setError('V2 graph estimated-memory limit must be at least 4096 bytes and at most 1 TiB.'); setBusy(false); setRunStatus(''); return;
      }
      requestBody = { graph, allowed_backends: ['cpu'], quality_target: quality, latency_budget_ms: deadline, max_memory_bytes: memory, ...(budget === undefined ? {} : { monetary_budget_usd: budget }) };
      apiPath = '/api/compute/v2/graph/jobs';
    } else if (runtime === 'v2') {
      const a = left.split(',').map(part => Number(part.trim()));
      const b = right.split(',').map(part => Number(part.trim()));
      const valid = (values: number[]) => values.length >= 1 && values.length <= 256 && values.every(value => Number.isInteger(value) && value >= -32768 && value <= 32767);
      if (!valid(a) || !valid(b) || a.length !== b.length) {
        setError('V2 requires equal-length vectors of 1–256 signed int16 integers (-32768 through 32767).'); setBusy(false); setRunStatus(''); return;
      }
      const quality = Number(qualityTarget), deadline = Number(latencyBudget);
      if (quality !== 1 || !Number.isFinite(deadline) || deadline <= 0 || deadline > 600000) {
        setError('The V2 integer graph runtime enforces exact correctness (quality target 1.0); deadline must be in (0, 600000] ms.'); setBusy(false); setRunStatus(''); return;
      }
      const budget = monetaryBudget.trim() === '' ? undefined : Number(monetaryBudget);
      const limits: Record<string, unknown> = { quality_target: quality, latency_budget_ms: deadline };
      if (budget !== undefined) limits.monetary_budget_usd = budget;
      const memory = Number(memoryLimit);
      if (!Number.isSafeInteger(memory) || memory < 1 || memory > 1099511627776) {
        setError('Logical memory limit must be a positive integer up to 1 TiB.'); setBusy(false); setRunStatus(''); return;
      }
      limits.max_memory_bytes = memory;
      const v2Allowed = backendPreference === 'auto'
        ? ['cpu', 'native_cpp']
        : [backendPreference === 'vector_simd' ? 'cpu' : backendPreference];
      requestBody = {
        operation: 'dot_i16_vector',
        a,
        b,
        allowed_backends: v2Allowed,
        ...(backendPreference !== 'auto' && backendPreference !== 'vector_simd' ? { preferred_backend: backendPreference } : {}),
        ...limits,
      };
      apiPath = '/api/compute/v2/jobs';
    } else {
      let payload: Record<string, unknown>;
      if (operation === 'vector_dot') {
        const a = left.split(',').map(part => Number(part.trim()));
        const b = right.split(',').map(part => Number(part.trim()));
        if (!a.length || a.length !== b.length || a.some(value => !Number.isFinite(value)) || b.some(value => !Number.isFinite(value))) {
          setError('Enter two equal-length comma-separated vectors containing only finite numbers.'); setBusy(false); setRunStatus(''); return;
        }
        payload = { left: a, right: b };
      } else {
        const n = Number(size);
        if (!Number.isInteger(n) || n < 1 || n > 4096) {
          setError('Matrix summary size must be an integer from 1 through 4096.'); setBusy(false); setRunStatus(''); return;
        }
        payload = { size: n };
      }
      const maxMemory = Number(memoryLimit);
      if (!Number.isSafeInteger(maxMemory) || maxMemory < 1 || maxMemory > 1099511627776) {
        setError('Maximum estimated live-buffer memory must be a positive integer up to 1 TiB.'); setBusy(false); setRunStatus(''); return;
      }
      const quality = Number(qualityTarget), deadline = Number(latencyBudget);
      if (!Number.isFinite(quality) || quality <= 0 || quality > 1 || !Number.isFinite(deadline) || deadline <= 0 || deadline > 600000) {
        setError('Quality target must be in (0, 1] and deadline must be in (0, 600000] ms.'); setBusy(false); setRunStatus(''); return;
      }
      const budget = monetaryBudget.trim() === '' ? undefined : Number(monetaryBudget);
      const v1Allowed = backendPreference === 'auto'
        ? ['cpu', 'native_cpp', 'vector_simd']
        : [backendPreference];
      requestBody = {
        operation,
        payload,
        allowed_backends: v1Allowed,
        preferred_backend: backendPreference,
        quality_target: quality,
        latency_budget_ms: deadline,
        max_memory_bytes: maxMemory,
        ...(budget === undefined ? {} : { monetary_budget_usd: budget }),
      };
      apiPath = '/api/compute/jobs';
    }

    const idempotencyKey = crypto.randomUUID().replaceAll('-', '');
    try {
      const response = await fetch(apiPath, {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'idempotency-key': idempotencyKey },
        body: JSON.stringify(requestBody),
        cache: 'no-store',
      });
      const submitted = await response.json();
      if (!response.ok) throw new Error(describeError(submitted, `Submission failed (${response.status})`));
      if (typeof submitted.run_id !== 'string') throw new Error('Backend accepted the request without returning an execution ID.');
      const runId: string = submitted.run_id;
      setActiveRunId(runId);
      setRunStatus(submitted.status ?? 'QUEUED');

      let completed = false;
      const pollIntervalMs = 500;
      // Cap polling duration to 60 seconds regardless of latency budget (which is server-side)
      const maxPollDurationMs = 60_000;
      const pollAttempts = Math.ceil(maxPollDurationMs / pollIntervalMs);
      for (let attempt = 0; attempt < pollAttempts; attempt += 1) {
        const currentResponse = await fetch(`/api/compute/runs/${runId}`, { cache: 'no-store' });
        const currentBody = await currentResponse.json();
        if (!currentResponse.ok) throw new Error(describeError(currentBody, `Run status request failed (${currentResponse.status})`));
        const current = currentBody as PersistedRun;
        setPersisted(current);
        setRunStatus(current.status);
        if (TERMINAL.has(current.status)) {
          if (current.response && current.response.run_id) setResult(current.response);
          if (current.status !== 'SUCCEEDED' && current.status !== 'LOCAL_PROVISIONAL_UNVERIFIED') {
            setError(current.response?.error?.message ?? `Execution ended with status ${current.status}.`);
          }
          await refreshHistory();
          completed = true;
          break;
        }
        await new Promise(resolve => setTimeout(resolve, pollIntervalMs));
      }
      if (!completed) setError('The run is still active. Its ID is retained in history.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'The compute request failed.');
    } finally {
      setBusy(false);
      void refreshHistory();
      void checkBackendStatus();
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 text-slate-950 dark:bg-slate-950 dark:text-slate-100 sm:px-8">
      <div className="mx-auto max-w-6xl space-y-8">
        <header className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-5 dark:border-slate-800">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-blue-700 dark:text-blue-300">
              BOYKA · Intelligent Computing Platform
            </p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight">
              {activeScreen === 'overview' && 'A. System Overview & Health'}
              {activeScreen === 'workspace' && 'B. Verified Compute Workspace'}
              {activeScreen === 'plan' && 'C. Workload Execution Plan'}
              {activeScreen === 'run-details' && 'D. Execution Run Details'}
              {activeScreen === 'benchmarks' && 'E. Empirical Benchmarks'}
              {activeScreen === 'engineering' && 'F. Engineering & Architecture Portal'}
              {activeScreen === 'hardware' && 'G. Hardware Engineering & Presilicon Co-Design'}
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-slate-600 dark:text-slate-300">
              {activeScreen === 'overview' && 'Authoritative V1/V2 computing runtime daemon, discovered CPU resources, and transparent accelerator boundary matrix.'}
              {activeScreen === 'workspace' && 'Submit mathematical operations to the CPU compute engine. Every execution is evaluated against strict contracts and verified with independent mathematical oracles.'}
              {activeScreen === 'plan' && 'DAG operation dependency graphs, tensor layouts, candidate device constraints, and interactive multi-target pipeline simulation.'}
                {activeScreen === 'run-details' && 'Inspect API-returned execution data, verification outcomes, persisted receipts, and explicitly unreported measurements.'}
              {activeScreen === 'benchmarks' && 'Multi-target execution comparisons, cold vs warm performance curves, and Section 13 negative results crossover disclosures.'}
              {activeScreen === 'engineering' && 'Complete CTO architecture governance, system architecture layers, technical decision trees, theories catalog, and release audit log.'}
              {activeScreen === 'hardware' && 'Interactive SystemVerilog RTL simulation, AXI4 MMIO register control, OpenROAD ASIC flows, and MESI/MOESI cache coherence.'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => void checkBackendStatus()}
              className="rounded-md border border-slate-300 px-3 py-2 text-xs font-medium hover:bg-white dark:border-slate-700 dark:hover:bg-slate-900"
            >
              Check Status
            </button>
            <button
              type="button"
              onClick={() => navigateToScreen(activeScreen === 'engineering' ? 'workspace' : 'engineering')}
              className="rounded-md border border-slate-300 px-3 py-2 text-xs font-medium hover:bg-white dark:border-slate-700 dark:hover:bg-slate-900"
            >
              {activeScreen === 'engineering' ? 'Compute Workspace' : 'Engineering Portal'}
            </button>
          </div>
        </header>

        {/* Provenance & Connectivity Status Banner */}
        <div className={`flex flex-wrap items-center justify-between gap-3 rounded-lg border p-4 text-xs ${
          backendStatus?.connected
            ? 'border-emerald-300 bg-emerald-50 text-emerald-950 dark:border-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-200'
            : 'border-amber-300 bg-amber-50 text-amber-950 dark:border-amber-800 dark:bg-amber-950/40 dark:text-amber-200'
        }`}>
          <div className="flex items-center gap-2">
            <span className={`inline-block h-2.5 w-2.5 rounded-full ${backendStatus?.connected ? 'bg-emerald-600 animate-pulse' : 'bg-amber-600'}`} />
            <div>
              <span className="font-semibold">
                {backendStatus?.connected ? 'BOYKA V1 API Connected' : 'BOYKA V1 API Unavailable'}
              </span>
              <p className="mt-0.5 text-xs opacity-90">{backendStatus?.detail ?? 'Checking backend connectivity…'}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <span className="rounded bg-black/10 px-2 py-1 font-mono dark:bg-white/10">
              Storage: {backendStatus?.durability === 'DURABLE_POSTGRESQL'
                ? 'PostgreSQL (Durable)'
                : backendStatus ? 'PostgreSQL (Unavailable)' : 'Checking'}
            </span>
            <span className="rounded bg-black/10 px-2 py-1 font-mono dark:bg-white/10">
              Mode: {backendStatus?.mode ?? 'CONNECTING'}
            </span>
          </div>
        </div>

        {/* 7 Core Integrated Screens Navigation Bar (Section 4 A-G) */}
        <div className="flex flex-wrap items-center gap-1.5 border-b border-slate-200 pb-3 dark:border-slate-800">
          <button
            type="button"
            onClick={() => navigateToScreen('overview')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
              activeScreen === 'overview'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <Activity className="h-4 w-4" />
            A. Overview
          </button>
          <button
            type="button"
            onClick={() => navigateToScreen('workspace')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
              activeScreen === 'workspace'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <Cpu className="h-4 w-4" />
            B. Compute Workspace
          </button>
          <button
            type="button"
            onClick={() => navigateToScreen('plan')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
              activeScreen === 'plan'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <GitBranch className="h-4 w-4" />
            C. Execution Plan
          </button>
          <button
            type="button"
            onClick={() => navigateToScreen('run-details')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
              activeScreen === 'run-details'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <FileCode className="h-4 w-4" />
            D. Run Details
          </button>
          <button
            type="button"
            onClick={() => navigateToScreen('benchmarks')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
              activeScreen === 'benchmarks'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <TrendingUp className="h-4 w-4" />
            E. Benchmarks
          </button>
          <button
            type="button"
            onClick={() => navigateToScreen('engineering')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
              activeScreen === 'engineering'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <FolderTree className="h-4 w-4" />
            F. Engineering Portal
          </button>
          <button
            type="button"
            onClick={() => navigateToScreen('hardware')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-semibold transition-all ${
              activeScreen === 'hardware'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-100'
            }`}
          >
            <Layers className="h-4 w-4" />
            G. Hardware Engineering
          </button>
        </div>

        {/* Screen A: Overview */}
        {activeScreen === 'overview' && (
          <OverviewScreen
            backendStatus={backendStatus}
            capabilities={capabilities}
            capabilityError={capabilityError}
            historyStats={trendStats}
            onNavigate={(screen) => navigateToScreen(screen)}
            onRefresh={() => {
              void checkBackendStatus();
              void refreshHistory();
            }}
          />
        )}

        {/* Screen C: Execution Plan & Workload Graph */}
        {activeScreen === 'plan' && (
          <ExecutionPlanScreen
            onRunExecuted={(id) => {
              void loadRun(id);
              void refreshHistory();
            }}
            onNavigateToRun={(id) => {
              setInspectedRunId(id);
              void loadRun(id);
              setActiveScreen('run-details');
            }}
          />
        )}

        {/* Screen D: Run Details & Verifier Ledger */}
        {activeScreen === 'run-details' && (
          <RunDetailsScreen
            currentRun={currentRunRecord}
            allRuns={history as any}
            onSelectRun={(id) => {
              setInspectedRunId(id);
              void loadRun(id);
            }}
            onDownloadReceipt={(run) => {
              void downloadItemReceipt(run as any);
            }}
          />
        )}

        {/* Screen E: Benchmarks */}
        {activeScreen === 'benchmarks' && (
          <BenchmarksScreen />
        )}

        {/* Screen F: Engineering Portal */}
        {activeScreen === 'engineering' && (
          <EngineeringPortalScreen onNavigateToHardware={() => navigateToScreen('hardware')} />
        )}

        {/* Screen G: Hardware Engineering */}
        {activeScreen === 'hardware' && (
          <HardwareEngineeringScreen />
        )}

        {/* Screen B: Compute Workspace */}
        {activeScreen === 'workspace' && (
          <>
          <section className="grid gap-5 lg:grid-cols-[1fr_0.9fr]">
          <form onSubmit={submit} className="space-y-5 rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="runtime" className="mb-2 block text-sm font-medium">Calculation runtime</label>
                <select id="runtime" value={runtime} onChange={event => setRuntime(event.target.value as 'v1' | 'v2' | 'v2-graph')} className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm dark:border-slate-700 dark:bg-slate-950">
                  <option value="v1">V1 Standard Arithmetic</option>
                  <option value="v2">V2 Hardware-Aligned Integer</option>
                  <option value="v2-graph">V2 Compute Graph Pipeline</option>
                </select>
              </div>
              {runtime === 'v1' ? (
                <div>
                  <label htmlFor="operation" className="mb-2 block text-sm font-medium">Operation</label>
                  <select id="operation" value={operation} onChange={event => setOperation(event.target.value as 'vector_dot' | 'matmul_ones')} className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm dark:border-slate-700 dark:bg-slate-950">
                    <option value="vector_dot">Vector dot product (vector_dot)</option>
                    <option value="matmul_ones">All-ones matrix summary (matmul_ones)</option>
                  </select>
                </div>
              ) : (
                <div className="rounded-md border border-slate-200 p-3 text-sm dark:border-slate-700">
                  <strong>{runtime === 'v2' ? 'Integer Vector Contract' : 'Composite Compute Graph'}</strong>
                  <p className="mt-1 text-xs text-slate-500">Evaluated on CPU with canonical reference verification.</p>
                </div>
              )}
            </div>

            {runtime === 'v2-graph' ? (
              <div>
                <label htmlFor="graph-json" className="mb-2 block text-sm font-medium">Compute Graph Definition (JSON)</label>
                <textarea id="graph-json" value={graphJson} onChange={event => setGraphJson(event.target.value)} rows={10} spellCheck={false} className="w-full rounded-md border border-slate-300 bg-white p-3 font-mono text-xs dark:border-slate-700 dark:bg-slate-950" required />
              </div>
            ) : runtime === 'v2' ? (
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="left" className="mb-2 block text-sm font-medium">Vector A (signed int16)</label>
                  <input id="left" value={left} onChange={event => setLeft(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm font-mono dark:border-slate-700 dark:bg-slate-950" required />
                  <p className="mt-1 text-xs text-slate-500">Values in range [-32768, 32767]</p>
                </div>
                <div>
                  <label htmlFor="right" className="mb-2 block text-sm font-medium">Vector B (signed int16)</label>
                  <input id="right" value={right} onChange={event => setRight(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm font-mono dark:border-slate-700 dark:bg-slate-950" required />
                </div>
              </div>
            ) : operation === 'vector_dot' ? (
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="left" className="mb-2 block text-sm font-medium">Vector Left (float64)</label>
                  <input id="left" value={left} onChange={event => setLeft(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm font-mono dark:border-slate-700 dark:bg-slate-950" required />
                  <p className="mt-1 text-xs text-slate-500">Comma-separated finite numbers</p>
                </div>
                <div>
                  <label htmlFor="right" className="mb-2 block text-sm font-medium">Vector Right (float64)</label>
                  <input id="right" value={right} onChange={event => setRight(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm font-mono dark:border-slate-700 dark:bg-slate-950" required />
                </div>
              </div>
            ) : (
              <div>
                <label htmlFor="size" className="mb-2 block text-sm font-medium">Matrix Dimension (N x N)</label>
                <input id="size" type="number" min="1" max="4096" step="1" value={size} onChange={event => setSize(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-2.5 text-sm dark:border-slate-700 dark:bg-slate-950" required />
                <p className="mt-1 block text-xs text-slate-500">Analytic reduction O(1) without creating the full matrices.</p>
              </div>
            )}

            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <label htmlFor="quality-target" className="mb-1 block text-xs font-medium">Quality Target (0–1)</label>
                <input id="quality-target" type="number" min="0.01" max="1" step="0.01" value={qualityTarget} onChange={event => setQualityTarget(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-2 text-xs dark:border-slate-700 dark:bg-slate-950" required />
              </div>
              <div>
                <label htmlFor="latency-budget" className="mb-1 block text-xs font-medium">Latency Budget (ms)</label>
                <input id="latency-budget" type="number" min="1" max="600000" step="1" value={latencyBudget} onChange={event => setLatencyBudget(event.target.value)} className="w-full rounded-md border border-slate-300 bg-white p-2 text-xs dark:border-slate-700 dark:bg-slate-950" required />
              </div>
            </div>

            {error ? <p className="rounded-md border border-red-300 bg-red-50 p-3 text-sm text-red-900" role="alert">{error}</p> : null}

            {activeRunId ? (
              <div className="rounded-md border border-slate-200 p-3 text-xs dark:border-slate-700">
                <p>Run ID: <span className="break-all font-mono">{activeRunId}</span></p>
                <p className="mt-1">Status: <strong>{readableStatus(runStatus)}</strong></p>
                {runStatus === 'QUEUED' ? (
                  <button type="button" onClick={cancelActiveRun} className="mt-2 rounded border border-red-300 px-3 py-1.5 font-semibold text-red-700 hover:bg-red-50">
                    Cancel Job
                  </button>
                ) : null}
              </div>
            ) : null}

            <button disabled={busy} type="submit" className="rounded-md bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:cursor-wait disabled:opacity-50">
              {busy ? 'Executing & Verifying…' : 'Execute & Verify'}
            </button>
          </form>

          {/* Authoritative Capability Registry Gating View */}
          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900" aria-labelledby="capability-title">
            <div className="flex items-center justify-between border-b pb-3 dark:border-slate-800">
              <div>
                <h2 id="capability-title" className="text-lg font-semibold">Authoritative Capabilities</h2>
                <p className="mt-0.5 text-xs text-slate-500">Strict registry gating prevents unauthorized hardware claims.</p>
              </div>
              <span className="rounded bg-slate-100 px-2 py-1 font-mono text-[10px] uppercase dark:bg-slate-800">Registry v1.0.0</span>
            </div>

            {visibleCapabilities.length ? (
              <div className="mt-4 space-y-3">
                {visibleCapabilities.map(item => (
                  <article key={item.operation} className="rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-800">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">{readableOperation(item.operation)}</h3>
                      <span className="font-mono text-[10px] text-slate-400">{item.operation}</span>
                    </div>
                    <p className="mt-1 text-slate-600 dark:text-slate-300">{operationDescription(item.operation, item.description)}</p>
                    <div className="mt-2.5 grid grid-cols-2 gap-2">
                      {Object.entries(item.backends).map(([bKey, bVal]) => (
                        <div key={bKey} className="rounded bg-slate-50 p-2 dark:bg-slate-950">
                          <div className="flex items-center justify-between">
                            <span className="font-bold uppercase text-[10px]">{bKey}</span>
                            <span className={`rounded px-1.5 py-0.5 text-[9px] font-semibold ${bVal.execution_allowed ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'}`}>
                              {bVal.execution_allowed ? 'ALLOWED' : 'GATED'}
                            </span>
                          </div>
                          <p className="mt-1 text-[10px] text-slate-500">{bVal.reason}</p>
                        </div>
                      ))}
                    </div>
                  </article>
                ))}
              </div>
            ) : (
              <p className="mt-4 text-xs text-slate-500">Loading capabilities…</p>
            )}
          </section>
        </section>

        {/* Results with Honest Verification and Persistence Provenance */}
        {result ? (
          <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900" aria-labelledby="result-title">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-3 dark:border-slate-800">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Execution Result & Provenance</p>
                <h2 id="result-title" className="mt-1 text-xl font-semibold flex items-center gap-2">
                  <span>{readableStatus(result.status)}</span>
                  <span className={`rounded px-2 py-0.5 text-xs font-normal ${
                    result.status === 'SUCCEEDED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                  }`}>
                    {result.status === 'SUCCEEDED' && result.verification?.status === 'VERIFIED' ? 'Execution & verification accepted' : 'Outcome: see actual status'}
                  </span>
                </h2>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <div className="rounded border border-slate-200 px-3 py-1.5 text-xs dark:border-slate-700">
                  Actual backend: <strong className="font-mono">{result.actual_backend ?? 'NOT_REPORTED'}</strong>
                </div>
                <button
                  type="button"
                  onClick={() => downloadJson(`receipt-${result.run_id.slice(0, 8)}.json`, result.receipt ?? persisted ?? result)}
                  className="flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <Download className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Download Receipt JSON</span>
                </button>
              </div>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-md bg-slate-50 p-3 text-xs dark:bg-slate-950">
                <span className="text-slate-500">Computed Output</span>
                <dl className="mt-2 space-y-1">
                  {resultEntries(result.output ?? result.error ?? 'No output').map(([label, value]) => (
                    <div key={label} className="flex justify-between gap-2">
                      <dt className="text-slate-500">{label}:</dt>
                      <dd className="break-all font-semibold font-mono">{value}</dd>
                    </div>
                  ))}
                </dl>
              </div>

              <div className="rounded-md bg-slate-50 p-3 text-xs dark:bg-slate-950">
                <span className="text-slate-500">Independent Verification</span>
                <p className="mt-1 font-semibold">{readableStatus(result.verification?.status)}</p>
                <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-400">
                  {result.verification?.independent
                    ? `Verified by independent oracle: ${result.verification.verifier_id}`
                    : result.verification?.reason ?? 'Independent verifier check pending or offline.'}
                </p>
              </div>

              <div className="rounded-md bg-slate-50 p-3 text-xs dark:bg-slate-950">
                <span className="text-slate-500">Storage Durability</span>
                <p className="mt-1 font-semibold font-mono">
                  {persisted?.persistence_status ?? 'NOT_REPORTED'}
                </p>
                <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-400">
                  {persisted?.persistence_status === 'DURABLE_POSTGRESQL'
                    ? persisted.receipt_sha256
                      ? 'Run and receipt hash were retrieved from the PostgreSQL execution store.'
                      : 'Run record was retrieved from the PostgreSQL execution store; receipt hash is not available.'
                    : 'The API did not report durable storage for this run.'}
                </p>
              </div>

              <div className="rounded-md bg-slate-50 p-3 text-xs dark:bg-slate-950">
                <span className="text-slate-500">Cryptographic Receipt</span>
                <p className="mt-1 font-mono text-[10px] break-all">
                  {persisted?.receipt_sha256 ? `${persisted.receipt_sha256.slice(0, 16)}…` : 'NO_RECEIPT_SHA'}
                </p>
                <p className="mt-1 text-[11px] text-slate-500">Run ID: {result.run_id}</p>
              </div>
            </div>

            <details className="rounded-md border border-slate-200 p-3 text-xs dark:border-slate-800">
              <summary className="cursor-pointer font-medium">View Detailed Technical Receipt</summary>
              <div className="mt-3 grid gap-3 lg:grid-cols-2">
                <div>
                  <h4 className="font-semibold text-slate-500 mb-1">Execution Profile & Graph</h4>
                  <pre className="max-h-60 overflow-auto rounded bg-slate-950 p-3 font-mono text-[11px] text-slate-100">
                    {JSON.stringify(result.receipt ?? result, null, 2)}
                  </pre>
                </div>
                <div>
                  <h4 className="font-semibold text-slate-500 mb-1">Persisted Run Record</h4>
                  <pre className="max-h-60 overflow-auto rounded bg-slate-950 p-3 font-mono text-[11px] text-slate-100">
                    {JSON.stringify(persisted, null, 2)}
                  </pre>
                </div>
              </div>
            </details>
          </section>
        ) : null}

        {/* Durable History Table with Storage and Verification Provenance */}
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900" aria-labelledby="history-title">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-4 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <h2 id="history-title" className="text-lg font-semibold">Execution History & Receipts</h2>
                <span className="rounded bg-blue-100 px-2 py-0.5 text-[11px] font-semibold text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                  {history.length} {history.length === 1 ? 'Run' : 'Runs'}
                </span>
              </div>
              <p className="mt-0.5 text-xs text-slate-500">
                Audit trail of submitted runs with cryptographic verification, grouping, and receipt export.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Grouping Mode Controls */}
              <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-xs dark:border-slate-700 dark:bg-slate-950">
                <span className="px-2 py-1 text-[11px] font-medium text-slate-500">Group:</span>
                <button
                  type="button"
                  onClick={() => setHistoryGrouping('date')}
                  className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition ${
                    historyGrouping === 'date'
                      ? 'bg-white text-blue-700 shadow-sm dark:bg-slate-800 dark:text-blue-300'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  <Calendar className="h-3 w-3" />
                  <span>Date</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryGrouping('batch')}
                  className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition ${
                    historyGrouping === 'batch'
                      ? 'bg-white text-blue-700 shadow-sm dark:bg-slate-800 dark:text-blue-300'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  <Layers className="h-3 w-3" />
                  <span>Operation</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryGrouping('none')}
                  className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium transition ${
                    historyGrouping === 'none'
                      ? 'bg-white text-blue-700 shadow-sm dark:bg-slate-800 dark:text-blue-300'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  <FolderTree className="h-3 w-3" />
                  <span>Flat View</span>
                </button>
              </div>

              {/* Batch Export All */}
              {history.length > 0 && (
                <button
                  type="button"
                  onClick={downloadAllReceipts}
                  className="flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <ArrowDownToLine className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Export All Receipts</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => void refreshHistory()}
                disabled={historyBusy}
                className="flex items-center gap-1.5 rounded-md border border-slate-300 px-3 py-1.5 text-xs font-medium hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                <RefreshCw className={`h-3 w-3 ${historyBusy ? 'animate-spin' : ''}`} />
                <span>{historyBusy ? 'Refreshing…' : 'Refresh'}</span>
              </button>
            </div>
          </div>

          {/* The trend is derived only from persisted runs; it is not a performance benchmark. */}
          {trendData.length > 0 && (
            <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50/50 p-4 dark:border-slate-800 dark:bg-slate-950/50">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                    Execution Trend & Success Ratio (Last {trendStats.total} Operations)
                  </h3>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className="flex items-center gap-1 rounded bg-emerald-100 px-2 py-0.5 font-medium text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300">
                    <CheckCircle2 className="h-3 w-3" />
                    <span>{trendStats.succeeded} Succeeded</span>
                  </span>
                  {trendStats.failed > 0 && (
                    <span className="flex items-center gap-1 rounded bg-rose-100 px-2 py-0.5 font-medium text-rose-800 dark:bg-rose-950/80 dark:text-rose-300">
                      <XCircle className="h-3 w-3" />
                      <span>{trendStats.failed} Failed</span>
                    </span>
                  )}
                  <span className="rounded border border-slate-300 bg-white px-2 py-0.5 font-bold font-mono text-slate-800 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200">
                    {trendStats.ratio}% Success Ratio
                  </span>
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-2">
                {trendData.map(item => (
                  <div key={item.fullRunId} className="rounded-md border border-slate-200 p-2.5 dark:border-slate-800">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="truncate font-medium">{item.operation}</span>
                      <span className={item.succeeded ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}>
                        {readableStatus(item.status)}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-between gap-2 text-[10px] text-slate-500">
                      <span className="font-mono">{item.runId} · {item.backend}</span>
                      <span>Cumulative success: {item.successRatio}%</span>
                    </div>
                    <div className="mt-1.5 h-1 overflow-hidden rounded bg-slate-200 dark:bg-slate-800" role="img" aria-label={`Cumulative success ratio ${item.successRatio}%`}>
                      <div className="h-full rounded bg-emerald-500" style={{ width: `${item.successRatio}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {historyError ? <p className="mt-3 text-xs text-red-700" role="alert">{historyError}</p> : null}

          {history.length ? (
            <div className="mt-4 space-y-5">
              {historyGrouping !== 'none' && groupedHistory ? (
                groupedHistory.map(group => (
                  <div key={group.label} className="rounded-lg border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
                    {/* Rich Group Summary Header */}
                    <div className="border-b border-slate-200 bg-slate-50/75 p-3.5 dark:border-slate-800 dark:bg-slate-950/75">
                      <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                        <div className="flex items-center gap-2">
                          {historyGrouping === 'date' ? (
                            <Calendar className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                          ) : (
                            <Layers className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                          )}
                          <h3 className="font-semibold text-sm text-slate-900 dark:text-slate-100">{group.label}</h3>
                          <span className="rounded bg-blue-100 px-2 py-0.5 text-[11px] font-semibold text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                            {group.totalRuns} {group.totalRuns === 1 ? 'Run' : 'Runs'}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => downloadJson(`receipts-${group.label.replace(/[^a-zA-Z0-9_-]/g, '_')}.json`, group.items)}
                          title="Export all receipts in this group"
                          className="flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 shadow-sm hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
                        >
                          <Download className="h-3.5 w-3.5 text-slate-500" />
                          <span>Export Group Receipts</span>
                        </button>
                      </div>

                      {/* Summary Metrics Grid */}
                      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                        {/* Metric 1: Success Percentage */}
                        <div className="rounded-lg border border-slate-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-900">
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span>Success Rate</span>
                            {group.successPercentage === 100 ? (
                              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                            ) : (
                              <Activity className="h-3.5 w-3.5 text-blue-500" />
                            )}
                          </div>
                          <div className="mt-1 flex items-baseline gap-1.5">
                            <span className={`text-base font-bold font-mono ${
                              group.successPercentage >= 90 ? 'text-emerald-600 dark:text-emerald-400' :
                              group.successPercentage >= 60 ? 'text-amber-600 dark:text-amber-400' : 'text-rose-600 dark:text-rose-400'
                            }`}>
                              {group.successPercentage}%
                            </span>
                            <span className="text-[10px] text-slate-500">
                              ({group.succeededCount}/{group.totalRuns} passed)
                            </span>
                          </div>
                          <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                            <div
                              className={`h-full rounded-full transition-all ${
                                group.successPercentage >= 90 ? 'bg-emerald-500' :
                                group.successPercentage >= 60 ? 'bg-amber-500' : 'bg-rose-500'
                              }`}
                              style={{ width: `${group.successPercentage}%` }}
                            />
                          </div>
                        </div>

                        {/* Metric 2: Total Runs */}
                        <div className="rounded-lg border border-slate-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-900">
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span>Total Operations</span>
                            <Layers className="h-3.5 w-3.5 text-slate-400" />
                          </div>
                          <div className="mt-1 flex items-baseline gap-1.5">
                            <span className="text-base font-bold font-mono text-slate-900 dark:text-slate-100">
                              {group.totalRuns}
                            </span>
                            <span className="text-[10px] text-slate-500">executed</span>
                          </div>
                          <div className="mt-1 flex items-center gap-1.5 text-[10px]">
                            <span className="text-emerald-600 dark:text-emerald-400 font-medium">{group.succeededCount} Pass</span>
                            {group.failedCount > 0 && (
                              <span className="text-rose-600 dark:text-rose-400 font-medium">• {group.failedCount} Fail</span>
                            )}
                          </div>
                        </div>

                        {/* Metric 3: Average Duration */}
                        <div className="rounded-lg border border-slate-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-900">
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span>Avg Duration</span>
                            <Clock className="h-3.5 w-3.5 text-slate-400" />
                          </div>
                          <div className="mt-1 flex items-baseline gap-1.5">
                            <span className="text-base font-bold font-mono text-blue-600 dark:text-blue-400">
                              {formatDuration(group.durations.length > 0 ? group.avgDurationMs : null)}
                            </span>
                          </div>
                          <div className="mt-1 text-[10px] text-slate-500 font-mono">
                            Total: {formatDuration(group.durations.length > 0 ? group.totalDurationMs : null)}
                          </div>
                        </div>

                        {/* Metric 4: Duration Distribution (Min / Max) */}
                        <div className="rounded-lg border border-slate-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-900">
                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span>Duration Range</span>
                            <Timer className="h-3.5 w-3.5 text-slate-400" />
                          </div>
                          <div className="mt-1 flex items-baseline gap-1 text-xs font-mono font-semibold text-slate-800 dark:text-slate-200">
                            <span>{formatDuration(group.minDurationMs)}</span>
                            <span className="text-slate-400 font-normal">to</span>
                            <span>{formatDuration(group.maxDurationMs)}</span>
                          </div>
                          <div className="mt-1 text-[10px] text-slate-500">
                            Spread: {group.minDurationMs !== null && group.maxDurationMs !== null ? formatDuration(Math.max(0, group.maxDurationMs - group.minDurationMs)) : 'NOT_MEASURED'}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Group Items Table */}
                    <div className="overflow-x-auto">
                      <table className="w-full min-w-[700px] border-collapse text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-200 uppercase text-slate-500 bg-white dark:bg-slate-900 dark:border-slate-800 text-[10px]">
                            <th className="p-2">Run ID</th>
                            <th className="p-2">Operation</th>
                            <th className="p-2">Backend</th>
                            <th className="p-2">Duration</th>
                            <th className="p-2">Status</th>
                            <th className="p-2">Storage</th>
                            <th className="p-2">Receipt SHA-256</th>
                            <th className="p-2 text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {group.items.map(item => (
                            <tr key={item.run_id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50/50 dark:hover:bg-slate-900/50">
                              <td className="max-w-36 break-all p-2 font-mono text-[11px]">{item.run_id}</td>
                              <td className="p-2 font-medium">
                                <div>{readableOperation(item.operation)}</div>
                                <div className="text-[10px] text-slate-400">
                                  {item.created_at ? new Date(item.created_at).toLocaleTimeString() : 'Recent'}
                                </div>
                              </td>
                              <td className="p-2">
                                <span className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-[11px] dark:bg-slate-800">
                                  {item.backend === 'cpu' ? 'CPU' : (item.backend ?? 'NOT_REPORTED')}
                                </span>
                              </td>
                              <td className="p-2 font-mono text-[11px] text-slate-600 dark:text-slate-300">
                                {formatDuration(getItemDurationMs(item))}
                              </td>
                              <td className="p-2">
                                <span className={`inline-block rounded px-1.5 py-0.5 font-medium ${
                                  item.status === 'SUCCEEDED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                }`}>
                                  {readableStatus(item.status)}
                                </span>
                              </td>
                              <td className="p-2">
                                <span className={`inline-block rounded px-1.5 py-0.5 font-mono text-[10px] ${
                                  item.receipt_sha256 ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                                }`}>
                                  {item.persistence_status ?? 'NOT_REPORTED'}
                                </span>
                              </td>
                              <td className="p-2 font-mono text-[10px] text-slate-400">
                                {item.receipt_sha256 ? `${item.receipt_sha256.slice(0, 12)}…` : 'None'}
                              </td>
                              <td className="p-2 text-right">
                                <div className="flex items-center justify-end gap-2">
                                  <button type="button" onClick={() => void openHistory(item.run_id)} className="font-semibold text-blue-600 hover:underline dark:text-blue-400">
                                    Inspect
                                  </button>
                                  <button
                                    type="button"
                                    disabled={downloadingRunId === item.run_id}
                                    onClick={() => void downloadItemReceipt(item)}
                                    title="Download Technical Receipt JSON"
                                    className="flex items-center gap-1 rounded border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                                  >
                                    <Download className="h-3 w-3 text-slate-500 dark:text-slate-400" />
                                    <span>Receipt</span>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))
              ) : (
                <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm">
                  <table className="w-full min-w-[700px] border-collapse text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 uppercase text-slate-500 bg-slate-50 dark:bg-slate-950 dark:border-slate-800 text-[10px]">
                        <th className="p-2">Run ID</th>
                        <th className="p-2">Operation</th>
                        <th className="p-2">Backend</th>
                        <th className="p-2">Duration</th>
                        <th className="p-2">Status</th>
                        <th className="p-2">Storage</th>
                        <th className="p-2">Receipt SHA-256</th>
                        <th className="p-2 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {history.map(item => (
                        <tr key={item.run_id} className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50/50 dark:hover:bg-slate-900/50">
                          <td className="max-w-36 break-all p-2 font-mono text-[11px]">{item.run_id}</td>
                          <td className="p-2 font-medium">
                            <div>{readableOperation(item.operation)}</div>
                            <div className="text-[10px] text-slate-400">
                              {item.created_at ? new Date(item.created_at).toLocaleTimeString() : 'Recent'}
                            </div>
                          </td>
                          <td className="p-2 font-mono">{item.backend === 'cpu' ? 'CPU' : item.backend ?? 'NOT_REPORTED'}</td>
                          <td className="p-2 font-mono text-[11px] text-slate-600 dark:text-slate-300">
                            {formatDuration(getItemDurationMs(item))}
                          </td>
                          <td className="p-2">
                            <span className={`inline-block rounded px-1.5 py-0.5 font-medium ${
                              item.status === 'SUCCEEDED' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            }`}>
                              {readableStatus(item.status)}
                            </span>
                          </td>
                          <td className="p-2">
                            <span className={`inline-block rounded px-1.5 py-0.5 font-mono text-[10px] ${
                              item.receipt_sha256 ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                            }`}>
                              {item.persistence_status ?? 'NOT_REPORTED'}
                            </span>
                          </td>
                          <td className="p-2 font-mono text-[10px] text-slate-400">
                            {item.receipt_sha256 ? `${item.receipt_sha256.slice(0, 12)}…` : 'None'}
                          </td>
                          <td className="p-2 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button type="button" onClick={() => void openHistory(item.run_id)} className="font-semibold text-blue-600 hover:underline dark:text-blue-400">
                                Inspect
                              </button>
                              <button
                                type="button"
                                disabled={downloadingRunId === item.run_id}
                                onClick={() => void downloadItemReceipt(item)}
                                title="Download Technical Receipt JSON"
                                className="flex items-center gap-1 rounded border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                              >
                                <Download className="h-3 w-3 text-slate-500 dark:text-slate-400" />
                                <span>Receipt</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ) : (
            <p className="mt-4 text-xs text-slate-500">
              {historyBusy
                ? 'Loading history…'
                : historyError
                  ? 'Saved executions could not be checked. Refresh history to retry.'
                  : 'No execution records yet. Submit a calculation to generate receipts.'}
            </p>
          )}
        </section>
        </>
        )}
      </div>
    </main>
  );
}
