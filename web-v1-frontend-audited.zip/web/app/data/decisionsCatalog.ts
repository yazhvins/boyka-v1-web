export interface DecisionRecord {
  id: string;
  question: string;
  category: 'hardware' | 'runtime' | 'organization' | 'capital' | 'commercial';
  whyNow: string;
  currentContext: string;
  options: {
    title: string;
    description: string;
    pros: string[];
    cons: string[];
    capitalCost: string;
    timeHorizon: string;
  }[];
  evidenceFor: string[];
  evidenceAgainst: string[];
  unknowns: string[];
  consequences: {
    technical: string;
    product: string;
    customer: string;
    financial: string;
    people: string;
    operational: string;
    ipLegal: string;
    security: string;
    capital: string;
    time: string;
  };
  reversibility: 'HIGHLY_REVERSIBLE' | 'PARTIALLY_REVERSIBLE' | 'IRREVERSIBLE_OR_VERY_COSTLY';
  optionValue: string;
  decisionOwner: string;
  whoMustBeConsulted: string[];
  approvalStatus: 'APPROVED_POLICY' | 'PENDING_EVIDENCE_GATE' | 'REJECTED_ALTERNATIVE';
  currentDecision: string;
  triggerToRevisit: string;
}

export const DECISIONS_CATALOG: DecisionRecord[] = [
  {
    id: 'DEC-001',
    question: 'Should BOYKA Build Custom Silicon Accelerators in Phase 1?',
    category: 'hardware',
    whyNow: 'The original BOYKA documents prominently feature custom silicon architecture and co-designed chips. As founding CTO, we must immediately clarify if this is a Phase 1 expenditure or a post-scale evolution.',
    currentContext: '[SCENARIO ASSUMPTION — NOT MEASURED] Custom ASIC tape-outs cost $20M–$50M, require 24–36 months, and demand a 30-person chip design team. In contrast, software runtime innovations on commodity GPUs (NVIDIA H100/B200) require < $500k and can validate the core algorithmic thesis in 3 months.',
    options: [
      {
        title: 'Option A: Immediate Custom Silicon Pursuit',
        description: '[SCENARIO ASSUMPTION — NOT MEASURED] Form a chip design division immediately and seek $30M+ hardware semiconductor venture capital.',
        pros: ['Direct hardware-software co-design', 'Theoretical peak memory bandwidth control'],
        cons: ['Extreme capital intensity', '24-36 month feedback delay', 'High risk of market obsolescence before silicon tape-out'],
        capitalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $25,000,000 - $50,000,000',
        timeHorizon: '24 - 36 months'
      },
      {
        title: 'Option B: Software-First on Commodity Hardware (Recommended)',
        description: 'Prove the anytime early-exit and adaptive KV-cache paging algorithms entirely on commodity NVIDIA GPUs (Triton / CUDA / vLLM runtime). Gate custom hardware behind strict efficiency benchmarks.',
        pros: ['[SCENARIO ASSUMPTION — NOT MEASURED] Immediate customer feedback', 'Low capital requirements ($250k-$1M)', 'Fast 3-month prototype iterations', 'Preserves optionality'],
        cons: ['Bound by fixed NVIDIA GPU memory bus topology', 'Dependent on NVIDIA driver stack'],
        capitalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $20,000 - $50,000 compute rental',
        timeHorizon: '3 - 6 months'
      },
      {
        title: 'Option C: FPGA / Emulation Hybrid',
        description: 'Implement core execution graph logic on cloud FPGAs (AWS F1 instances) before considering ASIC.',
        pros: ['Reprogrammable logic', 'Lower cost than ASIC'],
        cons: ['[SCENARIO ASSUMPTION — NOT MEASURED] FPGA clock speeds (250MHz) are 10x slower than modern GPUs, invalidating latency tests', 'Niche developer ecosystem'],
        capitalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $100,000 - $300,000',
        timeHorizon: '9 - 12 months'
      }
    ],
    evidenceFor: [
      '[SCENARIO ASSUMPTION — NOT MEASURED] Landauer thermodynamic calculations show algorithmic waste (unnecessary reasoning tokens) is 10x larger than silicon transistor physical inefficiency.',
      '[SCENARIO ASSUMPTION — NOT MEASURED] vLLM, SGLang, and FlashAttention achieved 3x-5x throughput improvements purely in software on identical GPU hardware.'
    ],
    evidenceAgainst: [
      'Commodity GPUs have fixed HBM-to-SRAM bandwidth ratios that may eventually throttle speculative draft verification.'
    ],
    unknowns: [
      'Exact Model FLOPs Utilization (MFU) ceiling of the anytime early-exit kernel on Blackwell architecture (B200).',
      'Whether enterprise customers will demand on-prem custom hardware.'
    ],
    consequences: {
      technical: 'Keeps engineering focused on algorithmic correctness and low-latency scheduling rather than verilog/RTL synthesis.',
      product: 'Enables an immediate OpenAI-compatible software gateway product that customers can use this quarter.',
      customer: 'Zero customer hardware installation barrier; pure API endpoint or container deployment.',
      financial: '[SCENARIO ASSUMPTION — NOT MEASURED] Reduces Phase 1 capital burn from $500k/month to $25k/month.',
      people: 'Requires 2-3 elite systems/ML software engineers instead of a 25-person hardware engineering department.',
      operational: 'Standard cloud infrastructure operations (AWS/GCP/CoreWeave) with zero manufacturing supply chain risk.',
      ipLegal: 'Trade secrets and software patents on runtime scheduling algorithms; no complex foundry or IP core licensing.',
      security: 'Standard cloud container security rather than silicon physical tampering / supply chain verification.',
      capital: '[SCENARIO ASSUMPTION — NOT MEASURED] Enables raising a focused $1.5M-$3M seed round rather than an unviable $40M deep-hardware round without prototype.',
      time: 'Delivers working software prototype in 90 days vs 3 years.'
    },
    reversibility: 'HIGHLY_REVERSIBLE',
    optionValue: 'Preserves the option to build custom silicon in Phase 4 if and only if software exhausts all commodity hardware efficiency.',
    decisionOwner: 'Founding CTO (Technical Architecture & Gating) with CEO Approval',
    whoMustBeConsulted: ['Founder / CEO', 'Hardware Advisors', 'Lead Systems Engineer'],
    approvalStatus: 'APPROVED_POLICY',
    currentDecision: 'Enforce Silicon Gating Policy: Custom silicon is strictly frozen. All Phase 1 & 2 engineering is 100% focused on software runtime on commodity GPUs.',
    triggerToRevisit: '[SCENARIO ASSUMPTION — NOT MEASURED] Software reaches >85% Model FLOPs Utilization on commodity hardware AND customers demand >5x higher density than standard H100/B200 racks can deliver.'
  },
  {
    id: 'DEC-002',
    question: 'Should BOYKA Build an Inference Runtime from Scratch or Fork vLLM / SGLang?',
    category: 'runtime',
    whyNow: 'We must begin prototype implementation for the Adaptive Inference Gateway. Building an entire distributed tensor-parallel engine from scratch consumes 9-12 months of boilerplate.',
    currentContext: 'Open-source inference engines (vLLM, SGLang, TensorRT-LLM) have hundreds of person-years of optimizations for PagedAttention, continuous batching, and FlashAttention kernels.',
    options: [
      {
        title: 'Option A: Build Clean-Sheet Engine from Scratch in Rust/C++',
        description: 'Write custom memory allocator, KV-cache manager, continuous batching scheduler, and Triton kernels from zero.',
        pros: ['100% control of execution abstractions', 'Zero legacy technical debt', 'Proprietary IP cleanliness'],
        cons: ['Re-inventing 18 months of commodity plumbing', 'Delays customer-facing validation by 9 months'],
        capitalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $400,000 in engineering time',
        timeHorizon: '9 - 12 months'
      },
      {
        title: 'Option B: Fork vLLM / SGLang and Implement BOYKA Adaptive Kernel Extensions (Recommended)',
        description: 'Leverage established continuous batching and PagedAttention infrastructure while replacing the decode scheduler with BOYKA SPRT early-exit and dynamic KV-paging hooks.',
        pros: ['Immediate prototype within 30 days', 'Automatic support for latest model architectures (Llama-3, DeepSeek, Qwen)', 'Focus engineering exclusively on differentiated algorithms'],
        cons: ['Must track upstream open-source releases or maintain a dedicated fork', 'Apache 2.0 license compliance required'],
        capitalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $50,000 in engineering time',
        timeHorizon: '1 - 2 months'
      }
    ],
    evidenceFor: [
      '95% of inference execution time is spent inside standardized GEMM matrix multiplications (cuBLAS/CUTLASS) where custom clean-sheet code cannot exceed NVIDIA vendor libraries.',
      'SGLang and vLLM already provide extensible plugin interfaces for speculative decoding and custom schedulers.'
    ],
    evidenceAgainst: [
      'Upstream architectural changes might require re-basing custom scheduling hooks.'
    ],
    unknowns: [
      'Exact kernel latency overhead of inserting asynchronous per-token stopping callbacks into continuous batching inner loops.'
    ],
    consequences: {
      technical: 'Accelerates time-to-first-benchmark by ~75%. Allows testing on state-of-the-art models on Day 1.',
      product: 'Supports all popular open-weights models out of the box without manual weight porting.',
      customer: 'Customers receive battle-tested reliability for base model execution.',
      financial: '[SCENARIO ASSUMPTION — NOT MEASURED] Saves ~$350k in initial engineering payroll.',
      people: 'Requires 1 Senior Inference Systems Engineer rather than a team of 5 runtime engineers.',
      operational: 'Standard deployment on Docker / Kubernetes.',
      ipLegal: 'BOYKA proprietary extensions remain distinct proprietary modules while respecting Apache 2.0 open-source licensing.',
      security: 'Benefits from open-source community vulnerability audits.',
      capital: 'Minimizes pre-seed burn.',
      time: 'Working benchmark in 4 weeks.'
    },
    reversibility: 'PARTIALLY_REVERSIBLE',
    optionValue: 'Can transition to a standalone clean-sheet engine in Phase 3 if architectural constraints in upstream engines prevent further scaling.',
    decisionOwner: 'Founding CTO',
    whoMustBeConsulted: ['Lead Systems Engineer', 'CEO'],
    approvalStatus: 'APPROVED_POLICY',
    currentDecision: 'Fork and extend upstream vLLM/SGLang scheduler. Confine BOYKA proprietary innovation to the Metareasoning Controller and SPRT early-exit kernels.',
    triggerToRevisit: 'Upstream scheduler abstractions impose >10% latency overhead on early-exit thread retirement.'
  },
  {
    id: 'DEC-003',
    question: 'Should We Raise Capital Immediately or Complete EXP-RP01-001 Validation First?',
    category: 'capital',
    whyNow: 'The temptation in AI is to pitch an ambitious vision deck immediately to institutional venture capital before generating empirical results.',
    currentContext: 'Deep-tech AI infrastructure valuations and investor scrutiny have bifurcated: conceptual pitch decks without benchmark receipts face low valuations or skepticism, while founders with verified micro-benchmarks command premium term sheets and founder-friendly governance.',
    options: [
      {
        title: 'Option A: Pitch Immediately on Vision Deck Alone',
        description: '[SCENARIO ASSUMPTION — NOT MEASURED] Take the 49-page conceptual vision to VCs now to raise a $3M-$5M pre-seed round.',
        pros: ['Capital in bank sooner if successful'],
        cons: ['Severe valuation discount for unvalidated claims', 'Vulnerable to rigorous technical diligence', 'High risk of failed fundraising cycle'],
        capitalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $0',
        timeHorizon: '3 - 5 months'
      },
      {
        title: 'Option B: Execute EXP-RP01-001 Micro-Benchmark First (6-8 Weeks, Recommended)',
        description: '[SCENARIO ASSUMPTION — NOT MEASURED] Spend 6-8 weeks and <$15k on an 8x H100 node to generate verified latency vs accuracy receipts on GSM8K/MATH before launching formal diligence.',
        pros: ['[SCENARIO ASSUMPTION — NOT MEASURED] Unassailable technical diligence package', '2x-3x higher valuation benchmark', 'Eliminates technical bluffing', 'Strong founder leverage'],
        cons: ['[SCENARIO ASSUMPTION — NOT MEASURED] Requires self-funding or micro-grant ($15k) for initial GPU compute'],
        capitalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $15,000 compute',
        timeHorizon: '6 - 8 weeks'
      }
    ],
    evidenceFor: [
      'Inference optimization is an empirical science. Investors will ask: "What is your measured speedup on GSM8K and what is your quality degradation?" Having the chart in Hand 1 closes rounds.',
      'Prevents embarrassing diligence failure when top VC technical partners inspect the codebase.'
    ],
    evidenceAgainst: [
      'Market timing risk if a competitor releases a similar paper in the 6-week window.'
    ],
    unknowns: [
      'Exact availability of rented H100 nodes on Lambda/CoreWeave during the test window.'
    ],
    consequences: {
      technical: 'Forces immediate scientific rigor and eliminates hand-waving.',
      product: 'Creates the exact benchmark charts that become the product marketing collateral.',
      customer: '[SCENARIO ASSUMPTION — NOT MEASURED] Gives prospective enterprise pilot partners confidence to sign LOIs.',
      financial: 'Preserves maximum founder equity (dilution 10-15% vs 25-30%).',
      people: 'Validates co-founder chemistry between Lipun and Arun under real execution pressure.',
      operational: 'Establishes our development pipeline and CI/CD testing infrastructure early.',
      ipLegal: 'Generates documented invention records for provisional patent filing prior to investor disclosure.',
      security: 'Clean-room benchmarking methodology.',
      capital: 'Yields higher quality investors who value technical substance over hype.',
      time: '6-8 week investment creates 18-month leverage.'
    },
    reversibility: 'HIGHLY_REVERSIBLE',
    optionValue: 'Preserves the option to raise larger capital on superior terms.',
    decisionOwner: 'Founders Jointly (CEO & CTO)',
    whoMustBeConsulted: ['Lipun (CEO)', 'Arun Kumar (CTO)', 'Key Seed Advisors'],
    approvalStatus: 'APPROVED_POLICY',
    currentDecision: 'Execute EXP-RP01-001 micro-benchmark first. Build the empirical data room before scheduling Tier-1 institutional VC meetings.',
    triggerToRevisit: '[SCENARIO ASSUMPTION — NOT MEASURED] A Tier-1 lead investor offers a clean term sheet at >$15M cap on vision alone with zero diligence hurdles.'
  }
];
