import { ReviewAnnotation, CommentItem } from '../types';

export const INITIAL_ANNOTATIONS: ReviewAnnotation[] = [
  {
    id: 'ann-001',
    documentId: 'BOYKA-SRC-001', // Boyka Computing - Part I
    pageNumber: 1,
    selectedText: '[BOYKA SOURCE] Rebuilding the computing architecture for post-transformer intelligence with 10x-100x efficiency gains.',
    myUnderstanding: 'Lipun is framing the core venture as an architectural leap beyond uniform matrix multiplication, focusing on eliminating redundant computation in static reasoning graphs.',
    assessmentKind: 'CHALLENGE',
    discussionStatus: 'OPEN',
    createdDate: '2026-09-20',
    comments: [
      {
        id: 'c-001',
        author: 'Arun Kumar (Candidate CTO)',
        role: 'Candidate Founding CTO',
        timestamp: '2026-09-20 14:30',
        targetType: 'document',
        targetId: 'ann-001',
        text: 'The source thesis sets an ambitious efficiency direction, but a submission should not manufacture a speedup target. Freeze a representative workload, baseline, quality gate and cost/latency vector; let the measured result decide whether adaptive execution deserves promotion.',
        reaction: 'challenge',
        status: 'open',
        replies: []
      }
    ]
  },
  {
    id: 'ann-002',
    documentId: 'BOYKA-SRC-001',
    pageNumber: 3,
    selectedText: 'Dynamic execution graphs that adjust depth per query.',
    myUnderstanding: 'This aligns directly with classical metareasoning (Russell & Wefald 1991) and anytime computation (Horvitz 1987). Instead of allocating 32 reasoning steps to "What is 2+2?", the runtime classifies query complexity upfront.',
    assessmentKind: 'AGREE',
    discussionStatus: 'RESOLVED',
    createdDate: '2026-09-20',
    comments: [
      {
        id: 'c-003',
        author: 'Arun Kumar (Candidate CTO)',
        role: 'Candidate Founding CTO',
        timestamp: '2026-09-20 15:45',
        targetType: 'document',
        targetId: 'ann-002',
        text: 'This is the strongest technical thesis in the document. The key bottleneck is ensuring the classifier itself takes <1ms and <0.5% total query FLOPs to prevent the classical Utility Problem (deliberation cost exceeding execution savings).',
        reaction: 'agree',
        status: 'resolved'
      }
    ]
  },
  {
    id: 'ann-003',
    documentId: 'BOYKA-SRC-003', // Part III - Rebuilding AI stack
    pageNumber: 2,
    selectedText: 'Custom silicon accelerator architecture with co-designed compiler.',
    myUnderstanding: 'The proposal envisions full vertical integration: custom ASICs, optical interconnects, and bespoke compilers to bypass GPU memory wall constraints.',
    assessmentKind: 'CHALLENGE',
    discussionStatus: 'OPEN',
    createdDate: '2026-09-21',
    comments: [
      {
        id: 'c-004',
        author: 'Arun Kumar (Candidate CTO)',
        role: 'Candidate Founding CTO',
        timestamp: '2026-09-21 11:10',
        targetType: 'document',
        targetId: 'ann-003',
        text: '[SCENARIO ASSUMPTION — NOT MEASURED] I strongly recommend an explicit Silicon Gating Policy here. Custom tape-outs cost $25M-$50M and take 24-36 months. We should prove our algorithmic runtime on NVIDIA Triton / vLLM / CUDA kernels first. If we reach >85% Model FLOPs Utilization on commodity hardware and hit a physical hardware interconnect wall that software cannot overcome, only then do we present a silicon business case.',
        reaction: 'challenge',
        status: 'open'
      }
    ]
  },
  {
    id: 'ann-004',
    documentId: 'BOYKA-SRC-002', // Part II
    pageNumber: 4,
    selectedText: 'Zero-configuration drop-in replacement for OpenAI API endpoints.',
    myUnderstanding: 'The product delivery vector is a transparent proxy gateway adhering to the OpenAI / Anthropic REST specification, dynamically optimizing routing under the hood.',
    assessmentKind: 'AGREE',
    discussionStatus: 'RESOLVED',
    createdDate: '2026-09-21',
    comments: [
      {
        id: 'c-005',
        author: 'Arun Kumar (Candidate CTO)',
        role: 'Candidate Founding CTO',
        timestamp: '2026-09-21 16:20',
        targetType: 'document',
        targetId: 'ann-004',
        text: 'This is the exact right commercial beachhead. It lowers customer adoption friction to changing a single base_url in their SDK. Zero engineering changes required for developers.',
        reaction: 'agree',
        status: 'resolved'
      }
    ]
  }
];
