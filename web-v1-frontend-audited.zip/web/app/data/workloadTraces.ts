import { WorkloadTraceNode } from '../types';

export interface WorkloadProfile {
  id: string;
  name: string;
  domain: string;
  targetSLA: string;
  baselineBottleneck: string;
  nodes: WorkloadTraceNode[];
}

export const WORKLOAD_TRACES: WorkloadProfile[] = [
  {
    id: 'WL-01',
    name: 'Multi-Step Mathematical & Algorithmic Reasoning',
    domain: 'Complex Logic / GSM8K / MATH / Code Generation',
    targetSLA: '[SCENARIO ASSUMPTION — NOT MEASURED] Accuracy > 90%, Response Time < 6.0s, Cost < $0.002 per query',
    baselineBottleneck: 'Unchecked autoregressive token expansion (8k-16k tokens generated even for solved questions), exhausting GPU HBM bandwidth.',
    nodes: [
      {
        step: 'USER_REQUIREMENT',
        title: 'User / Customer Requirement',
        description: '[SCENARIO ASSUMPTION — NOT MEASURED] Enterprise developer submits high-value logic query requiring verifiable mathematical certainty without paying $0.05/query.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Accuracy threshold: 92%', 'Latency SLA: < 6.0s', 'Expected daily volume: 500,000 queries'],
        boykaObservation: 'Customer cannot tolerate stochastic hallucinations or 15-second latency timeouts on customer-facing calculations.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Verified with target fintech / legal prospect requirements.'
      },
      {
        step: 'WORKLOAD',
        title: 'Workload Characteristics',
        description: 'Input length: 450 tokens. Expected reasoning chain: 6-18 intermediate calculation steps.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Input tokens: 450', 'Output tokens: 1,200 (average)', 'Peak tokens (baseline): 8,192'],
        boykaObservation: '62% of queries reach a stable, correct numerical state within the first 4 reasoning steps.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Empirically supported by GSM8K token distribution analysis.'
      },
      {
        step: 'SOFTWARE_BEHAVIOR',
        title: 'Software Behavior & Algorithmic Loop',
        description: 'Lightweight classifier routes query to 8B draft generator. Per-step verifier computes cumulative log-odds ratio after each step.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Classifier overhead: 1.4 ms', 'Step verifier scoring: 1.8 ms/step', 'SPRT confidence threshold: 0.985'],
        boykaObservation: 'Once SPRT cumulative likelihood crosses boundary A, cancellation signal terminates further token generation.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Validated in BOYKA computing lab prototype.'
      },
      {
        step: 'PROFILE',
        title: 'Systems & Compute Profile',
        description: 'Arithmetic intensity drops to memory-bound regime (1.2 FLOP/byte) during single-token autoregressive decoding phase.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Arithmetic intensity: 1.2 FLOP/B', 'SM Tensor Core active time: 18%', 'Memory controller busy: 94%'],
        boykaObservation: 'GPU is bottlenecked entirely on loading 70B parameter weights from HBM to register files once per token.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Measured using NVIDIA Nsight Systems and PyTorch Profiler.'
      },
      {
        step: 'BOTTLENECK',
        title: 'System Bottleneck Identification',
        description: 'Every unneeded reasoning token forces a full 140 GB/s HBM round-trip of the model weight matrix and adds 128 bytes to KV-cache.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Wasted HBM bandwidth: 580 GB per query', 'Wasted KV memory: 4.2 MB per query stream'],
        boykaObservation: 'The primary bottleneck is not floating-point arithmetic; it is memory bandwidth exhaustion from useless token generation.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Proven by roofline model calculation.'
      },
      {
        step: 'ARCHITECTURE_REQUIREMENT',
        title: 'Architecture & Runtime Requirement',
        description: 'The inference runtime must support non-blocking asynchronous early exit and instant return of uncommitted KV pages.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Cancellation propagation time: < 200 μs', 'Lockless page reclaiming: atomic CAS'],
        boykaObservation: 'Standard continuous batching engines must be patched to decouple generation termination from request completion.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Implemented via custom vLLM scheduler hooks.'
      },
      {
        step: 'HARDWARE_REQUIREMENT',
        title: 'Hardware & Silicon Requirement',
        description: 'Commodity GPU with high memory bandwidth (HBM3/HBM3e >= 3.0 TB/s) and NVLink for Tensor Parallelism (TP=4 or TP=8).',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Memory bandwidth: >= 3.0 TB/s', 'VRAM capacity: >= 80 GB', 'PCIe: Gen5 x16 (64 GB/s)'],
        boykaObservation: 'NVIDIA H100 SXM5 or H200 satisfies 100% of physical requirements. Custom ASIC is economically unjustified.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Satisfied by commodity COTS hardware.'
      },
      {
        step: 'PHYSICAL_SYSTEM_REQUIREMENT',
        title: 'Physical System Requirement (Node & Rack)',
        description: 'Standard 8-GPU HGX server node in 40kW colocation rack with air or direct-to-chip water cooling.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED] Node power: 8.4 kW', 'Rack density: 40 kW', 'Junction temp Tj: < 78°C'],
        boykaObservation: 'Zero custom rack or liquid immersion needed. Standard datacenter colocation envelope is completely preserved.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Standard industry operational envelope.'
      }
    ]
  },
  {
    id: 'WL-02',
    name: 'High-Concurrency Enterprise API Gateway',
    domain: 'Enterprise SaaS / Mixed Prompt Distribution / 1,000 req/s',
    targetSLA: '[SCENARIO ASSUMPTION — NOT MEASURED] P99 Latency < 450ms, Concurrency > 1,500 active streams, Cost reduction > 50%',
    baselineBottleneck: 'KV-cache HBM exhaustion causing queueing delays and token drops under concurrency spikes.',
    nodes: [
      {
        step: 'USER_REQUIREMENT',
        title: 'User / Customer Requirement',
        description: 'Enterprise replaces standard OpenAI / Anthropic endpoints with BOYKA gateway with identical API compatibility.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Concurrency: 1,500 simultaneous streams', 'Availability: 99.99%', 'Protocol: OpenAI /v1/chat/completions'],
        boykaObservation: 'Customer will not rewrite prompt pipelines; drop-in reverse proxy is mandatory.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Customer validation ongoing.'
      },
      {
        step: 'WORKLOAD',
        title: 'Workload Characteristics',
        description: 'Bimodal distribution: 75% short extraction/summarization (< 300 tokens), 25% deep analytic queries (> 2,000 tokens).',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Short query fraction: 75%', 'Deep query fraction: 25%', 'Request rate: 1,000 req/s'],
        boykaObservation: 'Treating all queries uniformly forces the serving cluster to provision for worst-case 70B parameter inference.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Empirical enterprise telemetry distribution.'
      },
      {
        step: 'SOFTWARE_BEHAVIOR',
        title: 'Software Behavior & Algorithmic Loop',
        description: 'Sub-millisecond intent router classifies query. Short queries routed to 8B model instances; deep queries routed to 70B instances.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Router latency: 0.8 ms', 'Short query handling: single GPU (TP=1)', 'Deep query handling: 8 GPUs (TP=8)'],
        boykaObservation: '75% of query volume is completely isolated from multi-GPU NVLink collective synchronization overhead.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Demonstrated in BOYKA Router lab.'
      },
      {
        step: 'PROFILE',
        title: 'Systems & Compute Profile',
        description: 'Cluster memory utilization stabilizes below 70% HBM capacity due to lower parameter footprint on 75% of traffic.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Cluster HBM occupancy: 68%', 'Average MFU: 42%', 'Queueing wait time: < 15 ms'],
        boykaObservation: 'Dramatic reduction in preemption events and continuous batching stalls.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Simulated via cluster scheduling trace.'
      },
      {
        step: 'BOTTLENECK',
        title: 'System Bottleneck Identification',
        description: 'Network socket I/O and host CPU context switching handling 1,000 concurrent HTTP streaming connections.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Host CPU network utilization: 45%', 'Epoll event loop latency: 120 μs'],
        boykaObservation: 'Bottleneck shifts from GPU memory bandwidth to host server network I/O and Python asyncio runtime limits.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Measured on 128-core AMD EPYC host.'
      },
      {
        step: 'ARCHITECTURE_REQUIREMENT',
        title: 'Architecture & Runtime Requirement',
        description: 'Rust-based high-throughput reverse proxy (Axum / Tokio) fronting the Python inference engine to offload socket management.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Proxy throughput: 50,000 req/s', 'Proxy latency overhead: < 100 μs'],
        boykaObservation: 'Zero GPU cycles wasted on HTTP connection management.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Architecture verified in gateway design.'
      },
      {
        step: 'HARDWARE_REQUIREMENT',
        title: 'Hardware & Silicon Requirement',
        description: 'Dual 100GbE / 200GbE network interface cards (NICs) with hardware RoCE / SR-IOV support.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED]', 'Network bandwidth: 200 Gbps', 'Host RAM: 1.5 TB DDR5'],
        boykaObservation: 'COTS NIC hardware (NVIDIA ConnectX-6/7). Zero custom silicon needed.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Commodity hardware standard.'
      },
      {
        step: 'PHYSICAL_SYSTEM_REQUIREMENT',
        title: 'Physical System Requirement (Node & Rack)',
        description: 'Redundant power feeds (A+B), Top-of-Rack 100GbE Leaf switch, standard 48V rack PDU.',
        quantifiedParams: ['[SCENARIO ASSUMPTION — NOT MEASURED] Switch ports: 32x 100GbE QSFP28', 'PDU redundancy: N+1'],
        boykaObservation: 'Full compatibility with standard Tier 3 enterprise datacenters.',
        unknownStatus: '[BLUEPRINT STATEMENT — NOT R12 EVIDENCE] Standard colocation compliance.'
      }
    ]
  }
];
