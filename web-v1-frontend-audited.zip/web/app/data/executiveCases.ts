import { ExecutiveDecisionCase } from '../types';

export const EXECUTIVE_DECISION_CASES: ExecutiveDecisionCase[] = [
  {
    id: 'CASE-01',
    title: 'Prospective Enterprise Customer Demands On-Premise Proprietary Hardware Port',
    dilemmaSummary: '[SCENARIO ASSUMPTION — NOT MEASURED] A Tier-1 financial institution offers a $2.5M ARR contract on the condition that BOYKA ports its metareasoning runtime to an exotic proprietary on-premise NPU accelerator rather than supporting standard NVIDIA H100 servers.',
    context: 'The prospective client refuses cloud deployment due to data residency mandates and has an existing fleet of non-CUDA accelerators. Accepting requires dedicating 4 out of 6 engineers for 7 months to rewrite custom Triton kernels into a vendor-specific low-level compiler.',
    perspectives: {
      ceo: '[SCENARIO ASSUMPTION — NOT MEASURED] The $2.5M ARR contract validates market demand, provides multi-year runway, and gives BOYKA an enterprise anchor logo. Urges the team to evaluate if this can be fulfilled without killing core roadmap velocity.',
      cto: 'Recommends strict rejection or counter-proposal. Rewriting the runtime for an exotic NPU diverts the entire engineering team from completing EXP-RP01-001 on standard H100s. Porting to proprietary silicon creates an unmaintainable codebase fork and freezes our primary competitive moat.',
      product: 'Warns that building custom one-off hardware integrations turns BOYKA from a scalable software platform into a low-margin professional services consultancy.',
      finance: '[SCENARIO ASSUMPTION — NOT MEASURED] Notes that while $2.5M ARR is attractive, the opportunity cost of delaying the general commercial release by 7 months will cause us to miss the Series A fundraising window, requiring an emergency bridge round.',
      sales: '[SCENARIO ASSUMPTION — NOT MEASURED] Argues strongly for accepting the deal, warning that walking away from a $2.5M contract hands the customer directly to competing enterprise AI vendors.',
      security: 'Confirms that on-premise deployment satisfies the client\'s regulatory data residency requirements, but notes that vendor NPU firmware lacks SOC 2 Type II audit logs.',
      legal: '[SCENARIO ASSUMPTION — NOT MEASURED] Highlights that the customer contract imposes severe SLA penalty clauses ($50k/day) for delivery delays, creating catastrophic legal liability if compiler porting fails.'
    },
    informationFlow: [
      '1. Sales logs customer RFP requirement for proprietary NPU support.',
      '2. CTO performs 48-hour technical spike on vendor compiler SDK, uncovering undocumented driver bugs and missing dynamic shape support.',
      '3. Product & Finance analyze gross margin and opportunity cost of engineering diversion.',
      '4. CEO convenes Executive Governance Session to review CTO technical assessment.'
    ],
    decisionAuthority: 'Joint CEO & CTO veto authority over customer architectural deviations that impact core company roadmap.',
    tradeOffsEvaluated: [
      '[SCENARIO ASSUMPTION — NOT MEASURED] Short-term $2.5M ARR vs. Long-term platform scalability and product velocity.',
      'Customer-specific proprietary NPU fork vs. Universal COTS NVIDIA/AMD GPU compatibility.',
      'Consulting services revenue vs. High-multiple SaaS / infrastructure software valuation.'
    ],
    resultingAction: 'Formal Counter-Offer: Reject proprietary NPU port. Offer customer a dedicated VPC or air-gapped on-premise deployment using standard NVIDIA H100 certified servers running BOYKA Container Appliance. If rejected by client, gracefully decline the contract.',
    followUpReviewGate: 'Customer response deadline: 14 days. If customer agrees to certified H100 appliance, onboard within standard 3-week enterprise SLA.'
  },
  {
    id: 'CASE-02',
    title: '[SCENARIO ASSUMPTION — NOT MEASURED] Custom Silicon ASIC Program Proposal ($25M Capital Expenditure)',
    dilemmaSummary: '[SCENARIO ASSUMPTION — NOT MEASURED] An external hardware consortium proposes that BOYKA partner on a 3nm custom ASIC tape-out, requiring a $25M capital expenditure commitment and a 36-month development cycle to manufacture a dedicated "SPRT Early-Exit Processor".',
    context: '[SCENARIO ASSUMPTION — NOT MEASURED] The consortium claims the chip will achieve 5x better token energy efficiency than NVIDIA Blackwell. However, BOYKA currently runs on cloud H100 instances, has not fully optimized its software compiler layer, and has unproven production workload traces.',
    perspectives: {
      ceo: '[SCENARIO ASSUMPTION — NOT MEASURED] Recognizes the massive valuation upside of being perceived as a full-stack silicon AI company, but understands that a $25M capital requirement forces an immediate mega-round with severe founder dilution and catastrophic liquidation preferences.',
      cto: 'Unequivocal recommendation: VETO THE PROPOSAL. Custom silicon is completely premature. We have not yet hit the physical limits of COTS H100/H200 GPUs. The proposed 3-year silicon manufacturing cycle guarantees that NVIDIA will ship two new architecture generations (Blackwell and Rubin) before our first silicon brings up, making our chip obsolete before it arrives.',
      product: 'Warns that hardware lock-in prevents rapid model adaptation. If transformer reasoning shifts to state-space models or recursive neural networks, hardwired ASIC matrix multipliers become useless silicon paperweights.',
      finance: '[SCENARIO ASSUMPTION — NOT MEASURED] Reports that committing to $25M in NRE fees and mask costs would consume 100% of prospective Series A capital, leaving zero operating budget for software engineering, customer deployment, or sales.',
      sales: 'Confirms that not a single enterprise customer has asked for proprietary chips; customers care exclusively about API latency, cost per 1k tokens, and 99.99% uptime.',
      security: 'Points out that bringing up novel custom silicon introduces untracked side-channel vulnerabilities, rowhammer-style memory risks, and uncertified cryptographic hardware root of trust.',
      legal: 'Identifies onerous IP cross-licensing clauses in the consortium agreement that would grant the hardware partner joint ownership over BOYKA\'s proprietary metareasoning algorithms.'
    },
    informationFlow: [
      '1. Hardware consortium submits 64-page term sheet and NRE cost schedule to CEO.',
      '2. CTO convenes Technical Gating Review to evaluate against the Custom Silicon Decision Tree.',
      '3. CTO derives that 82% of current system latency resides in host-device synchronization and memory bandwidth, which software PagedAttention and Triton kernels can resolve on COTS hardware.',
      '[SCENARIO ASSUMPTION — NOT MEASURED] 4. Finance models cash burn trajectory under $25M capital commitment.'
    ],
    decisionAuthority: 'CTO holds absolute technical gating authority over silicon tape-out expenditure; CEO holds capital allocation authority.',
    tradeOffsEvaluated: [
      '[SCENARIO ASSUMPTION — NOT MEASURED] Theoretical 5x silicon energy gain vs. 36-month execution risk and rapid COTS obsolescence.',
      '[SCENARIO ASSUMPTION — NOT MEASURED] Extreme $25M capital intensity and dilution vs. Capital-efficient software runtime scaling.',
      'Proprietary silicon IP ownership vs. Multi-vendor flexibility across NVIDIA, AMD, and cloud TPUs.'
    ],
    resultingAction: 'Formally Decline Silicon Program. Re-affirm Software-First Silicon Gating Policy: Custom silicon development remains strictly frozen until BOYKA processes at least 1 billion queries/day on commodity GPUs and identifies an insurmountable physical bottleneck.',
    followUpReviewGate: '[SCENARIO ASSUMPTION — NOT MEASURED] Annual Silicon Gating Review: Re-evaluate hardware roadmap only after Series B funding and after establishing 100,000 GPU-hours of verified production workload traces.'
  },
  {
    id: 'CASE-03',
    title: 'Verifier Accuracy Regression in Production Enterprise Customer Pilot',
    dilemmaSummary: 'During a live production pilot with a major healthcare diagnostics client, the verifier model begins falsely approving incomplete reasoning chains, causing a 14% accuracy drop on complex clinical protocol lookups.',
    context: 'The client threatens immediate pilot termination if hallucinated clinical citations persist. The issue emerged after the client ingested 40,000 pages of unstructured internal clinical trial records that were not represented in BOYKA\'s pre-deployment benchmark suite.',
    perspectives: {
      ceo: 'Treats this as an existential commercial threat to BOYKA\'s enterprise reputation. Demands immediate client communication and an emergency technical resolution within 24 hours.',
      cto: 'Activates Emergency Technical Incident Protocol. Root cause: out-of-distribution confidence calibration drift. The step verifier\'s log-odds output was calibrated on academic benchmarks (GSM8K/MATH) where step semantics are structured; it fails to detect subtle domain hallucinations in unstructured medical prose. Immediately deploys a runtime circuit-breaker: force verifier confidence threshold to 0.999 (disabling early exit and falling back to full-depth verification) for the client\'s endpoint.',
      product: 'Reroutes all client queries to standard frontier model fallback while the engineering team isolates the regression. Establishes a client-specific Golden Evaluation Set from historical audited transcripts.',
      finance: '[SCENARIO ASSUMPTION — NOT MEASURED] Approves an emergency $10,000 cloud GPU compute allocation to fine-tune and calibrate a domain-adapted Process Reward Model (PRM) on medical clinical guidelines.',
      sales: 'Maintains hourly transparent updates with the client\'s VP of Engineering, sharing raw telemetry logs and the exact remediation timeline.',
      security: 'Conducts an immediate audit to ensure client clinical data used for emergency fine-tuning is strictly isolated in an air-gapped tenant VPC with zero cross-tenant contamination.',
      legal: 'Reviews the pilot enterprise SLA agreement to confirm that pilot terms disclaim consequential damages, protecting the company from financial liability while remediation is executed.'
    },
    informationFlow: [
      '1. Client automated test harness triggers error rate alert; webhook pings BOYKA PagerDuty.',
      '2. CTO and Lead ML Systems Engineer diagnose logit distribution drift in telemetry database.',
      '3. CTO executes immediate configuration update to raise SPRT stopping boundary from 0.98 to 0.999.',
      '4. Executive team conducts incident post-mortem with client engineering leadership.'
    ],
    decisionAuthority: 'CTO has immediate operational authority to alter runtime stopping thresholds, deploy circuit-breakers, or force model fallbacks.',
    tradeOffsEvaluated: [
      'Cost efficiency (token savings) vs. Solution accuracy and client safety: Accuracy ALWAYS takes absolute precedence.',
      'Automated early exit vs. Strict conservative full-pass generation during domain distribution shift.',
      'Speed of hotfix vs. Rigorous statistical verification of new calibration parameters.'
    ],
    resultingAction: '1. Immediate circuit-breaker: Force full-depth verification (SPRT threshold = 0.999), restoring baseline accuracy to 94.6% within 45 minutes.\n2. Ingest 500 validated medical reasoning pairs into calibration harness.\n3. Deploy domain-specific temperature-scaled verifier within 72 hours, recovering 38% token savings while maintaining 94%+ accuracy.',
    followUpReviewGate: '72-Hour Post-Mortem & Client Golden Benchmark Verification: Present audited calibration curve and Brier score metrics directly to client VP of Engineering.'
  }
];
