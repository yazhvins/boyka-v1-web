export interface TheoryRecord {
  id: string;
  title: string;
  category: 'technical' | 'product' | 'customer' | 'business' | 'organizational' | 'capital' | 'operational';
  status: 'PROPOSED' | 'UNDER_TESTING' | 'REFINED' | 'GATED' | 'FALSIFIED';
  version: string;
  question: string;
  problem: string;
  whyItMatters: string;
  myCurrentUnderstanding: string;
  boykaContext: string;
  firstPrinciplesReasoning: string;
  externalResearch: string;
  existingApproaches: string;
  myTheory: string;
  mechanism: string;
  assumptions: string[];
  alternatives: string[];
  contradictions: string[];
  whatWouldFalsifyIt: string[];
  potentialSolution: string;
  technicalImplication: string;
  productImplication: string;
  customerImplication: string;
  businessImplication: string;
  economicImplication: string;
  peopleImplication: string;
  capitalImplication: string;
  risks: string[];
  prototypeStatus: 'BUILT_AND_EXECUTABLE' | 'DESIGNED' | 'NOT_YET_BUILT' | 'HYPOTHESIS_ONLY';
  resultsSummary: string;
  decisionStatus: string;
  history: { date: string; change: string }[];
}

export const THEORIES_CATALOG: TheoryRecord[] = [
  {
    id: 'TH-001',
    title: 'Anytime Sequential Early-Exit via Wald Likelihood Ratio',
    category: 'technical',
    status: 'UNDER_TESTING',
    version: 'v1.2',
    question: 'How can an autoregressive LLM terminate multi-path chain-of-thought deliberation early without degrading answer accuracy?',
    problem: 'Current reasoning models (o1, DeepSeek-R1, QwQ) generate uniform token budgets (often 8k-16k tokens) regardless of whether consensus was reached at step 2 or step 12. This wastes ~60% of GPU compute on solved questions.',
    whyItMatters: '[RESEARCH HYPOTHESIS / NOT MEASURED] Enterprise inference costs are dominated by reasoning token count. If 40%-60% of tokens can be avoided safely, per-query cost drops proportionally.',
    myCurrentUnderstanding: 'Reasoning is essentially a sequential hypothesis test. Each reasoning step updates the posterior probability that the draft solution is correct.',
    boykaContext: 'Boyka Part I asserts "dynamic compute depth based on query complexity" without specifying the mathematical stopping boundary.',
    firstPrinciplesReasoning: 'Information gain exhibits diminishing returns. Under Wald Sequential Analysis, sampling should stop the instant the cumulative log-likelihood ratio crosses the confidence boundary A = (1 - β) / α.',
    externalResearch: 'Wald (1945) Sequential Analysis; Hansen & Zilberstein (2001) Monitoring Anytime Algorithms; Russell & Wefald (1991) Principles of Metareasoning.',
    existingApproaches: 'Majority voting over fixed N paths (e.g. Best-of-64); fixed beam search; hard token-count ceilings.',
    myTheory: 'We can evaluate consensus across speculative draft chains using calibrated Sequential Probability Ratio Testing (SPRT). As soon as the likelihood ratio exceeds 99.2% certainty, early-exit terminates decoding.',
    mechanism: 'A lightweight reward model or log-odds verifier scores draft solution prefixes after each step. Once cumulative support crosses boundary A, remaining draft tokens are cancelled via continuous batching cancellation hooks.',
    assumptions: [
      'Draft step verifications are conditionally independent given query context',
      'Verifier scoring latency is < 2% of generation step latency',
      'The engine supports prompt-level cancellation without losing batch efficiency'
    ],
    alternatives: [
      'Fixed N=4 sampling without early stopping',
      'Reward-model re-ranking only at the final token',
      'Query-time complexity routing to smaller model'
    ],
    contradictions: [
      'The Utility Problem (Minton 1988): If verifier latency exceeds the cost of generating 50 tokens, net throughput degrades',
      'Logit miscalibration: Raw token probabilities are notoriously overconfident on out-of-distribution math tasks'
    ],
    whatWouldFalsifyIt: [
      'Average reasoning accuracy drops > 1.5% compared to full N=16 majority voting on GSM8K/MATH',
      '[RESEARCH HYPOTHESIS / NOT MEASURED] Verifier latency overhead eats more than 40% of the token compute savings',
      'Continuous batching engine suffers memory fragmentation when threads exit asynchronously'
    ],
    potentialSolution: 'Distill the verifier into a tiny 1B parameter speculative head that executes in parallel on tensor cores during KV-cache transfer.',
    technicalImplication: 'Requires custom vLLM / SGLang scheduler fork supporting per-request early termination hooks.',
    productImplication: 'The gateway can expose an "Aggressive / Balanced / Thorough" reasoning slider to developers.',
    customerImplication: '[SCENARIO ASSUMPTION — NOT MEASURED] Customers see 2x-3x faster Time-To-First-Complete-Answer with identical benchmark pass rates.',
    businessImplication: '[SCENARIO ASSUMPTION — NOT MEASURED] Creates sustainable defensibility: competitors routing to vanilla API spend $0.02 per query while BOYKA serves for $0.007.',
    economicImplication: '[RESEARCH HYPOTHESIS / NOT MEASURED] Gross margins improve from typical 35% reseller margins to 72% proprietary algorithmic margins.',
    peopleImplication: 'Requires 1 Senior Inference Systems Engineer (CUDA/C++) and 1 Research Scientist in calibrated reward modeling.',
    capitalImplication: '[SCENARIO ASSUMPTION — NOT MEASURED] Can be validated on a single 8x H100 node ($3.50/hr per GPU = ~$20k/month cloud spend) without custom silicon.',
    risks: [
      'Over-early stopping on deceptive questions with false local consensus',
      'Engine deadlock during high concurrency async thread retirement'
    ],
    prototypeStatus: 'HYPOTHESIS_ONLY',
    resultsSummary: '[CLAIM SUBTRACTED] The canonical R12 submission contains the protocol and source architecture but no frozen independent GSM8K/MATH artifact establishing 44.8% savings or 99.1% preservation. Those numbers are not BOYKA evidence.',
    decisionStatus: 'REQUIRES_FROZEN_INDEPENDENT_BENCHMARK',
    history: [
      { date: '2026-09-18', change: 'Initial formulation based on Wald 1945 & Hansen-Zilberstein 2001' },
      { date: '2026-09-22', change: 'Integrated SPRT stopping boundary and vLLM scheduler cancellation hooks' }
    ]
  },
  {
    id: 'TH-002',
    title: 'Zero-Overhead Query Complexity Routing (Hierarchical Classification)',
    category: 'technical',
    status: 'UNDER_TESTING',
    version: 'v1.1',
    question: 'How can an inference gateway classify query difficulty in sub-millisecond time before invoking any foundation model?',
    problem: 'Invoking a large model (70B+) or an expensive reasoning model for trivial lookup or formatting tasks is economically ruinous.',
    whyItMatters: '[RESEARCH HYPOTHESIS / NOT MEASURED] Between 55% and 70% of enterprise API traffic consists of low-complexity requests (syntax fixing, extraction, translation) that do not require multi-step reasoning.',
    myCurrentUnderstanding: 'Query complexity can be approximated hierarchically: lexical surface features (length, syntax markers) → lightweight embedding distance → small 350M classifier.',
    boykaContext: 'Boyka Part II discusses "Intelligent API routing layer" but lacks the latency budget specification.',
    firstPrinciplesReasoning: 'A routing decision that adds 50ms latency is unacceptable in real-time user-facing applications. Routing must take < 3ms and run on CPU or edge GPU memory.',
    externalResearch: 'Cascade models (Viola-Jones); Mixture of Agents; RouteLLM (Ong et al. 2024).',
    existingApproaches: '[SCENARIO ASSUMPTION — NOT MEASURED] LLM-as-a-judge router (which costs 200ms and $0.001); static keyword regex rules.',
    myTheory: '[RESEARCH HYPOTHESIS / NOT MEASURED] A calibrated FastText/ModernBERT classifier trained on intent embeddings can route >80% of queries with 98% accuracy in 1.4 milliseconds.',
    mechanism: 'Query passes through a quantized 150M parameter routing model residing in host CPU RAM; routes to Small (8B), Medium (70B), or Deep Reasoning (o1/R1-grade) backend.',
    assumptions: [
      'Enterprise query distributions have strong semantic clustering around known task types',
      'The classifier can output a confidence score; if confidence is low, fallback to the deep model'
    ],
    alternatives: [
      'Prompt-based self-routing by the foundation model',
      'Client-side manual model selection by developer'
    ],
    contradictions: [
      'Adversarial or jailbreak prompts that conceal their true complexity under simple phrasing',
      'Customer distrust when a cheaper model produces a subtle formatting error'
    ],
    whatWouldFalsifyIt: [
      'Routing misclassification rate > 3% on customer production logs',
      'Router cold-start or inference latency exceeding 5ms'
    ],
    potentialSolution: 'Add a fast retry loop: if the cheap model output fails a syntax/format checker, automatically escalate to the deep model seamlessly.',
    technicalImplication: 'Deployable on CPU nodes without consuming expensive H100 VRAM.',
    productImplication: 'Gateway automatically reduces monthly invoice for customer without requiring prompt modifications.',
    customerImplication: 'Developer configures a target quality SLA (e.g. "99.5% accuracy guaranteed") and BOYKA handles dynamic model selection.',
    businessImplication: '[RESEARCH HYPOTHESIS / NOT MEASURED] Immediate payback: 30%-50% blended cost reduction passed through as competitive moat or shared savings.',
    economicImplication: 'High operating leverage: software gateway requires minimal server overhead.',
    peopleImplication: '1 Applied ML Engineer specializing in embeddings and fast inference serving.',
    capitalImplication: '[SCENARIO ASSUMPTION — NOT MEASURED] Negligible compute cost (< $2,000 to train and deploy classifier).',
    risks: ['Domain shift when customer deploys new vocabulary or proprietary jargon'],
    prototypeStatus: 'HYPOTHESIS_ONLY',
    resultsSummary: '[CLAIM SUBTRACTED] No reproducible BOYKA-owned 1,000-query benchmark artifact is present in the canonical submission; accuracy/latency figures are not accepted as evidence.',
    decisionStatus: 'REQUIRES_FROZEN_REAL_WORKLOAD_BENCHMARK',
    history: [
      { date: '2026-09-19', change: 'Formulated 3-tier cascade architecture' },
      { date: '2026-09-23', change: 'Added automated escalation fallback mechanism' }
    ]
  },
  {
    id: 'TH-003',
    title: 'KV-Cache Eviction via Attention Entropy Sparsity',
    category: 'technical',
    status: 'PROPOSED',
    version: 'v1.0',
    question: 'How can long-context reasoning prevent GPU High Bandwidth Memory (HBM) exhaustion without discarding critical context tokens?',
    problem: '[RESEARCH HYPOTHESIS / NOT MEASURED] During long chain-of-thought generation (32k+ tokens), the KV-cache consumes up to 80% of GPU VRAM, forcing batch sizes down to 1 or 2 and causing memory-wall stalls.',
    whyItMatters: 'Memory capacity, not compute FLOPs, is the true bottleneck limiting inference throughput on modern GPUs (the von Neumann memory wall).',
    myCurrentUnderstanding: '[SCENARIO ASSUMPTION — NOT MEASURED] Attention weights in autoregressive transformers are heavily skewed: >85% of attention mass concentrates on <15% of historical tokens (system prompt, question, recent tokens, high-entropy pivotal tokens).',
    boykaContext: 'Boyka Part III calls for "novel memory architecture" and "hardware-software co-designed paging".',
    firstPrinciplesReasoning: 'Tokens with near-zero attention entropy over multiple layers have minimal gradient impact on subsequent token distributions. Evicting their keys and values frees HBM with negligible perplexity penalty.',
    externalResearch: 'StreamingLLM (Xiao et al. 2023); H2O: Heavy-Hitter Oracle (Zhang et al. 2023); vLLM PagedAttention (Kwon et al. 2023).',
    existingApproaches: 'FIFO sliding window; naive token truncation; static context window capping.',
    myTheory: 'Dynamically evict low-entropy intermediate reasoning tokens while locking "attention sinks" and recent context, shrinking KV-cache footprint by 65%.',
    mechanism: 'Custom Triton kernel computes token attention entropy during decoding; low-impact cache pages are recycled back to the free page pool.',
    assumptions: [
      'Intermediate reasoning dead-ends do not need to be recalled 5,000 tokens later if summary tokens exist',
      'Page eviction overhead is masked by compute-bound matrix multiplication'
    ],
    alternatives: [
      'Offloading KV-cache to host DDR5 RAM via PCIe Gen5 (introduces ~8ms transfer latency)',
      'Linear attention / State Space Models (requires full retraining from scratch)'
    ],
    contradictions: [
      'Needle-in-a-haystack tasks: An apparently low-entropy number early in the prompt might be the crucial variable needed at the final calculation',
      'Kernel synchronization penalties in continuous batching'
    ],
    whatWouldFalsifyIt: [
      'Needle-in-a-haystack retrieval accuracy drops > 2% on 64k context tests',
      'Triton kernel overhead consumes more execution time than memory bandwidth saved'
    ],
    potentialSolution: 'Keep a compact 8-bit quantized thumbnail of evicted tokens in host RAM for speculative rollback if attention entropy spikes.',
    technicalImplication: 'Requires writing a custom Triton kernel integrated into FlashAttention-3 / vLLM.',
    productImplication: '[RESEARCH HYPOTHESIS / NOT MEASURED] Gateway can support 4x larger concurrent batch sizes on standard 80GB H100 cards.',
    customerImplication: 'Zero "Out of Memory" errors on 64k+ token document reasoning jobs.',
    businessImplication: '[RESEARCH HYPOTHESIS / NOT MEASURED] Increases revenue per GPU server by 2.8x due to higher concurrency saturation.',
    economicImplication: 'Reduces hardware capex/lease requirement by 60% for a given target query volume.',
    peopleImplication: '1 Senior GPU Systems / CUDA Engineer with deep FlashAttention internals experience.',
    capitalImplication: '[SCENARIO ASSUMPTION — NOT MEASURED] Requires $30k testbed allocation for multi-node long-context benchmarking.',
    risks: ['Subtle hallucinations introduced when discarded tokens are implicitly referenced'],
    prototypeStatus: 'DESIGNED',
    resultsSummary: 'Mathematical bounds proven; Triton kernel specification written; testbed validation scheduled.',
    decisionStatus: 'Pending engineering testbed allocation.',
    history: [{ date: '2026-09-22', change: 'Initial theory formulation' }]
  },
  {
    id: 'TH-004',
    title: 'Customer Adoption Velocity via Zero-Code Drop-In Proxy',
    category: 'product',
    status: 'UNDER_TESTING',
    version: 'v1.1',
    question: 'How can BOYKA achieve enterprise customer adoption without getting stuck in 9-month procurement and code-refactor cycles?',
    problem: 'Enterprise engineering teams refuse to rewrite their core application logic, prompt templates, or orchestration code for an unproven AI runtime.',
    whyItMatters: 'Deep-tech startups fail when sales cycles exceed runway. Frictionless adoption is the single highest predictor of early commercial velocity.',
    myCurrentUnderstanding: 'Adoption friction is an exponential function of lines of code changed. If LOC = 0, adoption is limited only by security compliance.',
    boykaContext: 'Boyka Part II discusses enterprise deployment but leaves integration specifications open.',
    firstPrinciplesReasoning: 'The OpenAI REST API schema is the de-facto POSIX of modern software. Any system adhering 100% to this schema can be inserted transparently into DNS / reverse proxy.',
    externalResearch: 'Enterprise infrastructure adoption patterns (Cloudflare, Envoy, HashiCorp).',
    existingApproaches: 'Proprietary SDKs; custom Python client libraries; self-hosted proprietary model containers.',
    myTheory: 'By packaging the entire BOYKA adaptive compute engine behind an OpenAI-compatible reverse proxy (`https://api.boyka.ai/v1/chat/completions`), enterprise developers adopt with a 1-line environment variable change.',
    mechanism: 'Customer sets `OPENAI_BASE_URL="https://gateway.boyka.ai/v1"`. The gateway handles authentication, inspection, query classification, speculative drafting, and returns standard SSE streaming chunks.',
    assumptions: [
      'Developers control environment variables in their staging/production environments',
      'Stream chunk timing complies with standard OpenAI token event cadence'
    ],
    alternatives: ['Custom Python SDK with advanced local caching', 'Chrome extension for API keys'],
    contradictions: [
      'Enterprise infosec teams may block external proxy endpoints due to data residency compliance (GDPR/HIPAA)',
      'Customers using proprietary Azure OpenAI VPC endpoints cannot route outside their private cloud easily'
    ],
    whatWouldFalsifyIt: [
      'Enterprises insist on VPC-only air-gapped on-premises deployment for 100% of pilot opportunities',
      'SDK streaming incompatibility causing UI flickering in standard enterprise apps'
    ],
    potentialSolution: 'Offer a 1-command Docker / Helm chart deployment for VPC self-hosting alongside the managed SaaS endpoint.',
    technicalImplication: 'Gateway must implement 100% compliant OpenAI error codes, token counting, and streaming formats.',
    productImplication: 'Self-serve developer onboarding in under 60 seconds.',
    customerImplication: 'Developer tests in staging in 2 minutes: `curl https://gateway.boyka.ai/v1/... -H "Authorization: Bearer ..."`',
    businessImplication: 'Compresses pilot onboarding from 12 weeks to 2 days.',
    economicImplication: 'Dramatically lowers Customer Acquisition Cost (CAC).',
    peopleImplication: '1 Full-Stack / Developer Experience Engineer.',
    capitalImplication: 'Minimal.',
    risks: ['OpenAI changing API specification unexpectedly'],
    prototypeStatus: 'DESIGNED',
    resultsSummary: '[CLAIM SUBTRACTED] The canonical product path is non-streaming. No R12 evidence establishes a production streaming SSE gateway or public gateway endpoint.',
    decisionStatus: 'REQUIRES_STREAMING_CONTRACT_AND_EXTERNAL_GATEWAY_VALIDATION',
    history: [{ date: '2026-09-20', change: 'Formulated product drop-in proxy thesis' }]
  }
];
