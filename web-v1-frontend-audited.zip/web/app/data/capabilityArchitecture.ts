import { TechnicalCapabilitySpec } from '../types';

export const TECHNICAL_CAPABILITIES: TechnicalCapabilitySpec[] = [
  {
    id: 'CAP-01',
    discipline: 'AI / ML Research & Metareasoning',
    domain: 'AI_ALGORITHMS',
    whyRequired: 'Formulate mathematical stopping boundaries (Wald SPRT), evaluate uncertainty calibration, and design test-time compute search policies.',
    whenRequiredStage: 'FORMATION',
    prerequisiteDependency: 'None (Founding core capability)',
    sourcingOption: 'FOUNDER_CORE',
    hiringTrigger: 'Covered by Founding CTO. A dedicated research scientist is only justified if BOYKA expands into novel multi-modal reasoning architectures.',
    persistentJustification: 'Core IP generator. Must be anchored in executive leadership from Day 1.'
  },
  {
    id: 'CAP-02',
    discipline: 'ML Systems & Model Serving',
    domain: 'SYSTEMS_SOFTWARE',
    whyRequired: 'Deploy and orchestrate open-weight models (Llama-3.3, DeepSeek-R1), configure continuous batching engines, and manage multi-GPU tensor parallelism.',
    whenRequiredStage: 'PROTOTYPE',
    prerequisiteDependency: 'Validated baseline micro-benchmarks on cloud GPUs',
    sourcingOption: 'FOUNDER_CORE',
    hiringTrigger: 'Transition to dedicated Full-Time Employee when customer pilot traffic exceeds 100 concurrent requests requiring 24/7 uptime.',
    persistentJustification: 'High operational demand; continuously tuning serving parameters to incoming customer traffic.'
  },
  {
    id: 'CAP-03',
    discipline: 'GPU Performance Engineering (CUDA / Triton)',
    domain: 'SYSTEMS_SOFTWARE',
    whyRequired: 'Write high-throughput custom Triton kernels for asynchronous log-likelihood ratio reduction, custom FlashAttention masks, and memory-fused stopping checks.',
    whenRequiredStage: 'PROTOTYPE',
    prerequisiteDependency: 'Mathematical specification of SPRT early-exit reduction loop',
    sourcingOption: 'CONTRACT_SPECIALIST',
    hiringTrigger: 'Hire dedicated FTE only when kernel optimization becomes a continuous weekly requirement rather than periodic milestone sprints.',
    persistentJustification: 'Specialist skill set; in early stages, a world-class contractor delivering 2-week kernel sprints is significantly more capital-efficient.'
  },
  {
    id: 'CAP-04',
    discipline: 'Inference Runtime & Scheduler Architecture',
    domain: 'SYSTEMS_SOFTWARE',
    whyRequired: 'Hack upstream vLLM/SGLang scheduler to support non-blocking lockless memory block reclaiming and dynamic batch preemption upon early exit.',
    whenRequiredStage: 'MVP',
    prerequisiteDependency: 'EXP-RP01-001 proof of token savings on isolated worker',
    sourcingOption: 'FULL_TIME_EMPLOYEE',
    hiringTrigger: 'Triggered when multi-user batching scheduler exhibits lock contention under high concurrency, requiring dedicated systems architecture.',
    persistentJustification: 'Primary software competitive moat; continuous maintenance of the scheduling engine is essential.'
  },
  {
    id: 'CAP-05',
    discipline: 'Graph Compilation & Operator Fusion',
    domain: 'SYSTEMS_SOFTWARE',
    whyRequired: 'Integrate PyTorch Inductor / TensorRT graph capture with dynamic shape binning to avoid kernel launch overhead during early stopping.',
    whenRequiredStage: 'MVP',
    prerequisiteDependency: 'Stable custom Triton kernels',
    sourcingOption: 'CONTRACT_SPECIALIST',
    hiringTrigger: 'Contract specialist engaged for 60-day compilation pipeline delivery; convert to FTE only if proprietary compiler fork is maintained.',
    persistentJustification: 'Discrete project deliverable; can be achieved via scoped engagement.'
  },
  {
    id: 'CAP-06',
    discipline: 'Distributed Systems & Cluster Networking',
    domain: 'SYSTEMS_SOFTWARE',
    whyRequired: 'Design cross-node inference dispatch, Anycast DNS load distribution, RDMA network queue configuration, and multi-tenant VPC isolation.',
    whenRequiredStage: 'PILOT',
    prerequisiteDependency: 'Single-node HGX deployment achieving > 90% SLA compliance',
    sourcingOption: 'FULL_TIME_EMPLOYEE',
    hiringTrigger: 'Triggered when customer deployment expands beyond a single physical server node into a multi-node cluster (> 16 GPUs).',
    persistentJustification: 'Persistent operational need as enterprise traffic scales across geographic regions.'
  },
  {
    id: 'CAP-07',
    discipline: 'Hardware Architecture Exploration & Modeling',
    domain: 'HARDWARE_SILICON',
    whyRequired: 'Perform cycle-accurate architectural simulation (Gem5, Timeloop) to model memory bandwidth bottlenecks and evaluate custom accelerator trade-offs.',
    whenRequiredStage: 'EARLY_COMMERCIAL',
    prerequisiteDependency: 'Empirical production trace proving commodity silicon cannot resolve memory bandwidth wall',
    sourcingOption: 'RESEARCH_COLLABORATOR',
    hiringTrigger: 'Triggered only if Gate DEC-HW-01 is passed (custom silicon exploration officially approved by board).',
    persistentJustification: 'Academic research collaboration is optimal for preliminary exploration without incurring silicon payroll.'
  },
  {
    id: 'CAP-08',
    discipline: 'RTL Design & Micro-Architecture',
    domain: 'HARDWARE_SILICON',
    whyRequired: 'Author synthesizable Verilog/SystemVerilog for custom matrix multiplication units, on-chip SRAM crossbars, and host DMA interfaces.',
    whenRequiredStage: 'GROWTH',
    prerequisiteDependency: '[SCENARIO ASSUMPTION — NOT MEASURED] Validated architectural simulation demonstrating >= 4x speedup over next-gen COTS GPUs',
    sourcingOption: 'NOT_YET_NEEDED',
    hiringTrigger: '[SCENARIO ASSUMPTION — NOT MEASURED] Strictly gated until Series B funding and formal tape-out capital commitment ($25M+).',
    persistentJustification: 'Premature RTL design before stable workload traces leads to guaranteed silicon obsolescence.'
  },
  {
    id: 'CAP-09',
    discipline: 'Silicon Verification & Emulation (UVM)',
    domain: 'HARDWARE_SILICON',
    whyRequired: 'Construct Universal Verification Methodology (UVM) testbenches, run hardware emulation (Zebu/Palladium), and verify corner-case numerical stability.',
    whenRequiredStage: 'GROWTH',
    prerequisiteDependency: 'Completed RTL design blocks',
    sourcingOption: 'NOT_YET_NEEDED',
    hiringTrigger: 'Triggered concurrently with RTL design phase only if custom silicon program is formally funded.',
    persistentJustification: 'Mandatory for tape-out success, but completely unnecessary during software execution stages.'
  },
  {
    id: 'CAP-10',
    discipline: 'Board Design & Hardware Power Delivery',
    domain: 'INFRASTRUCTURE_PHYSICS',
    whyRequired: 'Design high-speed PCB layouts, 48V-to-0.8V multi-phase voltage regulator modules (VRMs), and PCIe Gen5 / OAM baseboard traces.',
    whenRequiredStage: 'SCALE',
    prerequisiteDependency: 'Silicon engineering samples delivered from foundry',
    sourcingOption: 'PARTNER_VENDOR',
    hiringTrigger: 'Engage established electronic manufacturing services (EMS) partner (e.g., Celestica, Flex) rather than hiring in-house PCB layout teams.',
    persistentJustification: 'Vendor partnership provides multi-million-dollar lab test equipment without capital expenditure.'
  },
  {
    id: 'CAP-11',
    discipline: 'Firmware & Baseboard Management Controller (BMC)',
    domain: 'SYSTEMS_SOFTWARE',
    whyRequired: 'Develop low-level device firmware, OpenBMC management interfaces, IPMI telemetry hooks, and secure boot cryptographic validation.',
    whenRequiredStage: 'SCALE',
    prerequisiteDependency: 'Physical hardware prototypes in bring-up lab',
    sourcingOption: 'CONTRACT_SPECIALIST',
    hiringTrigger: 'Engage specialized firmware consultancy during hardware bring-up phase.',
    persistentJustification: 'Specialized bring-up effort with declining workload after initial validation.'
  },
  {
    id: 'CAP-12',
    discipline: 'Datacenter Network Engineering (RDMA / RoCE)',
    domain: 'INFRASTRUCTURE_PHYSICS',
    whyRequired: 'Configure leaf-spine 400Gbps network fabrics, optimize RoCE v2 Priority Flow Control (PFC) and Explicit Congestion Notification (ECN) to prevent packet loss.',
    whenRequiredStage: 'PILOT',
    prerequisiteDependency: 'Physical bare-metal colocation deployment',
    sourcingOption: 'PARTNER_VENDOR',
    hiringTrigger: 'Provided as managed service by datacenter colocation provider (e.g., Equinix, CoreWeave) during Seed/Series A.',
    persistentJustification: 'Datacenter provider already maintains 24/7 network operations center (NOC).'
  },
  {
    id: 'CAP-13',
    discipline: 'Thermal & Mechanical Infrastructure Engineering',
    domain: 'INFRASTRUCTURE_PHYSICS',
    whyRequired: 'Simulate computational fluid dynamics (CFD), analyze cold-plate pressure drops, monitor coolant distribution units, and ensure junction temperature < 85°C.',
    whenRequiredStage: 'GROWTH',
    prerequisiteDependency: 'Rack power density exceeding 45 kW/rack',
    sourcingOption: 'PARTNER_VENDOR',
    hiringTrigger: 'Partner directly with OEM cooling providers (CoolIT, Asetek) who supply pre-validated liquid cold-plate server sleds.',
    persistentJustification: 'OEMs assume warranty liability for fluid leaks and thermal dissipation performance.'
  },
  {
    id: 'CAP-14',
    discipline: 'Site Reliability Engineering (SRE) & Observability',
    domain: 'PRODUCT_OPERATIONS',
    whyRequired: 'Implement continuous Prometheus/Grafana metric scrapers, PagerDuty alerting, automated GPU node health checks, and automatic request failover.',
    whenRequiredStage: 'PILOT',
    prerequisiteDependency: 'Live commercial customers accessing production API',
    sourcingOption: 'FULL_TIME_EMPLOYEE',
    hiringTrigger: 'Hire first dedicated SRE when customer SLA commits require 99.9% uptime with 15-minute incident response times.',
    persistentJustification: 'Essential for maintaining enterprise enterprise trust and SLA compliance.'
  },
  {
    id: 'CAP-15',
    discipline: 'Systems Security & Cryptographic Compliance',
    domain: 'PRODUCT_OPERATIONS',
    whyRequired: 'Implement end-to-end TLS encryption, mTLS inter-service auth, customer API key rotation, SOC 2 Type II audit logging, and penetration testing.',
    whenRequiredStage: 'PILOT',
    prerequisiteDependency: 'Enterprise pilot security questionnaire submission',
    sourcingOption: 'CONTRACT_SPECIALIST',
    hiringTrigger: 'Engage specialized cybersecurity audit firm for SOC 2 Type II readiness; hire in-house security lead at Series A.',
    persistentJustification: 'Auditing requires accredited independent 3rd-party assessment.'
  },
  {
    id: 'CAP-16',
    discipline: 'Product & Developer Experience (DX) Engineering',
    domain: 'PRODUCT_OPERATIONS',
    whyRequired: 'Build OpenAI-compatible REST/WebSocket reverse proxy, client SDKs (Python/TypeScript), interactive documentation, and usage billing dashboards.',
    whenRequiredStage: 'MVP',
    prerequisiteDependency: 'Stable local inference runtime',
    sourcingOption: 'FULL_TIME_EMPLOYEE',
    hiringTrigger: 'Triggered when the core runtime is proven and developer onboarding requires polished APIs and self-service dashboards.',
    persistentJustification: 'Direct customer interface; drives developer adoption and reduces sales friction.'
  }
];
