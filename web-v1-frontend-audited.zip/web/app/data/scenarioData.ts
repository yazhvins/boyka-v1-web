export interface CompanyScenario {
  id: string;
  name: string;
  tagline: string;
  feasibilityRating: 'HIGH (RECOMMENDED PHASE 1)' | 'MODERATE (PHASE 2-3)' | 'HIGH_CAPITAL_RISK';
  capitalRequired: string;
  timelineToRevenue: string;
  grossMarginTarget: string;
  techRequirements: string[];
  productDelivery: string;
  targetCustomer: string;
  teamComposition: string[];
  operationalRigor: string;
  ipStrategy: string;
  securityFocus: string;
  keyPartners: string[];
  manufacturing: string;
  criticalRisks: string[];
  founderCTOPerspective: string;
}

export const COMPANY_SCENARIOS: CompanyScenario[] = [
  {
    id: 'sc-software-gateway',
    name: '1. Software-First Adaptive Gateway',
    tagline: 'Pure software algorithmic runtime optimizing LLM inference on commodity GPUs',
    feasibilityRating: 'HIGH (RECOMMENDED PHASE 1)',
    capitalRequired: '[SCENARIO ASSUMPTION — NOT MEASURED] $1.5M - $3.0M (Pre-Seed to Seed)',
    timelineToRevenue: '6 - 9 months',
    grossMarginTarget: '70% - 82%',
    techRequirements: [
      'Custom CUDA/Triton kernels for SPRT anytime early-exit',
      'OpenAI-compatible reverse proxy with zero-overhead routing',
      'Dynamic KV-cache paging and memory eviction allocator',
      'Integration with vLLM / SGLang continuous batching'
    ],
    productDelivery: 'Managed Cloud SaaS API endpoint (`https://gateway.boyka.ai/v1`) and self-hosted Helm chart for customer VPCs.',
    targetCustomer: '[SCENARIO ASSUMPTION — NOT MEASURED] Enterprise engineering teams spending $20k-$250k/month on reasoning tokens (o1, DeepSeek, Claude) seeking immediate cost reduction.',
    teamComposition: [
      'Founding CTO (Systems & Math)',
      'CEO (GTM, Enterprise Sales)',
      '1 Senior Inference Systems Engineer (CUDA/C++)',
      '1 Full-Stack / Platform Developer',
      '1 Applied ML Researcher (Calibrated Verification)'
    ],
    operationalRigor: 'Standard cloud DevOps on multi-cloud Kubernetes. Zero physical hardware inventory or warehouse management.',
    ipStrategy: 'Trade secrets in stopping boundary calibrations and scheduling heuristics; provisional software patents on dynamic inference stopping.',
    securityFocus: 'SOC 2 Type II, zero data retention logging, tenant isolation in shared memory.',
    keyPartners: ['Cloud GPU providers (Lambda, CoreWeave, AWS)', 'Open-weights model maintainers'],
    manufacturing: 'None. 100% cloud-native software.',
    criticalRisks: [
      'Hyperscalers (OpenAI, Anthropic) releasing native anytime stopping APIs that compress pricing',
      'Upstream vLLM community adopting similar algorithmic features'
    ],
    founderCTOPerspective: 'This is the unequivocally correct entry wedge for BOYKA. It delivers immediate customer value, generates revenue quickly, preserves equity, and generates real empirical data before making hardware bets.'
  },
  {
    id: 'sc-infra-cloud',
    name: '2. Managed AI Infrastructure Cloud',
    tagline: 'Dedicated cloud computing cluster offering guaranteed low-latency reasoning instances',
    feasibilityRating: 'MODERATE (PHASE 2-3)',
    capitalRequired: '[SCENARIO ASSUMPTION — NOT MEASURED] $15M - $40M (Series A / B)',
    timelineToRevenue: '14 - 18 months',
    grossMarginTarget: '45% - 58%',
    techRequirements: [
      'Dedicated bare-metal H100/B200 cluster management',
      'RoCEv2 / InfiniBand inter-node communication stack',
      'Multi-tenant GPU slicing and hardware virtualization',
      'Automated cluster failover and cold-start mitigations'
    ],
    productDelivery: 'Reserved and on-demand GPU instance capacity running BOYKA-optimized base images with SLA guarantees.',
    targetCustomer: 'High-growth AI startups and mid-market enterprises training and serving fine-tuned reasoning models.',
    teamComposition: [
      'VP Infrastructure / Datacenter Ops',
      'Distributed Systems Network Engineers (InfiniBand/RDMA)',
      'Enterprise Account Executives',
      '24/7 Site Reliability Engineering (SRE) rotation'
    ],
    operationalRigor: 'High: 99.99% availability SLAs, hardware RMA handling, colocation power density management.',
    ipStrategy: 'Proprietary cluster scheduling algorithms and network congestion control.',
    securityFocus: 'Physical data center access controls, FedRAMP High, strict network segmentation.',
    keyPartners: ['Tier-3/4 colocation facilities', 'Hardware leasing debt funds (TriplePoint, Silicon Valley Bank)'],
    manufacturing: 'Server rack assembly via third-party system integrators (Supermicro, Dell).',
    criticalRisks: [
      'Massive GPU depreciation risk as newer chip generations launch',
      'High fixed lease obligations during market demand downturns'
    ],
    founderCTOPerspective: 'Viable once BOYKA has proved demand and customers insist on dedicated bare-metal infrastructure. Requires debt financing rather than pure dilutive equity.'
  },
  {
    id: 'sc-hardware-pcie',
    name: '3. Hardware-Accelerated PCIe Appliance',
    tagline: 'Proprietary PCIe add-in co-processor card offloading verification and routing',
    feasibilityRating: 'MODERATE (PHASE 2-3)',
    capitalRequired: '[SCENARIO ASSUMPTION — NOT MEASURED] $25M - $60M (Series B)',
    timelineToRevenue: '24 - 30 months',
    grossMarginTarget: '55% - 65%',
    techRequirements: [
      'FPGA or custom chip logic implementing verification matrix engines',
      'PCIe Gen6 host interface driver and memory mapped I/O',
      'Thermal and power envelope optimization (<75W slot power)'
    ],
    productDelivery: 'Physical PCIe accelerator card shipped to enterprise data centers and OEM server partners.',
    targetCustomer: 'Financial institutions, defense contractors, and healthcare systems operating air-gapped private compute clusters.',
    teamComposition: [
      'VP Hardware Engineering',
      'ASIC/FPGA Design Engineers',
      'Board Layout and Signal Integrity Engineers',
      'Hardware QA and Firmware Developers'
    ],
    operationalRigor: 'Hardware supply chain, component sourcing, inventory holding, return merchandise authorization (RMA).',
    ipStrategy: 'Extensive patent portfolio on hardware acceleration architectures and bus interfaces.',
    securityFocus: 'Hardware root of trust, secure boot, tamper-evident board design.',
    keyPartners: ['FPGA vendors (AMD Xilinx, Intel Altera)', 'Board manufacturing EMS (Foxconn, Jabil)'],
    manufacturing: 'Contract electronics manufacturing and testing facilities.',
    criticalRisks: [
      'Silicon errata requiring costly board respins',
      'NVIDIA NVLink ecosystem locking out third-party PCIe co-processors'
    ],
    founderCTOPerspective: 'An interesting middle ground if software alone cannot overcome the PCIe latency barrier, but must be justified by signed customer pre-orders.'
  },
  {
    id: 'sc-vertically-integrated',
    name: '4. Vertically Integrated Semiconductor Foundry',
    tagline: 'Custom silicon ASIC, proprietary packaging, and liquid-cooled rack systems',
    feasibilityRating: 'HIGH_CAPITAL_RISK',
    capitalRequired: '[SCENARIO ASSUMPTION — NOT MEASURED] $100M - $500M+',
    timelineToRevenue: '36 - 48 months',
    grossMarginTarget: '65% - 75%',
    techRequirements: [
      'Bespoke 3nm/2nm ASIC design and tape-out',
      'CoWoS advanced 3D packaging with High Bandwidth Memory (HBM3e/HBM4)',
      'Custom instruction set architecture (ISA) and compiler toolchain',
      'Direct-to-chip liquid cooling manifolds and 100kW+ rack integration'
    ],
    productDelivery: 'Turnkey data center supercomputing pods or cloud superclusters.',
    targetCustomer: 'Hyperscalers and sovereign AI nation-state initiatives.',
    teamComposition: [
      '100+ semiconductor engineers, compiler architects, packaging specialists, thermal engineers, and procurement directors.'
    ],
    operationalRigor: 'Extreme: Foundry wafer allocations, yield engineering, geopolitical supply chain risk management.',
    ipStrategy: 'Fundamental semiconductor patents, trade secrets in packaging.',
    securityFocus: 'National security grade, ITAR compliance, supply chain hardware integrity.',
    keyPartners: ['Semiconductor foundries (TSMC, Samsung)', 'EDA tool vendors (Synopsys, Cadence)', 'Memory suppliers (SK Hynix, Micron)'],
    manufacturing: 'Full TSMC fabrication, advanced packaging OSATs.',
    criticalRisks: [
      '[SCENARIO ASSUMPTION — NOT MEASURED] Mask set write-off ($25M per spin) on design flaw',
      'TSMC capacity allocation prioritization favoring NVIDIA/Apple/AMD',
      'Multi-year delay resulting in obsolescence before first silicon arrives'
    ],
    founderCTOPerspective: '[SCENARIO ASSUMPTION — NOT MEASURED] This was the grand vision in some parts of the initial BOYKA notes. As Founding CTO, my fiduciary and technical duty is to state clearly: pursuing this on Day 1 is fatal. It should only be evaluated if BOYKA achieves $50M+ ARR and dominates the algorithmic layer.'
  }
];
