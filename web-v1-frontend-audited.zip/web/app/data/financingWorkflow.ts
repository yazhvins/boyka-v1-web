import { FinancingWorkflowStage } from '../types';

export const FINANCING_WORKFLOW: FinancingWorkflowStage[] = [
  {
    stageNumber: 1,
    name: 'Thesis & Problem Formulation',
    objective: 'Articulate the exact computational problem, why existing COTS and static LLM inference fails, and the physical/economic mechanism of BOYKA.',
    primaryActor: 'Founding Team (CEO + CTO)',
    requiredArtifacts: ['Executive Synthesis', 'Problem Discovery Ledger', 'Theoretical Mechanism Dossier'],
    diligenceCriteria: ['Is the problem real and verified by first principles?', 'Is the market bottleneck structural or temporary?'],
    fatalRedFlags: ['Hand-waving claims of "novel AI physics" without peer-reviewed mathematical grounding.', 'Conflating compute efficiency with energy generation.'],
    exitGate: 'Formal technical sign-off on Research Batch 001 hypotheses and experimental protocol.'
  },
  {
    stageNumber: 2,
    name: 'Investor Profile & Alignment Filter',
    objective: 'Identify institutional investors with deep-tech systems competence who understand inference economics, runtime schedulers, and semiconductor cycles.',
    primaryActor: 'CEO',
    requiredArtifacts: ['Target Investor Criteria Matrix', 'Anti-Portfolio Filter (exclude pure software-only / app-layer funds)'],
    diligenceCriteria: ['Does the fund have partners with hardware/systems engineering backgrounds?', 'Do they support software-first silicon gating?'],
    fatalRedFlags: ['Investors demanding immediate custom chip tape-outs as a marketing gimmick.', 'Investors expecting B2C SaaS growth metrics.'],
    exitGate: 'Approved target list of 25 qualified deep-tech / AI infrastructure institutional investors.'
  },
  {
    stageNumber: 3,
    name: 'Outreach & Introduction',
    objective: 'Initiate contact through warm technical introductions, peer-reviewed research preprints, or technical demonstrations.',
    primaryActor: 'CEO (with CTO technical collateral)',
    requiredArtifacts: ['Executive One-Pager', 'Technical Teaser with reproducible benchmark snippet'],
    diligenceCriteria: ['Introduction must come from trusted technical operator or recognized AI researcher.'],
    fatalRedFlags: ['Cold spamming generic VC submission inboxes.', 'Overpromising speedups before peer review.'],
    exitGate: 'Confirmed partner-level introductory meetings scheduled.'
  },
  {
    stageNumber: 4,
    name: 'Initial Partner Meeting',
    objective: 'Present the executive thesis: why uniform inference is broken, how metareasoning early exit solves it, and why COTS GPUs are the fastest path to market.',
    primaryActor: 'CEO & CTO',
    requiredArtifacts: ['Executive Pitch Deck (12 slides max)', 'Whole-Company Operating Model Diagram'],
    diligenceCriteria: ['Can the team explain the difference between compute efficiency and hardware manufacturing without evasiveness?'],
    fatalRedFlags: ['CTO unable to explain roofline memory wall constraints.', 'CEO making wild TAM projections without customer validation.'],
    exitGate: 'Invitation to formal Technical Diligence session.'
  },
  {
    stageNumber: 5,
    name: 'Deep Technical Diligence',
    objective: 'Subject the algorithmic theories, runtime code, Triton kernels, and benchmark telemetry to adversarial scrutiny by investor technical partners.',
    primaryActor: 'CTO',
    requiredArtifacts: ['DEC-RP01-001 Architecture Decision Record', 'EXP-RP01-001 Benchmark Protocol', 'Raw Telemetry Logs & Jupyter Notebooks'],
    diligenceCriteria: ['Can the benchmark advantage be reproduced independently on an isolated H100 node?', 'Is the mathematical stopping rule (Wald SPRT) mathematically sound?'],
    fatalRedFlags: ['Benchmark advantages that vanish when compared against speculative decoding.', 'Uncalibrated verifier logits leading to hallucinations.'],
    exitGate: 'Technical Partner greenlight and issuance of Technical Diligence Memo.'
  },
  {
    stageNumber: 6,
    name: 'Customer & Commercial Diligence',
    objective: 'Investor calls target enterprise design partners to verify willingness to pay and validate integration pain points.',
    primaryActor: 'CEO',
    requiredArtifacts: ['3 Documented Enterprise Problem Interviews', 'Commercial ROI Calculator', 'Pilot Deployment SLA Specification'],
    diligenceCriteria: ['Do customers validate that reasoning latency and GPU token cost are primary blockers to scaling agentic AI?'],
    fatalRedFlags: ['Enterprise prospects stating that simple API prompt caching solves their problem.', 'Zero interest in OpenAI-compatible gateway drops.'],
    exitGate: 'Customer reference checks confirm strong commercial demand.'
  },
  {
    stageNumber: 7,
    name: 'Financial & Resource Diligence',
    objective: 'Audit bottom-up capital requirements: compute budgets, engineering team sizing, cloud GPU reservations, and operational runway.',
    primaryActor: 'CEO & CTO',
    requiredArtifacts: ['Bottom-Up 24-Month Milestone Budget', 'GPU Cloud Cost Model', 'Hiring & Sourcing Plan (Gated by Milestones)'],
    diligenceCriteria: ['Is every dollar tied to an explicit technical deliverable?', 'Are capital-intensive hardware bets strictly gated?'],
    fatalRedFlags: ['[SCENARIO ASSUMPTION — NOT MEASURED] Invented headcount growth curves.', 'Premature allocation of $10M+ for silicon tape-out before software validation.'],
    exitGate: 'Financial model audited and approved by fund investment committee.'
  },
  {
    stageNumber: 8,
    name: 'Legal, Corporate & IP Diligence',
    objective: 'Audit corporate entity incorporation, IP assignment agreements, open-source license compliance (Apache 2.0 / MIT), and prior art freedom-to-operate.',
    primaryActor: 'Corporate Legal Counsel & CEO',
    requiredArtifacts: ['Delaware C-Corp Incorporation Documents', 'Confidential Information & Invention Assignment Agreements (CIIAA)', 'Open-Source Dependency Audit Report'],
    diligenceCriteria: ['Clean IP assignment from all founders and contributors.', 'Zero copyleft (GPL) code contamination in proprietary runtime.'],
    fatalRedFlags: ['Contested IP ownership with prior academic institutions or former employers.', 'Undisclosed debt or litigation.'],
    exitGate: 'Legal Diligence clearance letter issued by investor counsel.'
  },
  {
    stageNumber: 9,
    name: 'Term Sheet Issuance & Negotiation',
    objective: 'Agree on primary investment terms: investment amount, milestone governance, board composition, and technical gating conditions.',
    primaryActor: 'CEO & Lead Investor',
    requiredArtifacts: ['Binding or Non-Binding Term Sheet', 'Voting Rights & Protective Provisions Agreement'],
    diligenceCriteria: ['Alignment on milestone-based tranched capital or clean priced seed structure.', 'Board seat for deep-tech operating partner.'],
    fatalRedFlags: ['[SCENARIO ASSUMPTION — NOT MEASURED] Onerous liquidation preferences (> 1x non-participating).', 'Investor demands for forced hardware tape-out timelines.'],
    exitGate: 'Mutually signed Term Sheet.'
  },
  {
    stageNumber: 10,
    name: 'Definitive Legal Documentation',
    objective: 'Draft and execute final financing agreements (Stock Purchase Agreement, Investor Rights Agreement, Right of First Refusal, Voting Agreement).',
    primaryActor: 'Legal Counsel & Founders',
    requiredArtifacts: ['Final Series Seed Purchase Agreement', 'Amended Certificate of Incorporation'],
    diligenceCriteria: ['Accurate disclosure schedules and representation warranties.'],
    fatalRedFlags: ['Last-minute changes to corporate governance or veto rights.'],
    exitGate: 'All definitive legal agreements executed by all parties.'
  },
  {
    stageNumber: 11,
    name: 'Closing & Capital Transfer',
    objective: 'Wire funds into dedicated company operating account and issue shares per closing memorandum.',
    primaryActor: 'CEO & Bank Escrow',
    requiredArtifacts: ['Bank Wire Confirmation', 'Closing Memorandum', 'Board Approval Resolutions'],
    diligenceCriteria: ['Full committed capital verified in company operating bank account.'],
    fatalRedFlags: ['Wire delivery delays or escrow disputes.'],
    exitGate: 'Funds cleared; official formal closing announced.'
  },
  {
    stageNumber: 12,
    name: 'Post-Funding Milestone Governance',
    objective: 'Execute against the exact technical and customer milestones funded by the round, reporting monthly burn and benchmark progress.',
    primaryActor: 'CEO & CTO',
    requiredArtifacts: ['Monthly Investor Telemetry Report', 'Milestone Gating Dashboard', 'Updated Cash Burn & Runway Trackers'],
    diligenceCriteria: ['Monthly reporting of: Cash burn, GPU utilization, Benchmark token savings, Enterprise pilot uptime.'],
    fatalRedFlags: ['Burn rate acceleration without achieving corresponding technical gates.', 'Silent failure of benchmark reproduction.'],
    exitGate: 'Achievement of Phase 2 Production Prototype unlocks Series A financing.'
  }
];

export interface MilestoneCapitalRequirement {
  phase: string;
  milestone: string;
  durationMonths: number;
  computeCost: string;
  engineeringCost: string;
  infrastructureCost: string;
  operationsLegalCost: string;
  contingencyCost: string;
  totalCapitalRequired: string;
  runwayMonths: number;
  gatingDeliverable: string;
}

export const MILESTONE_CAPITAL_BUDGET: MilestoneCapitalRequirement[] = [
  {
    phase: 'Phase 1: Formation & Empirical Proof',
    milestone: '[SCENARIO ASSUMPTION — NOT MEASURED] Reproduce candidate compute advantage under controlled workloads on 8x H100 node (EXP-RP01-001).',
    durationMonths: 6,
    computeCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $15,000 (Cloud GPU rental: 6,000 GPU-hours @ $2.50/hr)',
    engineeringCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $90,000 (Founding core stipend + specialized CUDA/Triton contract sprints)',
    infrastructureCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $6,000 (Cloud storage, GitHub Enterprise, CI/CD runners)',
    operationsLegalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $14,000 (Delaware incorporation, IP assignments, prior art legal search)',
    contingencyCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $15,000 (Buffer for unexpected benchmark reruns)',
    totalCapitalRequired: '[SCENARIO ASSUMPTION — NOT MEASURED] $140,000',
    runwayMonths: 6,
    gatingDeliverable: 'DEC-RP01-001: Verified >= 30% token reduction on GSM8K without accuracy loss.'
  },
  {
    phase: 'Phase 2: Production-Capable Prototype',
    milestone: 'Deliver OpenAI-compatible gateway with continuous batching scheduler and 3 enterprise pilot integrations.',
    durationMonths: 12,
    computeCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $95,000 (Dedicated 16x H100 cloud cluster for continuous multi-user serving)',
    engineeringCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $480,000 (Core systems team: 3 FTE systems/ML engineers + DX lead)',
    infrastructureCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $25,000 (Colocation networking, Prometheus observability, domain infra)',
    operationsLegalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $45,000 (SOC 2 Type I readiness audit, enterprise customer contracts)',
    contingencyCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $55,000 (Buffer for cluster scaling and customer failover redundancy)',
    totalCapitalRequired: '[SCENARIO ASSUMPTION — NOT MEASURED] $700,000',
    runwayMonths: 12,
    gatingDeliverable: 'Three enterprise pilots processing > 100k queries/day at 99.9% availability.'
  },
  {
    phase: 'Phase 3: Commercial Scaling & Bare-Metal Cluster',
    milestone: '[SCENARIO ASSUMPTION — NOT MEASURED] Deploy dedicated 64-GPU bare-metal HGX cluster in Tier 3 datacenter; reach $1.5M ARR.',
    durationMonths: 18,
    computeCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $450,000 (Bare-metal server lease financing & colocation power/cooling)',
    engineeringCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $1,350,000 (Expanded engineering team: 7 FTEs across runtime, distributed, SRE, DX)',
    infrastructureCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $120,000 (400Gbps InfiniBand leaf-spine network, enterprise VPC endpoints)',
    operationsLegalCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $110,000 (SOC 2 Type II audit completion, enterprise sales legal review)',
    contingencyCost: '[SCENARIO ASSUMPTION — NOT MEASURED] $170,000 (Operating cash reserve for SLA guarantee escrow)',
    totalCapitalRequired: '[SCENARIO ASSUMPTION — NOT MEASURED] $2,200,000',
    runwayMonths: 18,
    gatingDeliverable: '[SCENARIO ASSUMPTION — NOT MEASURED] Profitable per-query unit economics ($0.0008/query) with 10+ paying enterprise customers.'
  }
];
