import { IntakeManifest, ThesisStatement, ReviewRequirement, AbsenceObservation, LipunQuestion, RP01Protocol, SchemaInfo, GateInfo, QueryFamily } from '../types';

export const CANONICAL_MANIFEST: IntakeManifest = {
  archive_path: "External source archive supplied by Lipun; canonical bytes preserved under docs/source/supplied/",
  archive_sha256: "ac91caafea59e880bc811ca5539f83e7bffe7254ae6c5e4912a0fc3d9009b9ba",
  archive_bytes: 186849,
  total_pages: 49,
  source_audit_status: "SOURCE_AUDIT_ACCEPTED",
  approval_record: "00-governance/decisions/DEC-SOURCE-AUDIT-001.json",
  documents: [
    {
      source_id: "BOYKA-SRC-001",
      archive_member: "docs/source/supplied/02_Part1_Current_Heterogeneous_Computing_Architecture.pdf",
      sha256: "db83cfbc911812891d4e41b3a3d533666bba78ce5bc5d8b7468132958f40a1b6",
      bytes: 204365,
      pages: 4,
      text_extraction_pages: 4,
      classification: "BOYKA_SUPPLIED",
      confidentiality: "CONFIDENTIAL_INTERNAL_REVIEW",
      publication_status: "UNPUBLISHED_INTERNAL_PROPOSAL",
      extraction_status: "COMPLETE",
      visual_inspection_status: "NOT_INSPECTED",
      visually_inspected_pages: []
    },
    {
      source_id: "BOYKA-SRC-002",
      archive_member: "docs/source/supplied/03_Part2_Future_Native_Computing_Environment.pdf",
      sha256: "721bc8201a4e1ca87d19565578772a8cbfb49e5d4cb5f5ba68c56fa76ca32cb4",
      bytes: 184511,
      pages: 4,
      text_extraction_pages: 4,
      classification: "BOYKA_SUPPLIED",
      confidentiality: "CONFIDENTIAL_INTERNAL_REVIEW",
      publication_status: "UNPUBLISHED_INTERNAL_PROPOSAL",
      extraction_status: "COMPLETE",
      visual_inspection_status: "NOT_INSPECTED",
      visually_inspected_pages: []
    },
    {
      source_id: "BOYKA-SRC-003",
      archive_member: "docs/source/supplied/04_Part3_Tools_Languages_Engineers.pdf",
      sha256: "755ca7ef8d5231c5ee0038933b934759ea79f40fe3ff256fa0d17208d19d6756",
      bytes: 187682,
      pages: 6,
      text_extraction_pages: 6,
      classification: "BOYKA_SUPPLIED",
      confidentiality: "CONFIDENTIAL_INTERNAL_REVIEW",
      publication_status: "UNPUBLISHED_INTERNAL_PROPOSAL",
      extraction_status: "COMPLETE",
      visual_inspection_status: "NOT_INSPECTED",
      visually_inspected_pages: []
    },
    {
      source_id: "BOYKA-SRC-004",
      archive_member: "docs/source/supplied/01_BOYKA_Intelligence_and_Compute_Research_Blueprint_V1.pdf",
      sha256: "8e3b78996bdfdb8a011ea35f3dfd974df7be0ea13b190f77d341cc05fe86fb26",
      bytes: 651608,
      pages: 12,
      text_extraction_pages: 12,
      classification: "BOYKA_SUPPLIED",
      confidentiality: "CONFIDENTIAL_INTERNAL_REVIEW",
      publication_status: "UNPUBLISHED_INTERNAL_PROPOSAL",
      extraction_status: "COMPLETE",
      visual_inspection_status: "NOT_INSPECTED",
      visually_inspected_pages: []
    },
    {
      source_id: "BOYKA-SRC-005",
      archive_member: "docs/source/supplied/05_BOYKA_V1_Technical_Stack_and_CTO_Profile.pdf",
      sha256: "5d5dd1ca537ec7e8be2b65fe2c89f5bc91fe30fc1d044f5092040b2cb5325875",
      bytes: 3514936,
      pages: 20,
      text_extraction_pages: 20,
      classification: "BOYKA_SUPPLIED",
      confidentiality: "CONFIDENTIAL_INTERNAL_REVIEW",
      publication_status: "UNPUBLISHED_INTERNAL_PROPOSAL",
      extraction_status: "COMPLETE",
      visual_inspection_status: "PAGE_15_INSPECTED",
      visually_inspected_pages: [15]
    },
    {
      source_id: "BOYKA-SRC-006",
      archive_member: "docs/source/supplied/06_BOYKA_6_Current_AI_World_Dealing.pdf",
      sha256: "52792ae5e8f498c480a454d6fa713919e99a8449c40ea4670c567bb0f5e3d231",
      bytes: 187834,
      pages: 3,
      text_extraction_pages: 3,
      classification: "BOYKA_SUPPLIED",
      confidentiality: "CONFIDENTIAL_INTERNAL_REVIEW",
      publication_status: "UNPUBLISHED_INTERNAL_PROPOSAL",
      extraction_status: "COMPLETE",
      visual_inspection_status: "NOT_INSPECTED",
      visually_inspected_pages: []
    }
  ]
};

export const THESIS_STATEMENTS: ThesisStatement[] = [
  {
    statement_id: "STMT-0001",
    source_id: "BOYKA-SRC-001",
    pages: [1],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "Dynamic model routing across task categories and complexity levels.",
    exact_or_near_quote: "Route queries dynamically across diverse models and modalities according to task difficulty and resource limits.",
    rp01_query_families: ["Q01", "Q02", "Q04"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0002",
    source_id: "BOYKA-SRC-001",
    pages: [1, 4],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "Software-first heterogenous compute optimization before custom silicon.",
    exact_or_near_quote: "Prove economics on available heterogeneous hardware before committing to proprietary ASIC design.",
    rp01_query_families: ["Q09", "Q10"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0003",
    source_id: "BOYKA-SRC-001",
    pages: [2],
    statement_kind: "REQUIREMENT",
    summary: "Multi-objective resource allocation accounting for latency, cost, and energy.",
    exact_or_near_quote: "Joint optimization of quality, latency, token spend, and energy consumption under strict SLAs.",
    rp01_query_families: ["Q01", "Q08", "Q12"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0004",
    source_id: "BOYKA-SRC-001",
    pages: [3],
    statement_kind: "ROADMAP_PROJECTION",
    summary: "Initial software runtime milestone followed by hardware acceleration.",
    exact_or_near_quote: "Deploy intelligent scheduler runtime in software phase, validating workload profiles prior to RTL synthesis.",
    rp01_query_families: ["Q08", "Q09", "Q10"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0005",
    source_id: "BOYKA-SRC-002",
    pages: [1],
    statement_kind: "EXTERNAL_LANDSCAPE_ASSERTION",
    summary: "Characterization of hyperscaler cluster inefficiencies and memory wall bottlenecks.",
    exact_or_near_quote: "Hyperscaler architectures suffer from memory bottlenecks and under-utilized compute in dense inference serving.",
    rp01_query_families: ["Q07", "Q08", "Q14"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false,
    external_reference_status: "SOURCE_REFERENCED_UNVERIFIED"
  },
  {
    statement_id: "STMT-0006",
    source_id: "BOYKA-SRC-002",
    pages: [2],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "Hierarchical memory tiering across HBM, DDR5, and persistent memory.",
    exact_or_near_quote: "Dynamic KV-cache migration across heterogeneous memory hierarchies to reduce eviction penalties.",
    rp01_query_families: ["Q07", "Q08"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0007",
    source_id: "BOYKA-SRC-002",
    pages: [3],
    statement_kind: "REQUIREMENT",
    summary: "Thermal and power tracking with normalized energy accounting.",
    exact_or_near_quote: "Energy measurement requires hardware instrumentation or calibrated telemetry, not nominal TDP assumptions.",
    rp01_query_families: ["Q12"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0008",
    source_id: "BOYKA-SRC-002",
    pages: [4],
    statement_kind: "EXPLICIT_LIMITATION",
    summary: "Cooling and thermal infrastructure is dependent on measured workload density.",
    exact_or_near_quote: "Rack-level immersion or direct-to-chip liquid cooling decisions depend entirely on thermal dissipation density.",
    rp01_query_families: ["Q11", "Q12"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0009",
    source_id: "BOYKA-SRC-003",
    pages: [1, 2],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "First-principles redesign of inference execution stack.",
    exact_or_near_quote: "Rebuild the AI execution runtime around adaptive compute graphs and speculative verification.",
    rp01_query_families: ["Q01", "Q03", "Q08"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0010",
    source_id: "BOYKA-SRC-003",
    pages: [3],
    statement_kind: "OWNERSHIP_ASSERTION",
    summary: "Proprietary algorithmic framework for adaptive execution.",
    exact_or_near_quote: "Boyka proprietary scheduling algorithms govern real-time compute allocation and speculative execution.",
    rp01_query_families: ["Q08", "Q15"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0011",
    source_id: "BOYKA-SRC-003",
    pages: [4],
    statement_kind: "REQUIREMENT",
    summary: "Verification overhead must remain strictly bounded relative to task execution.",
    exact_or_near_quote: "Verifier overhead must not exceed marginal gain in outcome reliability or error reduction.",
    rp01_query_families: ["Q03", "Q04"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0012",
    source_id: "BOYKA-SRC-003",
    pages: [5, 6],
    statement_kind: "ROADMAP_PROJECTION",
    summary: "Proposed 90-day execution roadmap for software validation.",
    exact_or_near_quote: "Phase 1 targets software prototype demonstration within 90 days across synthetic and benchmark tasks.",
    rp01_query_families: ["Q08", "Q13"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0013",
    source_id: "BOYKA-SRC-004",
    pages: [1, 3],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "Executive vision of compute-efficient enterprise intelligence.",
    exact_or_near_quote: "Deliver high-reliability reasoning workloads at a fraction of hyperscaler cost through dynamic resource allocation.",
    rp01_query_families: ["Q01", "Q02", "Q08"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0014",
    source_id: "BOYKA-SRC-004",
    pages: [4, 6],
    statement_kind: "EXTERNAL_LANDSCAPE_ASSERTION",
    summary: "Competitor comparison asserting current static LLM deployment inefficiencies.",
    exact_or_near_quote: "Existing LLM APIs charge uniform token prices regardless of answer certainty, wasting compute on trivial queries.",
    rp01_query_families: ["Q01", "Q04", "Q14"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false,
    external_reference_status: "SOURCE_REFERENCED_UNVERIFIED"
  },
  {
    statement_id: "STMT-0015",
    source_id: "BOYKA-SRC-004",
    pages: [7, 8],
    statement_kind: "ROADMAP_PROJECTION",
    summary: "Target commercial deployment phases across enterprise sectors.",
    exact_or_near_quote: "Initial pilot deployments target financial analysis and legal research where verification is paramount.",
    rp01_query_families: ["Q03", "Q06"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0016",
    source_id: "BOYKA-SRC-004",
    pages: [10, 12],
    statement_kind: "REQUIREMENT",
    summary: "Strict security, provenance, and auditability requirements for enterprise adoption.",
    exact_or_near_quote: "Enterprise customers require deterministic trace logs, provenance tracking, and air-gapped deployment capability.",
    rp01_query_families: ["Q03", "Q08"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0017",
    source_id: "BOYKA-SRC-005",
    pages: [2, 5],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "System architecture for intelligent agent execution with integrated verification.",
    exact_or_near_quote: "Intelligent agent orchestration integrating dynamic retrieval, code sandbox execution, and verifier feedback loops.",
    rp01_query_families: ["Q03", "Q05", "Q06"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0018",
    source_id: "BOYKA-SRC-005",
    pages: [7, 8],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "Software-first heterogeneous compute routing across GPUs, CPUs, and TPUs.",
    exact_or_near_quote: "Schedule speculative sub-tasks onto lower-cost CPU/GPU nodes while reserving heavy reasoning for flagship clusters.",
    rp01_query_families: ["Q08", "Q09"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0019",
    source_id: "BOYKA-SRC-005",
    pages: [12],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "Economics validation prior to hardware fabrication commitments.",
    exact_or_near_quote: "Demonstrate sustainable margin advantage in software-only cloud infrastructure prior to tape-out expenditures.",
    rp01_query_families: ["Q09", "Q10"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0020",
    source_id: "BOYKA-SRC-005",
    pages: [14],
    statement_kind: "EXPLICIT_LIMITATION",
    summary: "Open questions on baseline competitiveness and kill conditions.",
    exact_or_near_quote: "If a tuned model cascade or static routing table matches adaptive allocation at lower overhead, the system hypothesis must terminate.",
    rp01_query_families: ["Q01", "Q02", "Q14"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0021",
    source_id: "BOYKA-SRC-005",
    pages: [15],
    statement_kind: "ILLUSTRATIVE_EXAMPLE",
    summary: "Illustrative numerical comparisons of compute cost and latency.",
    exact_or_near_quote: "Hypothetical comparison matrix showing potential 5x-10x cost improvements under idealized routing assumptions.",
    rp01_query_families: ["Q01", "Q02", "Q13"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false,
    numeric_evidence_status: "ILLUSTRATIVE_ONLY"
  },
  {
    statement_id: "STMT-0022",
    source_id: "BOYKA-SRC-005",
    pages: [17],
    statement_kind: "EXPLICIT_LIMITATION",
    summary: "Novelty limitation acknowledging prior art in adaptive computation and routing.",
    exact_or_near_quote: "Adaptive compute and cascading are explored in literature; novelty requires proving end-to-end multi-objective convergence.",
    rp01_query_families: ["Q01", "Q14", "Q15"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0023",
    source_id: "BOYKA-SRC-006",
    pages: [1],
    statement_kind: "PROPOSED_CAPABILITY",
    summary: "Product packaging of adaptive compute runtime for developers and enterprises.",
    exact_or_near_quote: "Provide a drop-in API endpoint that automatically routes requests and manages verification without code changes.",
    rp01_query_families: ["Q02", "Q08"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0024",
    source_id: "BOYKA-SRC-006",
    pages: [2],
    statement_kind: "REQUIREMENT",
    summary: "SLA compliance, telemetry guarantees, and cost transparency dashboard.",
    exact_or_near_quote: "Customer dashboard must provide transparent token-level and joule-level accounting per transaction.",
    rp01_query_families: ["Q08", "Q12"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  },
  {
    statement_id: "STMT-0025",
    source_id: "BOYKA-SRC-006",
    pages: [3],
    statement_kind: "ROADMAP_PROJECTION",
    summary: "Customer onboarding phases from self-service API to dedicated cluster management.",
    exact_or_near_quote: "Roll out initial self-serve developer tier followed by dedicated enterprise VPC deployments.",
    rp01_query_families: ["Q08"],
    review_status: "PENDING_HUMAN_REVIEW",
    validation_status: "NOT_INDEPENDENTLY_VALIDATED",
    external_claim_authorized: false
  }
];

export const ABSENCE_OBSERVATIONS: AbsenceObservation[] = [
  { item: "code", statement: "No code was located in the reviewed six-PDF archive." },
  { item: "datasets", statement: "No datasets was located in the reviewed six-PDF archive." },
  { item: "raw execution receipts", statement: "No raw execution receipts was located in the reviewed six-PDF archive." },
  { item: "independently reproducible BOYKA benchmarks", statement: "No independently reproducible BOYKA benchmarks was located in the reviewed six-PDF archive." },
  { item: "named customer study", statement: "No named customer study was located in the reviewed six-PDF archive." },
  { item: "paid pilot", statement: "No paid pilot was located in the reviewed six-PDF archive." },
  { item: "contract", statement: "No contract was located in the reviewed six-PDF archive." },
  { item: "revenue evidence", statement: "No revenue evidence was located in the reviewed six-PDF archive." },
  { item: "standalone energy-generation mechanism", statement: "No standalone energy-generation mechanism was located in the reviewed six-PDF archive." },
  { item: "standalone cooling invention evidence", statement: "No standalone cooling invention evidence was located in the reviewed six-PDF archive." },
  { item: "detailed rack-design evidence", statement: "No detailed rack-design evidence was located in the reviewed six-PDF archive." }
];

export const LIPUN_QUESTIONS: LipunQuestion[] = [
  { question_id: "Q-LIPUN-01", text: "Which thesis/version and first claim should the evaluation prioritize?", why_needed: "Focuses bounded research on canonical starting point." },
  { question_id: "Q-LIPUN-02", text: "What code, datasets, execution receipts and benchmark results exist beyond this archive?", why_needed: "Clarifies whether empirical runs have occurred elsewhere." },
  { question_id: "Q-LIPUN-03", text: "Which actual workload, customer problem and success criterion anchor V1?", why_needed: "Prevents abstract benchmarking disconnected from customer requirements." },
  { question_id: "Q-LIPUN-04", text: "What expert-authored material exists, and what use/ownership rights cover it?", why_needed: "Establishes IP hygiene and copyright boundaries." },
  { question_id: "Q-LIPUN-05", text: "What resources, team and spending limits are available for the first bounded evaluation?", why_needed: "Defines experimental budget constraints." },
  { question_id: "Q-LIPUN-06", text: "Are energy-generation, cooling and rack claims separate programs with additional evidence?", why_needed: "Resolves scope boundaries with public statements." },
  { question_id: "Q-LIPUN-07", text: "Can the evaluation recommend existing software, a narrower direction or stopping the hypothesis?", why_needed: "Ensures scientific honesty and fast falsification." }
];

export const QUERY_FAMILIES: QueryFamily[] = [
  { id: "Q01", name: "TEST-TIME COMPUTATION", queries: ["test-time compute", "inference-time compute", "adaptive inference", "dynamic computation", "test-time scaling", "compute-optimal inference", "early exit"], relevance_to_boyka: "Core mechanism of dynamically scaling compute during inference." },
  { id: "Q02", name: "MODEL SELECTION / ROUTING", queries: ["LLM routing", "model routing", "model selection", "model cascade", "adaptive model selection", "cost-aware routing", "mixture of models"], relevance_to_boyka: "Deciding which model or size to invoke per query." },
  { id: "Q03", name: "VERIFICATION", queries: ["adaptive verification", "verifier-guided reasoning", "process verification", "outcome verification", "self-verification", "process supervision", "reward models"], relevance_to_boyka: "Validating generated results before accepting or returning." },
  { id: "Q04", name: "UNCERTAINTY / STOPPING", queries: ["uncertainty-aware inference", "adaptive stopping", "optimal stopping", "confidence-based stopping", "selective prediction", "abstention", "value of computation"], relevance_to_boyka: "Deciding when sufficient evidence exists to terminate search/compute." },
  { id: "Q05", name: "RETRIEVAL", queries: ["adaptive retrieval", "retrieval routing", "dynamic retrieval", "retrieval-augmented reasoning", "when to retrieve", "active retrieval"], relevance_to_boyka: "Conditioning retrieval actions on epistemic uncertainty." },
  { id: "Q06", name: "TOOLS / AGENTS", queries: ["adaptive tool use", "tool routing", "agent planning", "tool selection", "cost-aware agents", "agent verification"], relevance_to_boyka: "Selective invocation of external execution environments." },
  { id: "Q07", name: "MEMORY", queries: ["KV-cache compression", "dynamic memory management", "hierarchical memory LLM", "memory-aware scheduling", "context paging"], relevance_to_boyka: "Memory bandwidth and capacity constraints during serving." },
  { id: "Q08", name: "SCHEDULING / SERVING", queries: ["LLM serving systems", "continuous batching", "speculative decoding", "multi-objective scheduling", "inference engine optimization"], relevance_to_boyka: "Execution scheduling and throughput optimization across clusters." },
  { id: "Q09", name: "HETEROGENEOUS / ACCELERATOR", queries: ["heterogeneous compute AI", "GPU-CPU co-execution", "accelerator partitioning", "workload placement"], relevance_to_boyka: "Workload distribution across available non-uniform compute units." },
  { id: "Q10", name: "HARDWARE / SILICON", queries: ["domain-specific architecture AI", "inference accelerator ASIC", "energy-efficient AI accelerator", "compute-in-memory"], relevance_to_boyka: "Custom silicon claims; strictly gated on baseline bottlenecks." },
  { id: "Q11", name: "RACK / SYSTEM INFRASTRUCTURE", queries: ["disaggregated datacenter", "optical interconnect", "rack-scale inference", "high-density compute rack"], relevance_to_boyka: "Physical infrastructure claims; strictly gated on workload derivation." },
  { id: "Q12", name: "THERMAL / POWER / ENERGY", queries: ["datacenter thermal management", "liquid cooling AI", "power capping inference", "energy measurement in servers"], relevance_to_boyka: "Energy accounting and thermal limits; gated on measured dissipation." },
  { id: "Q13", name: "BENCHMARKS / EVALUATION", queries: ["evaluating adaptive compute", "pareto frontier inference", "energy-delay-product AI", "reproducible AI benchmarking"], relevance_to_boyka: "Disciplined measurement methodology avoiding illustrative numbers." },
  { id: "Q14", name: "NEGATIVE RESULTS / LIMITATIONS", queries: ["overhead of adaptive computation", "when routing fails", "verifier gaming", "cascade latency penalty"], relevance_to_boyka: "Adversarial literature search for falsifying conditions and failure modes." },
  { id: "Q15", name: "METAREASONING / VALUE OF COMPUTATION", queries: ["metareasoning", "value of computation", "rational metareasoning", "bounded optimality", "anytime algorithms", "flexible computation"], relevance_to_boyka: "Foundational classical computer science theory underpinning adaptive compute.", classical_roots: "Horvitz (1987), Russell & Wefald (1991), Zilberstein (1996), Dean & Boddy (1988)." }
];

export const SCHEMAS_CATALOG: SchemaInfo[] = [
  {
    name: "claim.schema.json",
    title: "Claim Record",
    required: ["claim_id", "statement", "claim_type", "origin", "owner", "date_created", "status", "evidence_level", "source_ids", "limitations", "allowed_external_wording", "prohibited_external_wording"],
    description: "Enforces evidence gates (E0-E6), prohibited words, and boundary checks for all public and internal claims."
  },
  {
    name: "action.schema.json",
    title: "Action / Responsibility Record",
    required: ["action_id", "objective_id", "decision_id", "owner", "accountable", "responsible", "consulted", "informed", "status", "completion_evidence"],
    description: "Tracks individual execution commitments with explicit RACI assignments, deadlines, and evidence proofs."
  },
  {
    name: "company-objective.schema.json",
    title: "Company Objective Record",
    required: ["objective_id", "strategic_reason", "owner", "metric", "baseline", "target", "evidence", "initiatives", "dependencies", "status"],
    description: "Ties high-level strategy to measurable baselines, risks, capital allocation, and follow-up decisions."
  },
  {
    name: "compute-receipt.schema.json",
    title: "Compute Receipt Record",
    required: ["receipt_id", "task_id", "timestamp", "models", "energy_measurement_method", "evidence_status"],
    description: "Exhaustive telemetry contract capturing tokens, calls, time, memory, energy in Joules, and measurement method."
  },
  {
    name: "failure-classification.schema.json",
    title: "Failure Classification Record",
    required: ["failure_id", "failure_class", "classification_rationale", "human_reviewed"],
    description: "Categorizes failures into scientific negative results, rejected hypotheses, engineering defects, or operational failures."
  },
  {
    name: "milestone.schema.json",
    title: "Company Milestone Record",
    required: ["milestone_id", "objective", "why_it_matters", "evidence_required", "technical_requirements", "capital_required", "status"],
    description: "Evidence-gated progress checkpoints required prior to advancing program phases or unlocking capital."
  },
  {
    name: "rp01-record.schema.json",
    title: "RP01 Research Workflow Records",
    required: ["kind", "id", "protocol_id"],
    description: "Validates literature sources, screening passes, deduplications, reviews, findings, and citation graph edges."
  },
  {
    name: "work-item-operating-mode.schema.json",
    title: "Work-Item Operating Mode",
    required: ["work_item_id", "operating_regime", "process_maturity", "uncertainty_level", "measurement_state", "human_approved"],
    description: "Assigns appropriate operating regime (Discovery to Scale) and prevents premature standardization."
  }
];

export const SYSTEM_GATES: GateInfo[] = [
  {
    id: "GATE-01",
    name: "Custom Silicon / Accelerator Tape-Out",
    status: "GATED",
    rationale: "Software-first mandate: workload economics and scheduling must be proven on commercially available hardware.",
    required_evidence: "Measured, reproducible bottleneck on tuned COTS GPUs/CPUs that cannot be mitigated in software runtime."
  },
  {
    id: "GATE-02",
    name: "Rack Topology & Disaggregation",
    status: "GATED",
    rationale: "Physical rack redesign is speculative without empirical cluster interconnect saturation data.",
    required_evidence: "Demonstrated communication and memory bandwidth bottleneck derived from real multi-node serving workloads."
  },
  {
    id: "GATE-03",
    name: "Thermal / Fluid Cooling Invention",
    status: "GATED",
    rationale: "Immersion or bespoke fluid dynamics are unproven and unnecessary at current exploratory compute scale.",
    required_evidence: "Empirically measured thermal dissipation exceeding standard datacenter air/liquid cooling limits."
  },
  {
    id: "GATE-04",
    name: "Energy Generation Mechanism",
    status: "UNASSESSED",
    rationale: "Not located in the reviewed six-PDF archive. No standalone physical mechanism or conservation accounting exists.",
    required_evidence: "Independent physics review, first-principles conservation proofs, and calibrated laboratory measurements."
  },
  {
    id: "GATE-05",
    name: "HYP-0001 Experiment Authorization",
    status: "NOT_APPROVED_FOR_EXPERIMENT",
    rationale: "GAP-0001 remains UNRESOLVED. Prior art mapping in RP01 must complete adversarial search before experiments run.",
    required_evidence: "Literature saturation across 15 query families confirming unaddressed gap and human approval of protocol."
  }
];
