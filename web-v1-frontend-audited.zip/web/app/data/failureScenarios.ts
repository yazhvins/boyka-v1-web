import { TechnicalFailureScenario } from '../types';

export const FAILURE_SCENARIOS: TechnicalFailureScenario[] = [
  {
    id: 'FAIL-001',
    title: 'Benchmark Compute Advantage Disappears Under Stronger Baseline',
    category: 'ALGORITHMIC',
    symptom: 'BOYKA early-exit shows 45% token savings over raw unoptimized HuggingFace Transformers, but only 4% savings when compared against vLLM + Speculative Decoding baseline.',
    detectionSignal: 'Automated CI/CD benchmark regression alert comparing EXP-RP01-001 against latest upstream vLLM release.',
    diagnosticMethod: 'Isolate token count savings from runtime engine improvements (PagedAttention and fused CUDA kernels).',
    rootCause: 'The baseline was artificially weak. Speculative decoding with small draft models already recaptures much of the autoregressive memory bandwidth penalty.',
    measuredImpact: 'Token advantage shrinks from 45% to 4%; marketing claims of "10x speedup" are falsified.',
    containmentProtocol: 'Halt external publication of benchmark figures. Update experimental baseline to state-of-the-art speculative decoding.',
    decisionGate: 'Gate DEC-RP01-002: Does sequential SPRT stopping provide additive savings on top of speculative decoding?',
    architecturalRedesign: 'Integrate Wald SPRT stopping boundaries directly inside the speculative verification kernel, terminating draft chains early rather than relying solely on draft acceptance.'
  },
  {
    id: 'FAIL-002',
    title: 'Continuous Batching KV-Cache Memory Exhaustion & Stall',
    category: 'MEMORY',
    symptom: 'During a concurrency spike (500 concurrent reasoning streams), GPU HBM reaches 99.8% capacity. Continuous batching scheduler stalls for 1.8 seconds while swapping KV blocks to host DRAM.',
    detectionSignal: 'P99 TTFT spikes from 240ms to 2,100ms; NVML reports 79.8 GB allocated out of 80 GB.',
    diagnosticMethod: 'Profile PagedAttention memory manager block allocation table during multi-path beam expansion.',
    rootCause: 'Speculative reasoning branches allocate memory blocks for hypothetical paths. The runtime did not eagerly reclaim blocks when branches were pruned by the verifier.',
    measuredImpact: 'Throughput collapses by 65%; 12% of requests experience socket timeout errors.',
    containmentProtocol: 'Activate dynamic concurrency throttle: reject incoming requests above 400 active streams until free memory exceeds 15%.',
    decisionGate: 'Gate MEM-01: Implement non-blocking atomic page deallocation on early exit before accepting production workloads.',
    architecturalRedesign: 'Implement eager lockless KV-block reclamation hook: as soon as SPRT prunes a reasoning branch, its physical block IDs are pushed back to the free pool in < 200 microseconds.'
  },
  {
    id: 'FAIL-003',
    title: 'Interconnect Network Latency Dominates Distributed Tensor Parallelism',
    category: 'NETWORK',
    symptom: 'Scaling 70B parameter model from 4 GPUs (TP=4) to 8 GPUs (TP=8) yields only 1.15x throughput increase instead of the expected 1.85x.',
    detectionSignal: 'Nsight Systems timeline shows NCCL AllReduce kernel occupying 54% of total forward-pass time.',
    diagnosticMethod: 'Trace NCCL collective communication times across NVLink 4.0 vs PCIe fallback paths.',
    rootCause: 'At small batch sizes (batch size = 1 or 2 per GPU), the GEMM computation time is so small (< 80 μs) that the 11.8 μs AllReduce latency and CPU launch overhead dominate the execution loop.',
    measuredImpact: 'Hardware cost doubles (8 GPUs vs 4 GPUs) with virtually zero latency improvement for interactive users.',
    containmentProtocol: 'Pin small-batch interactive workloads to TP=2 or TP=4; reserve TP=8 exclusively for high-throughput batched serving.',
    decisionGate: 'Gate NET-01: Disallow TP=8 deployments unless concurrency batch size per GPU is >= 8.',
    architecturalRedesign: 'Implement Pipeline Parallelism (PP) or Megatron sequence parallelism with communication-computation overlap (CUDA streams).'
  },
  {
    id: 'FAIL-004',
    title: 'Verifier Produces False Acceptance on Out-Of-Distribution Prompts',
    category: 'VERIFIER',
    symptom: 'On novel financial reasoning prompts, BOYKA early-exit terminates at step 2 with 99.1% reported confidence, but the final answer is completely mathematically incorrect.',
    detectionSignal: 'Customer golden-set accuracy drops from 91.4% to 74.2% on financial filings dataset.',
    diagnosticMethod: 'Plot Expected Calibration Error (ECE) and reliability diagrams of the verifier model across diverse prompt domains.',
    rootCause: 'The verifier model was trained exclusively on GSM8K/MATH and suffers from overconfidence on out-of-distribution syntax and tabular financial data.',
    measuredImpact: 'Customer trust breached; high risk of enterprise contract cancellation.',
    containmentProtocol: 'Force verifier confidence threshold from 0.98 to 0.999 for financial domain endpoints; disable early exit for enterprise accounts requesting strict verification.',
    decisionGate: 'Gate VERIF-01: Verifier calibration audit required for any new customer domain prior to enabling early exit.',
    architecturalRedesign: 'Implement conformal prediction bands and domain-adaptive temperature scaling to guarantee a user-specified error bound.'
  },
  {
    id: 'FAIL-005',
    title: 'Minton\'s Utility Problem: Controller Overhead Exceeds Generation Savings',
    category: 'ALGORITHMIC',
    symptom: 'Deploying an advanced step-level verifier to decide early stopping increases total end-to-end latency by 18%, despite reducing generated token count by 30%.',
    detectionSignal: 'Prometheus metrics show average query latency increased from 820ms to 967ms.',
    diagnosticMethod: 'Break down query latency into: (1) generation time, (2) verifier forward-pass time, and (3) host CPU scheduler decision overhead.',
    rootCause: 'The verifier model (a 3B parameter model) required 14ms per step. Evaluating it after every step across 10 steps added 140ms of overhead, completely erasing the 120ms saved by avoiding tokens.',
    measuredImpact: 'Negative customer value proposition: paying for extra compute while receiving slower answers.',
    containmentProtocol: 'Immediately revert to evaluating the verifier only every 4th step or at explicit sentence boundary tokens (period, newline).',
    decisionGate: 'Gate ALGO-01: Verifier execution time per check must be mathematically bounded to < 2.5% of generation step time.',
    architecturalRedesign: 'Replace full neural verifier forward pass with a lightweight token-level value head trained directly into the base generator\'s hidden state.'
  },
  {
    id: 'FAIL-006',
    title: 'Rack Density Improves But Cooling Pumping Power Erases Net Energy Gain',
    category: 'RACK_THERMAL',
    symptom: 'Compressing 8 HGX nodes into a high-density 80kW rack with custom liquid cooling reduces datacenter floor footprint by 50%, but facility PUE degrades from 1.15 to 1.34.',
    detectionSignal: 'Facility power monitor indicates chiller and coolant distribution unit (CDU) pump power consumes 24% of total IT load.',
    diagnosticMethod: 'Measure pressure drop across micro-channel cold plates vs coolant volumetric flow rate.',
    rootCause: 'Overly restrictive micro-channel cold plates required extreme pump pressure (65 psi) to maintain turbulent flow, driving parasitic pumping power to unacceptable levels.',
    measuredImpact: 'Total cost of ownership (TCO) increases by 14%; green efficiency claims negated by parasitic power draw.',
    containmentProtocol: 'De-rate rack power density from 80kW to 45kW by spacing server chassis across two standard racks.',
    decisionGate: 'Gate THERM-01: Reject custom liquid cold-plate designs that demand CDU pumping power > 3.0% of IT load.',
    architecturalRedesign: 'Utilize standard OCP Open Rack v3 reference cold plates with low pressure drop (delta-P < 15 psi) operating on warm-water facility supply (32°C).'
  }
];
