import { EvidenceItem } from '../types';

export const EVIDENCE_CATALOG: Record<string, EvidenceItem> = {
  'ev-adaptive-compute': {
    id: 'ev-adaptive-compute',
    title: 'Adaptive Allocation of Computation Principle',
    claim_or_summary: 'Intelligent systems achieve superior efficiency by allocating inference compute dynamically based on problem difficulty and expected improvement.',
    source_type: 'ACADEMIC_PAPER',
    source_reference: 'Russell & Wefald (1991), Principles of Metareasoning, AI Journal; Horvitz (1987), AAAI.',
    exact_quote: 'A rational agent should take the computational action α that maximizes expected net utility: V(S, α) = U(S_α) - U(S_0) - Cost(α).',
    canonical_id: 'CAND-001 / FP-0001',
    evidence_level: 'E5_PEER_REVIEWED',
    limitations: [
      'Myopic single-step horizon assumptions fail in multi-step LLM chains',
      'Meta-controller computation consumes latency and memory',
      'Theoretical optimality holds only with calibrated utility expectations'
    ],
    contradicting_evidence: 'The Utility Problem (Minton 1988; Etzioni 1991): Metalevel deliberation can exceed base execution savings.',
    review_status: 'VERIFIED',
    provenance_trail: '05-prior-art/CANDIDATE_SURVEY_BATCH_001.md -> 06-first-principles/FP-0001-VALUE-OF-COMPUTATION.md'
  },
  'ev-boyka-part1-claim': {
    id: 'ev-boyka-part1-claim',
    title: 'BOYKA Source Proposal: Compute-Efficient Intelligence',
    claim_or_summary: 'BOYKA proposes replacing uniform fixed-parameter inference with dynamic compute graphs, anytime early exit, and verification loops.',
    source_type: 'BOYKA_DOCUMENT',
    source_reference: 'Boyka Computing - Part I.pdf, pages 1-2; Boyka Computing - Part III (Rebuilding AI stack), page 1.',
    exact_quote: 'Rebuild the AI execution runtime around adaptive compute graphs and speculative verification to deliver high-reliability reasoning at a fraction of hyperscaler cost.',
    canonical_id: 'STMT-0001 / BOYKA-SRC-001',
    evidence_level: 'E1_ASSERTION',
    limitations: [
      'Source archive contains conceptual proposals only; no benchmark receipts or code',
      'Numeric claims (e.g. 10x-100x efficiency) were illustrative goals, not validated measurements',
      'Hardware requirements are asserted but unproven on COTS baselines'
    ],
    contradicting_evidence: 'No empirical benchmark on open or private testbeds is present in the 49-page source archive.',
    review_status: 'AWAITING_REVIEW',
    provenance_trail: '01-intake-manifest/MANIFEST.json -> BOYKA-SRC-001 -> STMT-0001'
  },
  'ev-hardware-gating': {
    id: 'ev-hardware-gating',
    title: 'COTS First Hardware Discipline Policy',
    claim_or_summary: 'Custom silicon (ASIC) and physical rack redesigns are premature and economically unjustified until software optimizations on commodity GPUs are exhausted.',
    source_type: 'GOVERNANCE_DECISION',
    source_reference: 'Architecture Decision Record DEC-RP01-001; 15-hardware/SILICON_GATING_POLICY.md.',
    exact_quote: 'Custom silicon engineering is strictly frozen in Phase 1 (Discovery) until software achieves >85% MFU on COTS GPUs and proves an insurmountable interconnect bottleneck.',
    canonical_id: 'GATE-01 / DEC-RP01-001',
    evidence_level: 'E2_THEORETICAL',
    limitations: [
      'COTS hardware has fixed memory bus topology that may limit draft verification',
      'Modern H100/B200 clusters carry high cloud rental rates during large-scale evaluation'
    ],
    review_status: 'GATED',
    provenance_trail: '15-hardware/SILICON_GATING_POLICY.md -> 20-decisions/DEC-RP01-001-BATCH-001-INTAKE.md'
  },
  'ev-anytime-stopping': {
    id: 'ev-anytime-stopping',
    title: 'Wald SPRT & Hansen-Zilberstein Anytime Stopping',
    claim_or_summary: 'Optimal stopping during stochastic multi-path sampling can be solved using sequential probability ratio testing without waiting for a fixed sample count.',
    source_type: 'ACADEMIC_PAPER',
    source_reference: 'Wald & Wolfowitz (1948), Annals of Math. Statistics; Hansen & Zilberstein (2001), AI Journal.',
    exact_quote: 'Under i.i.d. sampling, no test can achieve error rates (α, β) with smaller expected sample size than the Sequential Probability Ratio Test (SPRT).',
    canonical_id: 'CAND-006 / FP-0002',
    evidence_level: 'E5_PEER_REVIEWED',
    limitations: [
      'Requires calibrated log-likelihood ratios which raw LLM logits frequently do not provide',
      'Continuous batching engines must support early thread retirement without wasting allocated KV-cache'
    ],
    review_status: 'VERIFIED',
    provenance_trail: '02-research-universe/candidate-batches/batch-001/candidate-papers.jsonl -> CAND-006'
  },
  'ev-landauer-thermodynamics': {
    id: 'ev-landauer-thermodynamics',
    title: 'Thermodynamic Energy Bounds on Reasoning Tokens',
    claim_or_summary: 'Generating reasoning tokens has an irreducible thermodynamic cost governed by Landauer\'s principle and silicon energy dissipation.',
    source_type: 'PHYSICAL_LAW',
    source_reference: 'Landauer (1961), IBM J. Res. Dev.; 06-first-principles/FP-0003-PHYSICAL-LIMITS-LANDAUER.md.',
    exact_quote: 'E_min = k_B * T * ln(2) per bit erasure. Modern GPUs operate at ~0.7 pJ/FLOP; a 70B parameter model dissipates ~0.1 Joules per generated token.',
    canonical_id: 'FP-0003',
    evidence_level: 'E5_PEER_REVIEWED',
    limitations: [
      'Silicon leakage and cooling overhead (PUE ~1.15) increase effective energy consumption above core FLOPs',
      'Memory access across HBM consumes 3-5x more energy than raw arithmetic math'
    ],
    review_status: 'VERIFIED',
    provenance_trail: '06-first-principles/FP-0003-PHYSICAL-LIMITS-LANDAUER.md'
  },
  'ev-customer-validation-status': {
    id: 'ev-customer-validation-status',
    title: 'Current Customer Evidence Baseline',
    claim_or_summary: 'No customer study, paid pilot, signed contract, or commercial revenue has been conducted or established to date.',
    source_type: 'SYSTEM_MEASUREMENT',
    source_reference: 'Source Archive Audit; 22-customer/README.md; ABSENCE_OBSERVATIONS.',
    exact_quote: 'No named customer study, paid pilot, contract, or revenue evidence was located in the reviewed six-PDF archive.',
    canonical_id: 'ABSENCE-005',
    evidence_level: 'E4_REPRODUCIBLE',
    limitations: [
      'Represents historical status of initial archive intake; customer discovery outreach is planned for Phase 2'
    ],
    review_status: 'VERIFIED',
    provenance_trail: '00-governance/decisions/DEC-SOURCE-AUDIT-001.json -> ABSENCE_OBSERVATIONS'
  },
  'ev-kv-cache-bottleneck': {
    id: 'ev-kv-cache-bottleneck',
    title: 'KV-Cache Memory Capacity as Primary Search Bottleneck',
    claim_or_summary: 'Test-time multi-path tree search is bounded by High-Bandwidth Memory (HBM) capacity rather than raw compute FLOPS.',
    source_type: 'SYSTEM_MEASUREMENT',
    source_reference: '13-memory/KV_CACHE_ALLOCATION_BOUNDS.md; Pope et al. (2023).',
    exact_quote: 'A 70B parameter model requires ~320 KB per token of KV cache. 64 concurrent multi-path reasoning paths of 16K tokens require 327 GB of HBM.',
    canonical_id: 'BOUND-KV-001',
    evidence_level: 'E2_THEORETICAL',
    limitations: [
      'Paging mechanisms (PagedAttention) and FP8 KV-cache quantization can compress footprint by 2x-4x',
      'Prefix caching allows shared stem reuse across parallel branches'
    ],
    review_status: 'VERIFIED',
    provenance_trail: '13-memory/KV_CACHE_ALLOCATION_BOUNDS.md'
  }
};

export const getEvidence = (id: string): EvidenceItem | undefined => {
  return EVIDENCE_CATALOG[id];
};
