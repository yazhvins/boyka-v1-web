export interface LeadershipStageCell {
  roleId: string;
  roleTitle: string;
  stageId: string;
  stageName: string;
  dedicatedRequired: 'FOUNDER_OWNED' | 'FRACTIONAL_OR_ADVISORY' | 'DEDICATED_EXECUTIVE' | 'NOT_APPLICABLE';
  whatFunctionDoes: string;
  outputsOwed: string[];
  decisionsInfluenced: string[];
  capabilitiesRequired: string[];
  hiringTrigger: string;
}

export const STAGES_LIST = [
  { id: 'FORMATION', name: '01. Formation', focus: 'Founding thesis, co-founder alignment, ownership, legal entity' },
  { id: 'DISCOVERY', name: '02. Discovery', focus: 'First-principles physics, literature survey, core technical gap formulation' },
  { id: 'VALIDATION', name: '03. Validation', focus: 'Micro-benchmarks, algorithmic feasibility, customer problem interviews' },
  { id: 'PROTOTYPE', name: '04. Prototype', focus: 'Working software prototype, anytime early-exit demonstration' },
  { id: 'MVP', name: '05. MVP', focus: 'OpenAI-compatible inference gateway, developer onboarding, security baseline' },
  { id: 'PILOT', name: '06. Pilot', focus: '3-5 unpaid/paid enterprise proof-of-concept deployments, SLA validation' },
  { id: 'COMMERCIAL', name: '07. Commercial', focus: 'First paid annual contracts, repeatable pricing, SOC 2 Type II' },
  { id: 'GROWTH', name: '08. Growth', focus: 'Scaling sales, multi-region cloud deployment, gross margin expansion' },
  { id: 'SCALE', name: '09. Scale', focus: 'Platform expansion, hardware acceleration evaluation, category leadership' },
];

export const ROLES_LIST = [
  { id: 'CEO', name: 'Chief Executive Officer', defaultOwner: 'Lipun' },
  { id: 'CTO', name: 'Chief Technology Officer', defaultOwner: 'Arun Kumar (Candidate)' },
  { id: 'CFO', name: 'Finance & Capital (CFO)', defaultOwner: 'Founder-owned → Fractional' },
  { id: 'COO', name: 'Operations (COO)', defaultOwner: 'Founders → Head of Ops' },
  { id: 'CPO', name: 'Product (CPO)', defaultOwner: 'Founding CTO / CEO → VP Product' },
  { id: 'CRO', name: 'Sales & Revenue (CRO)', defaultOwner: 'Founder-led Sales → VP Sales' },
  { id: 'CMO', name: 'Marketing & GTM (CMO)', defaultOwner: 'Founders → Head of Growth' },
  { id: 'CIO_CDO', name: 'Data & Enterprise Systems', defaultOwner: 'Deferred until Scale' },
  { id: 'CISO', name: 'Security & Trust (CISO)', defaultOwner: 'CTO → Fractional → Head of Security' },
  { id: 'PEOPLE', name: 'People & Talent', defaultOwner: 'Founders → Talent Lead' },
  { id: 'LEGAL_IP', name: 'Legal & IP', defaultOwner: 'External Counsel' },
  { id: 'RESEARCH', name: 'Research Leadership', defaultOwner: 'Founding CTO' },
  { id: 'ENGINEERING', name: 'Engineering Leadership', defaultOwner: 'Founding CTO → VP Eng' },
];

export const MATRIX_CELLS: Record<string, LeadershipStageCell> = {
  // CEO at various stages
  'CEO-FORMATION': {
    roleId: 'CEO',
    roleTitle: 'Chief Executive Officer',
    stageId: 'FORMATION',
    stageName: 'Formation',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Establishes company mission, recruits co-founder, incorporates entity, aligns equity split and founder vision.',
    outputsOwed: ['Founder Accord', 'Initial Equity Cap Table', 'Mission Statement'],
    decisionsInfluenced: ['Co-founder selection', 'Corporate structure', 'Core venture direction'],
    capabilitiesRequired: ['Strategic clarity', 'Storytelling', 'High-conviction alignment'],
    hiringTrigger: 'Company inception (Co-Founder).'
  },
  'CEO-VALIDATION': {
    roleId: 'CEO',
    roleTitle: 'Chief Executive Officer',
    stageId: 'VALIDATION',
    stageName: 'Validation',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Conducts customer problem interviews with CTO; establishes advisory network; prepares initial pre-seed/seed narrative.',
    outputsOwed: ['Customer Problem Ledger (20 interviews)', 'Pre-seed Pitch Deck', 'Runway Plan'],
    decisionsInfluenced: ['Customer segment selection', 'Fundraising timing', 'Initial capital allocation'],
    capabilitiesRequired: ['Customer empathy', 'Investor relationship building', 'Synthesis of market signals'],
    hiringTrigger: 'Existing founder.'
  },
  'CEO-PILOT': {
    roleId: 'CEO',
    roleTitle: 'Chief Executive Officer',
    stageId: 'PILOT',
    stageName: 'Pilot',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Closes 3-5 pilot sponsor agreements; leads enterprise executive relationships; runs fundraising process.',
    outputsOwed: ['[SCENARIO ASSUMPTION — NOT MEASURED] Signed Pilot Letters of Intent (LOIs)', 'Term Sheet Evaluation', 'Board Updates'],
    decisionsInfluenced: ['Pilot contract scope', 'Pricing commitments', 'Capital round terms'],
    capabilitiesRequired: ['Enterprise negotiation', 'Fundraising execution', 'Executive presence'],
    hiringTrigger: 'Existing founder.'
  },
  'CEO-SCALE': {
    roleId: 'CEO',
    roleTitle: 'Chief Executive Officer',
    stageId: 'SCALE',
    stageName: 'Scale',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Sets multi-year capital strategy; drives major strategic partnerships; maintains company culture and executive team alignment.',
    outputsOwed: ['Annual Operating Plan', 'Board Resolutions', 'Major Strategic Joint Ventures'],
    decisionsInfluenced: ['M&A opportunities', 'Hardware investments', 'Public positioning'],
    capabilitiesRequired: ['Executive management', 'Macro capital allocation', 'Visionary leadership'],
    hiringTrigger: 'Existing founder.'
  },

  // CTO at various stages
  'CTO-FORMATION': {
    roleId: 'CTO',
    roleTitle: 'Chief Technology Officer',
    stageId: 'FORMATION',
    stageName: 'Formation',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Conducts exhaustive audit of BOYKA proposal, validates physical first principles (Landauer, memory-wall), establishes technical governance.',
    outputsOwed: ['Source Document Audit (49 pp)', 'First-Principles Physics Dossier', 'Architecture Decision Records (ADRs)'],
    decisionsInfluenced: ['Technical thesis viability', 'Scope boundaries', 'Hardware vs software gating'],
    capabilitiesRequired: ['Deep-tech systems understanding', 'Scientific rigor', 'Adversarial critical thinking'],
    hiringTrigger: 'Co-founder onboarding.'
  },
  'CTO-VALIDATION': {
    roleId: 'CTO',
    roleTitle: 'Chief Technology Officer',
    stageId: 'VALIDATION',
    stageName: 'Validation',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Designs and executes micro-benchmarks on commodity GPU testbeds; evaluates SPRT anytime stopping algorithms on GSM8K/MATH datasets.',
    outputsOwed: ['Micro-Benchmark Receipts (EXP-RP01-001)', 'Verifier Accuracy Curves', 'GPU Telemetry Logs'],
    decisionsInfluenced: ['Algorithmic direction', 'Candidate pruning', 'Compute budget requirements'],
    capabilitiesRequired: ['CUDA/PyTorch internals', 'Mathematical statistics (Wald analysis)', 'Inference profiling'],
    hiringTrigger: 'Existing co-founder.'
  },
  'CTO-PROTOTYPE': {
    roleId: 'CTO',
    roleTitle: 'Chief Technology Officer',
    stageId: 'PROTOTYPE',
    stageName: 'Prototype',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Builds end-to-end working software prototype; implements OpenAI-compatible proxy with dynamic early-exit and KV-cache manager.',
    outputsOwed: ['Executable Prototype Demo', 'End-to-End Latency vs Accuracy Receipts', 'Technical Architecture Whitepaper'],
    decisionsInfluenced: ['Framework selection (vLLM vs SGLang)', 'API protocol contract', 'Model weight licensing'],
    capabilitiesRequired: ['High-performance distributed systems', 'C++ / Rust / Python runtime', 'API design'],
    hiringTrigger: 'Existing co-founder.'
  },
  'CTO-PILOT': {
    roleId: 'CTO',
    roleTitle: 'Chief Technology Officer',
    stageId: 'PILOT',
    stageName: 'Pilot',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Oversees technical pilot deployments inside enterprise customer VPCs; monitors latency SLAs; handles edge-case model deviations.',
    outputsOwed: ['Pilot Deployment Runbooks', 'SLA Performance Dashboard', 'Security Hardening Checklist'],
    decisionsInfluenced: ['Deployment architecture (SaaS vs VPC)', 'Custom enterprise adapters', 'Technical support escalation'],
    capabilitiesRequired: ['Enterprise DevOps / Kubernetes', 'Infosec compliance', 'Technical customer communication'],
    hiringTrigger: 'Existing co-founder.'
  },
  'CTO-SCALE': {
    roleId: 'CTO',
    roleTitle: 'Chief Technology Officer',
    stageId: 'SCALE',
    stageName: 'Scale',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Leads multi-team technical organization (Research, Core Systems, Developer Platform); evaluates next-gen hardware/chip co-design.',
    outputsOwed: ['3-Year Technology Roadmap', 'Silicon Gating Evaluation Report', 'Patent Portfolio Strategy'],
    decisionsInfluenced: ['Custom silicon tape-out', 'Global data center infrastructure', 'Technical acquisitions'],
    capabilitiesRequired: ['Organizational design', 'Hardware-software co-design', 'Long-term technology forecasting'],
    hiringTrigger: 'Existing co-founder.'
  },

  // CFO across stages
  'CFO-FORMATION': {
    roleId: 'CFO',
    roleTitle: 'Finance & Capital (CFO)',
    stageId: 'FORMATION',
    stageName: 'Formation',
    dedicatedRequired: 'FOUNDER_OWNED',
    whatFunctionDoes: 'CEO and CTO track zero-burn formation expenses and legal filing costs.',
    outputsOwed: ['Expense tracking spreadsheet'],
    decisionsInfluenced: ['Incorporation state', 'Bank account setup'],
    capabilitiesRequired: ['Basic accounting'],
    hiringTrigger: 'Not required.'
  },
  'CFO-VALIDATION': {
    roleId: 'CFO',
    roleTitle: 'Finance & Capital (CFO)',
    stageId: 'VALIDATION',
    stageName: 'Validation',
    dedicatedRequired: 'FRACTIONAL_OR_ADVISORY',
    whatFunctionDoes: 'Fractional CFO or bookkeeper structures bottom-up runway model for cloud GPU spend and initial founder stipends.',
    outputsOwed: ['18-Month Bottom-Up Budget', 'Cloud GPU Cost Projections', 'Tax Compliance Filings'],
    decisionsInfluenced: ['Cloud provider credit negotiation', 'Runway length calculation'],
    capabilitiesRequired: ['SaaS unit economics', 'R&D tax credits (QSBS / R&D credit)'],
    hiringTrigger: 'First external capital close.'
  },
  'CFO-COMMERCIAL': {
    roleId: 'CFO',
    roleTitle: 'Finance & Capital (CFO)',
    stageId: 'COMMERCIAL',
    stageName: 'Commercial',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: '[SCENARIO ASSUMPTION — NOT MEASURED] Full-time VP Finance manages billing engine, customer invoicing, enterprise contract ARR recognition, and series A/B models.',
    outputsOwed: ['GAAP Financial Statements', 'Cohort Gross Margin Tracking', 'Capital Allocation Model'],
    decisionsInfluenced: ['Pricing discount floors', 'Cloud reserved instance commitments', 'Staffing ramp budget'],
    capabilitiesRequired: ['Enterprise SaaS & infrastructure finance', 'Series A+ fundraising diligence'],
    hiringTrigger: '[SCENARIO ASSUMPTION — NOT MEASURED] Exceeding $1.5M ARR or closing Series A.'
  },

  // CISO across stages
  'CISO-VALIDATION': {
    roleId: 'CISO',
    roleTitle: 'Security & Trust (CISO)',
    stageId: 'VALIDATION',
    stageName: 'Validation',
    dedicatedRequired: 'FOUNDER_OWNED',
    whatFunctionDoes: 'CTO enforces zero secrets in code, TLS in transit, and clean boundary separation for research testbeds.',
    outputsOwed: ['Baseline Security Guidelines'],
    decisionsInfluenced: ['Cloud access control', 'SSH key rotation'],
    capabilitiesRequired: ['Basic cloud security hygiene'],
    hiringTrigger: 'CTO owned.'
  },
  'CISO-MVP': {
    roleId: 'CISO',
    roleTitle: 'Security & Trust (CISO)',
    stageId: 'MVP',
    stageName: 'MVP',
    dedicatedRequired: 'FRACTIONAL_OR_ADVISORY',
    whatFunctionDoes: 'Fractional CISO / compliance consultant prepares SOC 2 Type I readiness; audits multi-tenant prompt data isolation.',
    outputsOwed: ['Data Flow Diagram', 'Data Retention Policy', 'Penetration Test Report'],
    decisionsInfluenced: ['Zero-retention logging architecture', 'Tenant isolation boundary'],
    capabilitiesRequired: ['SOC 2 Type I / II framework', 'API gateway security'],
    hiringTrigger: 'First enterprise pilot discussions.'
  },
  'CISO-COMMERCIAL': {
    roleId: 'CISO',
    roleTitle: 'Security & Trust (CISO)',
    stageId: 'COMMERCIAL',
    stageName: 'Commercial',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Full-time Head of Security manages customer security questionnaires, SOC 2 Type II audits, HIPAA / FedRAMP pipelines.',
    outputsOwed: ['SOC 2 Type II Certification', 'Enterprise Security Whitepaper', 'Incident Response Runbook'],
    decisionsInfluenced: ['Compliance certifications roadmap', 'Vendor security reviews'],
    capabilitiesRequired: ['Enterprise infosec leadership', 'VPC network security'],
    hiringTrigger: 'Customer enterprise infosec reviews becoming sales bottleneck.'
  },

  // Legal & IP across stages
  'LEGAL_IP-FORMATION': {
    roleId: 'LEGAL_IP',
    roleTitle: 'Legal & IP',
    stageId: 'FORMATION',
    stageName: 'Formation',
    dedicatedRequired: 'FRACTIONAL_OR_ADVISORY',
    whatFunctionDoes: 'External corporate counsel drafts incorporation, founder IP assignment agreements, and 83(b) tax elections.',
    outputsOwed: ['Proprietary Information & Inventions Agreement (PIIA)', 'Certificate of Incorporation'],
    decisionsInfluenced: ['Vesting schedule', 'IP clean-room ownership'],
    capabilitiesRequired: ['Startup corporate law'],
    hiringTrigger: 'Immediate on founding.'
  },
  'LEGAL_IP-PROTOTYPE': {
    roleId: 'LEGAL_IP',
    roleTitle: 'Legal & IP',
    stageId: 'PROTOTYPE',
    stageName: 'Prototype',
    dedicatedRequired: 'FRACTIONAL_OR_ADVISORY',
    whatFunctionDoes: 'Patent counsel conducts Freedom-to-Operate (FTO) review and drafts provisional patent applications for novel runtime stopping mechanisms.',
    outputsOwed: ['FTO Search Report', 'Provisional Patent Application (Adaptive Inference Stopping)'],
    decisionsInfluenced: ['Public paper publication vs trade secret protection', 'Open-source licensing terms'],
    capabilitiesRequired: ['AI/Software patent prosecution', 'Decision theory prior art expertise'],
    hiringTrigger: 'Demonstration of novel runtime mechanism in working prototype.'
  },

  // People across stages
  'PEOPLE-VALIDATION': {
    roleId: 'PEOPLE',
    roleTitle: 'People & Talent',
    stageId: 'VALIDATION',
    stageName: 'Validation',
    dedicatedRequired: 'FOUNDER_OWNED',
    whatFunctionDoes: 'Founders manage direct technical sourcing through personal networks for initial Founding Engineers.',
    outputsOwed: ['Target Candidate Pipeline', 'Technical Interview Rubric'],
    decisionsInfluenced: ['Founder equity grant ranges', 'Technical culture definition'],
    capabilitiesRequired: ['Technical talent bar assessment'],
    hiringTrigger: 'Founders own until 10-15 team members.'
  },
  'PEOPLE-COMMERCIAL': {
    roleId: 'PEOPLE',
    roleTitle: 'People & Talent',
    stageId: 'COMMERCIAL',
    stageName: 'Commercial',
    dedicatedRequired: 'DEDICATED_EXECUTIVE',
    whatFunctionDoes: 'Head of People / Talent manages recruiting pipelines, compensation benchmarking, performance reviews, and culture scaling.',
    outputsOwed: ['Leveling & Compensation Matrix', 'Employee Handbook', 'Recruiting Velocity Dashboard'],
    decisionsInfluenced: ['Option pool refresh', 'Remote vs hub office policy'],
    capabilitiesRequired: ['High-growth tech recruiting', 'People operations'],
    hiringTrigger: 'Team exceeds 12-15 employees.'
  }
};
