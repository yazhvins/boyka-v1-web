'use client';

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="mx-auto max-w-2xl space-y-4 p-8" role="alert">
      <h1 className="text-xl font-semibold">The application could not render this page.</h1>
      <p className="text-sm text-slate-600">No execution is assumed to have succeeded. You can retry the page or return to the product portal.</p>
      {error.digest ? <p className="font-mono text-xs">Reference: {error.digest}</p> : null}
      <div className="flex gap-3"><button className="rounded border px-3 py-2" onClick={reset}>Try again</button><a className="rounded border px-3 py-2" href="/">Portal</a></div>
    </main>
  );
}
