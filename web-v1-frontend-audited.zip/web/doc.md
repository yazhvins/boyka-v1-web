# BOYKA V1 Frontend — Full Source Audit, Product UX Specification, and Upgrade Plan

**Document status:** Source-based audit and target product specification  
**Audit date:** 17 November 2026  
**Source archive:** `web.zip`  
**Application root in archive:** `web/`  
**Primary implementation inspected:** `web/app/workspace/page.tsx`, `web/app/lib/backend.ts`, API route handlers, screen components, data catalogs, and Playwright E2E tests.

---

## 1. Purpose and decision

This document records what the supplied frontend actually contains, what it does not yet provide, the risks that must be corrected, and the complete customer-facing frontend that BOYKA V1 should expose.

The supplied archive is a Next.js application with a compute workspace and a large engineering/architecture portal. It is **not yet a complete customer-facing BOYKA V1 application**. The current product surface is primarily a CPU arithmetic execution console plus technical evidence screens. The V1 product definition requires a broader customer workflow: create a project/application, describe or submit an AI, non-AI, or hybrid workload, connect authorized models and compute resources, plan and execute work, observe the real execution, independently inspect verification, retrieve artifacts/results, and manage deployments, usage, and history.

### Decision

1. Preserve and improve the existing execution, capability, history, receipt, and run-inspection experiences. They are useful foundations.
2. Rebuild the product information architecture around customer workspaces, projects, applications, workloads, resources, providers, executions, results, deployments, and governance.
3. Move the current engineering portal, research catalogs, and presilicon/hardware demonstrations out of the ordinary customer V1 navigation. Retain them only as a separately permissioned internal engineering area if they remain useful.
4. Remove V2 and future-hardware choices from the V1 customer execution path. V2 may be shown as a clearly separate roadmap or unavailable product area, never as a selectable V1 runtime.
5. Make the UI an honest client of the authoritative V1 backend. It must not invent successful runs, verified results, available hardware, benchmark values, persistence, or provider capabilities.
6. Treat backend/API contracts as the source of truth. The frontend must not reimplement scheduling, workload classification, resource eligibility, verification, or receipt generation.

This is a source review of the supplied ZIP. It is not a claim that the app was executed, built, type-checked, security-tested, or connected to a live BOYKA backend during this review.

---

## 2. Scope, evidence standard, and archive inventory

### 2.1 What was inspected

The archive contains 173 ZIP entries, including generated `.next/dev` output. The source review excluded generated `.next` build/cache files and examined the application source, API routes, configuration, data modules, and E2E test.

Important source files:

| Area | Files |
|---|---|
| App entry and shell | `app/page.tsx`, `app/layout.tsx`, `app/globals.css`, `app/loading.tsx`, `app/error.tsx`, `app/not-found.tsx` |
| Main workspace | `app/workspace/page.tsx` |
| Backend gateway | `app/lib/backend.ts`, `app/api/backend-status/route.ts` |
| V1 API routes | `app/api/compute/capabilities/route.ts`, `execute/route.ts`, `jobs/route.ts`, `history/route.ts`, `runs/[runId]/route.ts`, `runs/[runId]/cancel/route.ts`, `receipts/import/route.ts`, `hardware/route.ts`, `benchmarks/run/route.ts` |
| V2 API routes | `app/api/compute/v2/capabilities/route.ts`, `execute/route.ts`, `jobs/route.ts`, `graph/jobs/route.ts`, `app/api/v2/[...path]/route.ts` |
| Screens | `OverviewScreen.tsx`, `ExecutionPlanScreen.tsx`, `RunDetailsScreen.tsx`, `BenchmarksScreen.tsx`, `EngineeringPortalScreen.tsx`, `HardwareEngineeringScreen.tsx` |
| Simulations | `ExecutionGraphSimulation.tsx`, `CacheCoherenceSimulation.tsx` |
| Data catalogs | architecture layers, capability architecture, decisions, evidence, executive cases, failure scenarios, financing workflow, leadership matrix, review annotations, scenarios, canonical source/evidence data, subsystem evaluations, theories, workload traces, generated repository status |
| Types | `app/types.ts`, `app/engineering-types.ts` |
| Tests and config | `e2e/compute-workspace.spec.ts`, `package.json`, `playwright.config.ts`, `next.config.ts`, `tsconfig.json`, ESLint config |

### 2.2 Technology visible in the archive

- Next.js `16.4.0`, App Router.
- React and React DOM `19.3.0`.
- TypeScript `5.8.3`.
- Tailwind CSS `4.1.0`.
- `lucide-react` for icons.
- Playwright `1.56.1` for browser E2E tests.
- Dependencies include `@boyka/contracts`, `@boyka/api-client`, and `@boyka/validation`, all pinned to `25.3.0`.

The package name/version is `@boyka/web` / `25.3.0`. The visible code uses a mix of local TypeScript request/response types and direct `fetch()` calls. The presence of shared packages in `package.json` does not by itself prove they are consistently used by every screen or route.

### 2.3 Evidence labels used in this document

- **Observed:** directly visible in the supplied source.
- **Risk:** a likely correctness, security, product, or operational issue inferred from the source.
- **Target requirement:** a proposed requirement for the intended V1 customer product, not a claim that it is already implemented.
- **Unverified:** requires a running application, backend, database, deployment, or test execution to establish.

No production-readiness conclusion should be drawn from source structure alone.

---

## 3. Current frontend: what exists today

### 3.1 Routing and application entry

`app/page.tsx` redirects `/` directly to `/workspace`. There is no public marketing/product landing experience in the supplied app, no sign-in route, no onboarding flow, and no visible account/workspace switcher.

`app/layout.tsx` defines the title and metadata as “BOYKA | Absolute Computing & Intelligence” and describes the site as an architecture, verified computing runtime, engineering portal, and hardware co-design validation product. This wording reflects a technical/engineering portal more than a customer V1 workspace.

The app has a basic global loading state, global error boundary, not-found page, and Tailwind-based global stylesheet. The stylesheet defines light/dark base colors and custom scrollbars. The inspected code does not show a complete reusable design-token system, component library, or explicit theme preference control.

### 3.2 Current primary screen structure

The main route is a single client component at `app/workspace/page.tsx`. It contains a large amount of page state, API orchestration, request validation, polling, history aggregation, download handling, and conditional rendering.

The current top-level screens are:

| Screen | Current title | Actual purpose in source |
|---|---|---|
| A | System Overview & Health | Backend connection, capability/resource eligibility, summary metrics, product/engineering links |
| B | Verified Compute Workspace | Submit a small set of arithmetic operations and inspect the result |
| C | Workload Execution Plan | DAG/plan view, simulation, estimation and pipeline concepts |
| D | Execution Run Details | Run request/output, verification, receipt and history inspection |
| E | Empirical Benchmarks | Static evidence/limitations and prior adaptive-compute result |
| F | Engineering & Architecture Portal | CTO/engineering architecture, decision, theory, evidence and repository audit catalogs |
| G | Hardware Engineering & Presilicon Co-Design | RTL, cache coherence, MMIO and hardware simulation-oriented content |

The tab selection is held in React state and mirrored to the URL query parameter `?tab=` using `history.replaceState`. It is not implemented as separate App Router pages. This means browser navigation, deep links, route-level loading, page-level access control, and independent server rendering are limited by the single-page structure.

### 3.3 Current compute form

The visible V1 operation selector offers only:

- `vector_dot` — two equal-length finite numeric vectors.
- `matmul_ones` — an analytic summary of an all-ones matrix.

The same form also exposes runtime choices for:

- V1 Standard Arithmetic.
- V2 Hardware-Aligned Integer.
- V2 Compute Graph Pipeline.

V2 modes are wired to separate V2 endpoints and are not the V1 customer workload experience. The form includes V2 int16 vector validation and a raw JSON graph editor. This mixes V1 and V2 in the same customer interaction.

The form has fields for quality target and latency budget. The source also maintains state for backend preference, memory limit, and monetary budget, and includes those values in submitted request objects. In the inspected JSX, those state values do not have corresponding visible controls. This creates hidden request behavior and makes the form contract harder to understand.

The V1 request path is `POST /api/compute/jobs`. The UI creates an idempotency key, expects a run ID, polls `GET /api/compute/runs/{runId}`, and refreshes history. Polling occurs every 500 ms for at most 60 seconds. If the run remains active after that window, the UI displays a message that the run is still active and retains its ID in history.

### 3.4 Capability display

The workspace fetches:

- `GET /api/compute/capabilities`
- `GET /api/compute/v2/capabilities`

It renders the currently selected capability list and backend gating reasons. The V1 capability area is a useful foundation: it can communicate that a backend is detected, allowed, gated, or unavailable.

The customer-facing version must use the backend’s canonical capability schema and distinguish at least:

- detected vs actually executable;
- configured vs not configured;
- reachable vs not reachable;
- supported vs unsupported;
- available vs busy/degraded;
- verified vs unverified.

A green “available” state must never be inferred from hardware detection alone. The UI should show the reason and the evidence timestamp/source for each relevant capability.

### 3.5 Results and receipts

The current workspace renders:

- operation status;
- actual backend;
- computed output;
- verification status and verifier ID;
- whether verification is independent;
- persistence status;
- receipt SHA-256;
- run ID;
- detailed receipt JSON;
- persisted run record JSON.

The history area includes grouping by date or operation, run counts, success percentage, duration summaries, backend, status, persistence status, receipt hash, Inspect, and Receipt download actions. It supports group receipt export and all-receipt export.

This is one of the strongest existing product foundations. The customer V1 should retain the ability to inspect exact execution provenance, but should progressively present a readable summary first and technical detail second. Raw JSON should remain available as an advanced view, not the default user experience.

### 3.6 Overview screen

`OverviewScreen.tsx` presents live product status, backend/capability state, execution history statistics, heterogeneous resource eligibility, and links into product/engineering paths.

It is useful as a technical system overview but does not yet answer the normal customer questions:

- Which projects and apps do I own?
- What work is running now?
- What needs my attention?
- Which providers/resources are connected?
- What did my recent executions produce?
- What are my usage and budget positions?
- What can I safely run right now?

The target dashboard should answer those questions directly.

### 3.7 Execution plan screen and simulations

`ExecutionPlanScreen.tsx` contains a planner/pipeline presentation with tabs for simulation, DAG specification, and cost-model concepts. It embeds `ExecutionGraphSimulation.tsx`.

`ExecutionGraphSimulation.tsx` contains hardcoded presentation values such as a default run identifier, `GPU-V100`, scheduler labels, and simulated telemetry. It includes an explicit message that execution occurred in local simulation mode. The component contains a comment acknowledging “real or simulated telemetry”.

The visual may be useful as a teaching or engineering demonstration, but it must not be presented as a real execution trace. A customer run graph must be generated from the actual persisted execution plan and stage events. A simulation must be marked `SIMULATED` in the UI, visually separated from live execution, and must not create a customer receipt or success metric.

### 3.8 Run details screen

`RunDetailsScreen.tsx` is intended to show the recorded request and output, verification evidence, and run history. This is a useful location for a complete run evidence view.

The target version should show:
- request contract and normalized workload;
- workload classification and classification evidence;
- execution graph and dependency order;
- plan and scheduling decisions;
- actual provider/model/resource/backend used;
- stage-by-stage lifecycle and timestamps;
- actual measurements and their provenance;
- output and downloadable artifacts;
- verification method, verifier identity/version, verdict and limitations;
- durable receipt, content hash and persistence state;
- retry/cancel/re-run relationships;
- warnings, failures, and remediation.

Only values actually returned by the backend may be displayed as actual measurements or evidence.

### 3.9 Benchmarks screen

`BenchmarksScreen.tsx` explicitly states that it shows reproducible benchmark records and does not generate sample timings or simulated results. It also states that no current benchmark run is connected to the screen and presents a prior adaptive-compute result with limitations.

This honesty is good. However, a customer benchmark page must distinguish:
- customer-run measurements;
- reproducible BOYKA benchmark suites;
- imported external benchmark evidence;
- simulations;
- estimated values;
- unavailable metrics.

No benchmark comparison should be shown without workload definition, hardware/software environment, warm/cold state, run count, aggregation method, verification status, source, and reproducibility metadata.

### 3.10 Engineering portal and hardware engineering screens

`EngineeringPortalScreen.tsx` draws on extensive static data catalogs covering architecture layers, technical capabilities, decisions, evidence, executive cases, failure scenarios, financing workflow, leadership matrix, canonical source intake, theories, workload traces, subsystem evaluations, and repository status.

`HardwareEngineeringScreen.tsx` includes RTL module descriptions, an interactive cache coherence simulator, MMIO controls, RTL simulation console content, and hardware readiness classifications.

`CacheCoherenceSimulation.tsx` is an interactive simulation with generated packet/state behavior. `HardwareEngineeringScreen.tsx` contains preset console messages and simulated PASS labels, while also identifying physical silicon as `NOT_MEASURED` and showing “SIMULATED / FLOW READY” and `NOT_MEASURED` states.

These screens are engineering/research material, not the primary customer V1 product. They should be:
- removed from customer navigation by default;
- placed under an internal engineering route protected by explicit role/permission;
- or retained in a separate research/engineering application.

If any content is surfaced to customers, it must be clearly categorized as documentation, a simulation, an experiment, or a measured production capability. A preset console output must never be mistaken for a fresh RTL run.

---

## 4. Critical source findings and risks

### 4.1 High-priority issue: local fallback can manufacture a successful-looking execution

`app/lib/backend.ts` contains local computation implementations for `vector_dot`, `matmul_ones`, and `dot_i16_vector`. When the upstream request throws due to connection failure or timeout, `proxyBackend()` may execute a local fallback for `POST /api/compute/jobs`.

The local fallback:
- computes the operation inside the Next.js web process;
- sets the run status to `SUCCEEDED`;
- creates a local receipt hash;
- labels execution mode `LOCAL_FALLBACK`;
- reports `LOCAL_SELF_CONSISTENCY_CHECK`, not independent verification;
- reports `independent: false`;
- reports `EPHEMERAL_IN_MEMORY` persistence;
- stores local runs in a process-local map and optionally a JSON file under `tmp/`.

This is materially different from an authoritative BOYKA V1 execution. Even if the UI displays the fallback warning, a `SUCCEEDED` status is dangerous because the shared status mapper labels `SUCCEEDED` as “Completed & Verified”. The result panel has a second verification condition, but the status headline and history success counts still treat `SUCCEEDED` as success.

The existing E2E test for a 503 response does not prove that a connection-refused or timeout path cannot use local fallback: the fallback is entered on a thrown fetch error, while a normal HTTP 503 is a returned response. The test named “unavailable execution API does not synthesize a run” stubs a 503 and checks the 503 path; it does not exercise the thrown-network-error fallback path.

**Required correction:**
- Remove local fallback from the authoritative customer V1 job path, or expose it only as a separately named local preview action with an unmistakable `LOCAL_SIMULATION`/`LOCAL_UNVERIFIED` lifecycle.
- Never map a local self-consistency result to `SUCCEEDED` or “Completed & Verified”.
- Never issue a canonical BOYKA receipt for a local preview. If a local diagnostic record is useful, label it as a local diagnostic record and keep it outside canonical execution history.
- Add E2E tests that simulate connection refused, DNS failure, timeout, upstream 5xx, malformed JSON, and partial response. Assert no authoritative run, verified output, or durable receipt is synthesized.
- Ensure history success rate counts only the canonical terminal success state and separately reports provisional/local states.

### 4.2 High-priority issue: missing authentication and tenant UX

The supplied app has no visible sign-in, account, organization, membership, role, API-key management, or workspace switcher. `proxyBackend()` forwards `authorization`, `x-boyka-tenant`, `idempotency-key`, and `x-request-id` headers if supplied by the browser, but the inspected UI does not establish how users authenticate or how a tenant is selected safely.

**Required correction:**
- Implement the chosen authentication/session model before exposing customer data.
- Resolve tenant identity server-side from the authenticated session. Do not trust a browser-supplied tenant header as the authorization boundary.
- Add organization/workspace switching, member roles, invitation flow, and session expiry handling.
- All API calls must be scoped to the authenticated tenant; the frontend must not be able to select arbitrary tenant IDs to cross data boundaries.
- Add UI for unauthorized, forbidden, expired session, and re-authentication states.
- Ensure no customer secret or provider API key is exposed in client-side logs, browser storage, rendered HTML, URLs, or telemetry.

### 4.3 High-priority issue: the current V1 UI is too narrow

The V1 UI supports two simple arithmetic operations. It does not provide the end-to-end project/application/workload lifecycle required for BOYKA V1.

Missing customer product capabilities include:
- create/manage workspace, project, and application;
- create workloads from a form, API contract, code/package, or workflow definition;
- AI, non-AI, and hybrid workload creation and classification;
- model/provider connections and BYOK credential lifecycle;
- customer-owned local/cloud resource connections;
- resource discovery and eligibility detail;
- workload analysis and explainable plan review;
- multi-step workflow creation and execution;
- result/artifact browser and retrieval;
- app deployment lifecycle;
- budgets, quotas, usage, and cost visibility;
- notifications, audit log, team access, and settings.

These should be implemented as actual customer journeys, not as static dashboard cards.

### 4.4 High-priority issue: V1 and V2 are mixed

The main V1 workspace includes V2 runtime choices, V2 hardware-aligned integer operations, and V2 graph JSON submission. The top-level navigation includes hardware engineering and presilicon work.

**Required correction:** V1 customer UI must be V1-only. Remove V2 execution selectors and V2 routes from the customer V1 navigation and execution form. If V2 is mentioned, place it in a separate roadmap/research page with explicit “not part of V1 runtime” wording.

### 4.5 High-priority issue: the API gateway contains product behavior

`app/lib/backend.ts` is not only a transparent proxy. It includes local execution logic, local history persistence, run-ID generation, receipt hashing, and fallback behavior.

This creates a second execution authority inside the web app and risks diverging from the canonical backend. The frontend gateway should be a thin, secure same-origin BFF (backend-for-frontend) that:
- validates request size and encoding;
- authenticates the user/session;
- derives tenant context;
- forwards only approved headers;
- applies timeouts and request correlation;
- normalizes errors without changing execution semantics;
- does not independently schedule, execute, verify, or create canonical receipts.

Canonical run state and receipts must come from the V1 backend.

### 4.6 Missing or incomplete route handlers

The archive contains zero-byte route files:
- `app/api/compute/runs/[runId]/cancel/route.ts`
- `app/api/compute/v2/graph/jobs/route.ts`

The UI calls the cancel endpoint, but the supplied route file is empty. The V2 graph route is also empty while the UI can submit to it. These are direct implementation gaps in the supplied archive.

Other route files proxy or validate narrow request shapes. Their presence does not prove that the upstream backend supports every customer workflow.

Additional route/gateway findings:
- `GET /api/compute/history` falls back to local history whenever the upstream response is not `ok`, not only when the upstream is unreachable. This can turn an upstream `401`, `403`, `500`, or other meaningful error into a `200` response containing a different local dataset.
- `GET /api/compute/runs/[runId]` also checks local storage after any non-success upstream response for upstream-format IDs. This can mask an upstream authorization or server error if a matching local record exists.
- `backendOrigin()` defaults to `http://127.0.0.1:8005` when `BOYKA_API_ORIGIN` is absent. In a deployed environment this can silently target loopback rather than fail fast for missing configuration.
- Local fallback records are held in a process-level map and written to a JSON file under `tmp/`. The stored record includes the original request payload. The local store shown in the source has no tenant partitioning or per-record authorization filter. This is not acceptable as a customer data store and may expose payloads to other users of the same app process or filesystem.
- The backend status route considers PostgreSQL or SQLite as durable storage, and can return `DURABLE_SQLITE` or `EPHEMERAL_ONLY`. The `BackendStatus` TypeScript union in `workspace/page.tsx` only declares `DURABLE_POSTGRESQL` or `UNAVAILABLE`. The runtime contract and frontend type are therefore not aligned.

**Required correction:** remove all local-history fallback from customer APIs; preserve upstream non-2xx status and error body; fail fast when production `BOYKA_API_ORIGIN` is missing; remove local payload persistence; and align the health schema/type with the backend's actual canonical durability states.

### 4.7 Inconsistent and incomplete frontend state handling

The main page keeps many concerns in one component: navigation, backend status, V1/V2 capabilities, form state, execution polling, history, receipt downloads, grouping, and detail-screen state.

Specific observations:
- The page is approximately 1,600 lines long and is a client component.
- `activeView` is declared but does not appear to drive the visible UI.
- `backendPreference`, `memoryLimit`, and `monetaryBudget` are included in request construction but do not have visible controls in the inspected form.
- Some capability-derived values are computed separately from the actual visible capability cards; `selectedCapability`, `selectedV2Capability`, and `activeView` should be checked for unused/dead state.
- The page's `BackendStatus` type does not include all values returned by the status route (`DURABLE_SQLITE`, `EPHEMERAL_ONLY`).
- A run can remain active after the 60-second polling cap; the app should provide a durable live status view rather than only a one-time message.
- The UI uses `history.replaceState` for tabs rather than separate page routes.
- A history row can be inspected and downloaded, but the current list is limited to 50 records and does not show a complete server-driven filter/pagination contract.
- Success-rate grouping treats every status other than `SUCCEEDED` as failed. This can misclassify queued, running, cancelled, provisional, rejected, and unverified outcomes.

**Required correction:** use a route-based application structure and domain-specific hooks/services. Derive status counts from canonical status categories rather than a binary succeeded/failed assumption.

### 4.8 Benchmark and simulation evidence boundaries

The current benchmark page is intentionally cautious, but the planner and hardware simulations contain preset or generated data.

**Required correction:** every visualization must carry an explicit evidence type:
- `LIVE_MEASURED`
- `PERSISTED_MEASURED`
- `ESTIMATED`
- `SIMULATED`
- `STATIC_DOCUMENTATION`
- `UNAVAILABLE`
- `UNKNOWN`

A graph rendered from a simulation must not share the visual status or language of a live customer execution. A model/provider/resource capability must not be displayed as available unless the backend confirms it.

### 4.9 Accessibility, responsive design, and design-system gaps

The source uses semantic labels and some ARIA attributes, and the Playwright test uses accessible role/label selectors. However, the archive does not establish complete WCAG 2.2 AA conformance.

Required validation includes:
- keyboard-only navigation and visible focus;
- correct dialog focus management;
- accessible validation summaries and inline errors;
- screen-reader announcements for job status changes;
- non-color-only status indicators;
- contrast in both themes;
- responsive tables and graph alternatives;
- reduced-motion behavior for simulations;
- touch target sizing;
- zoom/reflow at 200% and narrow mobile widths;
- semantic headings and landmark structure.

### 4.10 Build/test status is unverified

The ZIP includes `.next/dev` generated output, but this is not proof that the current source builds cleanly. The supplied Playwright E2E file covers a useful CPU calculation, receipt retrieval, reload recovery, unavailable API, history failure, and failed receipt retrieval.

The review did not run `npm run build`, `npm run lint`, `npm run typecheck`, or Playwright. The E2E test itself configures a prototype Python service and standalone Next server, which means test success depends on the surrounding repository scripts and runtime environment not included in this ZIP.

---

## 5. Target BOYKA V1 product model

The frontend must present BOYKA as a **heterogeneous compute and application execution platform**. The UI should not position V1 as an AGI product, an AGI-only workflow, or a hardware product.

### 5.1 Core customer journey

The primary user journey should be:

1. Sign in and enter an organization/workspace.
2. Create or select a project.
3. Create an application or workload.
4. Define the objective, inputs, constraints, and required outputs.
5. Classify the workload as AI, non-AI, hybrid, or unknown using backend evidence.
6. Connect or select authorized model providers and compute resources.
7. Inspect workload analysis, dependencies, capability eligibility, and the proposed execution plan.
8. Review data-sharing, provider, region, budget, and approval constraints.
9. Submit the workload.
10. Monitor stages, resource allocation, provider/model calls, and actual progress.
11. Inspect independent verification and any limitations.
12. Retrieve outputs, artifacts, logs, and canonical receipts.
13. Re-run, version, deploy, or schedule the application/workflow.
14. Review usage, budget, history, audit trail, and team access.

The customer must be able to complete the journey without BOYKA AGI, BOYKA-owned GPU hardware, Kaggle, or a specific cloud provider. A CPU/reference path remains a valid baseline for supported workloads. Optional providers and accelerators are displayed only when actually configured, reachable, supported, and authorized.

### 5.2 Workload categories

The UI must support three primary workload categories plus uncertainty:

| Category | Meaning in the product | UI behavior |
|---|---|---|
| AI | Work requires model inference, training, embedding, or another AI/model operation | Show provider/model selection, model permissions, data policy, model-specific limits |
| NON_AI | Conventional compute, data processing, simulation, optimization, or other non-model work | Show operation/workflow configuration and eligible compute resources |
| HYBRID | Workflow includes both AI and non-AI stages | Show graph with model and non-model stages, data boundaries, stage-level resource/provider choices |
| UNKNOWN | Evidence is insufficient to classify safely | Explain what is unknown; request additional contract detail or permit only a safe, explicitly approved path |

The browser must not infer classification from words like “AI”, tensor use, GPU presence, or parallelism. The backend returns classification, confidence/evidence, and any unresolved fields.

### 5.3 Resource and provider model

The customer-facing resource screen must distinguish:

- BOYKA-managed resources, if actually offered;
- customer local resources;
- customer cloud resources;
- authorized third-party infrastructure;
- model API providers;
- customer-hosted models.

The interface should show the real resource state, including `AVAILABLE`, `UNAVAILABLE`, `NOT_CONFIGURED`, `NOT_REACHABLE`, `UNSUPPORTED`, `UNVERIFIED`, `BUSY`, and `DEGRADED`, or the canonical equivalent returned by the backend.

For model providers:
- add provider connection;
- enter API credentials through a secure server-side secret flow;
- test connection without exposing the secret again;
- discover available models/capabilities where supported;
- set allowed models, regions, budgets, and data policies;
- set default provider/model at project or workload level;
- rotate/revoke credentials;
- view provider outages/rate limits;
- never silently switch provider or send customer data to another provider.

BYOK is a credential/authorization model, not a promise that one customer’s subscription credits can be pooled or resold to other tenants.

---

## 6. Recommended V1 information architecture

Use real route segments and a consistent application shell. The following is the target navigation, not a claim that these routes already exist.

### 6.1 Global shell

**Top bar**
- BOYKA logo and product name.
- Organization/workspace selector.
- Project context when inside a project.
- Global search/command launcher.
- Notifications and activity.
- Help/documentation.
- User profile, session, and sign-out.

**Primary navigation**
1. Home
2. Workspaces
3. Projects
4. Applications
5. Workloads
6. Executions
7. Resources
8. Model Providers
9. Data & Artifacts
10. Usage & Budgets
11. Team & Access
12. Settings

**Secondary navigation**
- Documentation and API keys (permission-gated).
- Audit log (admin/security roles).
- Platform status.
- Internal engineering/research only if separately authorized.

### 6.2 Route map

| Route | Purpose | Core UI |
|---|---|---|
| `/` | Product entry or authenticated dashboard redirect | Landing for signed-out users; Home for signed-in users |
| `/login` | Authentication | Sign-in, SSO if supported, recovery |
| `/onboarding` | First-run setup | Create organization/workspace, invite members, setup checklist |
| `/home` | Customer dashboard | Work summary, running jobs, attention items, usage |
| `/workspaces` | Workspace list | Create/select workspace |
| `/workspaces/[workspaceId]` | Workspace overview | Projects, members, resources, activity |
| `/projects` | Project list | Search, filters, create project |
| `/projects/[projectId]` | Project overview | App/workload summary, usage, providers, activity |
| `/projects/[projectId]/applications` | App list | Create, version, deploy, archive |
| `/applications/[appId]` | App detail | Overview, versions, workflows, deployments, runs |
| `/applications/[appId]/builder` | Application/workflow builder | Nodes, edges, contracts, configuration, validation |
| `/workloads/new` | Workload creation | Objective, category, inputs, constraints, data policy |
| `/workloads/[workloadId]` | Workload detail | Classification, analysis, graph, versions |
| `/executions` | Execution list | Status, owner, project, type, time, provider/resource |
| `/executions/[runId]` | Execution detail | Timeline, graph, logs, output, verification, receipt |
| `/resources` | Resource inventory | Local/cloud/BOYKA resource connections and state |
| `/resources/connect` | Connect resource | Guided connection and verification |
| `/providers` | Provider inventory | Model providers and connection status |
| `/providers/[providerId]` | Provider detail | Models, limits, policy, credentials status |
| `/artifacts` | Artifact browser | Search, type, owner, version, retention |
| `/artifacts/[artifactId]` | Artifact detail | Preview, metadata, checksum, provenance, download |
| `/usage` | Usage and budget | Actual usage, quotas, provider spend if supplied, budget alerts |
| `/team` | Team and roles | Members, invites, role assignments |
| `/settings` | Workspace/user settings | Preferences, notifications, policies |
| `/audit` | Audit log | Immutable activity and access events, permission-gated |
| `/status` | Platform status | API, queue, provider, storage health with timestamps |

A route may be deferred from the first customer release if the capability is not implemented. Do not expose an inert navigation item or a fake “coming soon” feature as if it were operational.

### 6.3 Role-based navigation

At minimum, plan for these product roles (exact role names must align with the backend authorization model):

- Organization owner
- Workspace admin
- Project admin
- Developer
- Operator
- Analyst/read-only
- Security/auditor

The frontend must hide or disable actions based on server-provided permissions, but the backend remains the enforcement authority. Hiding a button is not authorization.

---

## 7. Screen-by-screen target requirements

### 7.1 Home dashboard

The home page should answer “what is happening, what needs attention, and what can I do next?”

**Sections**
- Current workspace and project context.
- Create application / create workload primary actions.
- Active executions with stage/status and elapsed time.
- Recent completed/failed executions.
- Recent artifacts and outputs.
- Resource availability summary.
- Provider connection/health summary.
- Budget and usage summary.
- Alerts: failed jobs, expired credentials, quota thresholds, unavailable resources, required approvals.
- Onboarding checklist for new tenants.

**Rules**
- Every metric includes a source and period.
- Do not display a fabricated success rate or estimated spend as actual.
- Empty state must distinguish “no data yet” from “data could not be loaded”.
- A backend outage should produce an explicit degraded state, not a blank dashboard.

### 7.2 Workspace and project management

Support:
- create, rename, archive, and select workspace/project;
- project description, tags, owner, environment;
- member access and role assignments;
- project-level provider/resource defaults;
- project activity feed;
- project-level data retention and policy settings, if backend supports them.

All CRUD actions need confirmation for destructive changes, optimistic UI rollback on failure, and audit events.

### 7.3 Application management

An application is a customer-owned unit of work/product, not just an execution request.

Support:
- create app from blank template or existing workflow;
- app metadata, owner, version, tags;
- workflow graph and input/output contracts;
- development/staging/production environment references if supported;
- app version history and immutable version IDs;
- deploy, pause, resume, rollback, and archive only when backend lifecycle APIs exist;
- deployment health and last execution;
- app-specific secrets/config references (never display secret values after creation).

Do not display “deployed” merely because a deployment request was accepted. Show `REQUESTED`, `BUILDING`, `DEPLOYING`, `ACTIVE`, `DEGRADED`, `FAILED`, `PAUSED`, or canonical backend states.

### 7.4 Workload creation and builder

The workload creation wizard should collect only information necessary for the chosen workflow, and progressively reveal advanced controls.

**Step 1 — Objective**
- Name and description.
- What outcome is required?
- Input and output expectations.
- Workload category returned by backend classification (AI/NON_AI/HYBRID/UNKNOWN).

**Step 2 — Contract and data**
- Input schema or sample payload.
- File/data attachments and dataset references.
- Data classification and residency.
- Data-sharing constraints.
- Retention policy.
- Validation errors before submission.

**Step 3 — Model and provider (only when applicable)**
- Provider and model.
- Credential connection state.
- Supported operations/capabilities.
- Region, data policy, rate limit and quota.
- Maximum spend/budget if trustworthy pricing is available.
- Explicit approval for external data transfer or fallback provider.

**Step 4 — Compute resources**
- Candidate local/cloud/BOYKA resources.
- Availability, reachability, capability, memory, and constraints.
- Estimated resource requirements with uncertainty and source.
- No claim that a device can execute solely because it was detected.

**Step 5 — Execution constraints**
- Deadline/latency objective.
- Throughput objective if supported.
- Quality/correctness target.
- Memory limit.
- Monetary budget only when a trusted pricing basis exists.
- Retry policy and timeout.
- Approval requirements.

**Step 6 — Review**
- Normalized workload contract.
- Classification and evidence.
- Data flow and external provider calls.
- Proposed graph and resource plan.
- Constraints that cannot be satisfied.
- Explicit consent/approval before execution.

**Builder**
- Graph canvas with typed nodes and ports.
- Node inspector panel.
- Dependency and data-flow visualization.
- Schema validation.
- Stage-specific provider/resource choices.
- Versioned drafts and save state.
- Undo/redo and keyboard shortcuts.
- Graph accessibility alternative: ordered node/stage list and dependency table.
- Validation before execution.
- Clear distinction between draft, validated, submitted, and executed graph.

### 7.5 Workload analysis and execution plan

The plan screen should present backend-returned analysis, not calculate its own plan in the browser.

Show:
- workload family and classification evidence;
- operation/stage taxonomy;
- graph dependencies;
- estimated compute/memory/network requirements;
- resource candidates and why each is eligible or rejected;
- provider/model choice where applicable;
- constraints and conflicts;
- expected execution stages;
- fallback policy and approval gates;
- uncertainty and unavailable information.

Every number must be tagged as measured, estimated, simulated, unavailable, or unknown. The plan must not promise an optimization or savings percentage without measured comparative evidence.

### 7.6 Execution monitor

The execution monitor must support long-running jobs beyond the current 60-second polling window.

Show:
- run ID and immutable workload/app version;
- current lifecycle state;
- stage timeline with timestamps;
- stage status: queued/running/succeeded/failed/skipped/retrying/cancelled;
- actual resource/provider/model used per stage;
- logs/events with pagination;
- cancellation request and confirmed cancellation state;
- retries and parent/child run relationships;
- timeout, failure and recovery details;
- live connection state (SSE/WebSocket/polling as actually implemented);
- refresh/reconnect behavior.

The frontend must distinguish “cancel requested” from “cancelled”. It must not stop polling merely because a fixed client timeout elapsed.

### 7.7 Result, artifact, and receipt experience

The result page should separate three things:

1. **Business output:** what the workload produced.
2. **Artifacts:** downloadable files, datasets, generated code, logs, model outputs, reports, and other persisted objects.
3. **Execution evidence:** verification, provenance, measurements, and canonical receipt.

Each artifact should include:
- artifact ID and type;
- name and media type;
- size;
- creation time;
- version;
- checksum;
- owner/tenant/project;
- retention and expiry;
- source run/stage;
- access/download state.

A download action must fetch the real artifact from the authorized backend. It must never create a placeholder file after an API failure.

Receipt detail should show:
- receipt ID/hash;
- run ID;
- canonical status;
- request/workload contract digest;
- source revision and execution environment where supplied;
- actual backend/provider/model;
- verification result and verifier identity/version;
- persistence durability;
- measured metrics and provenance;
- limitations and missing evidence.

### 7.8 Resources

Resource inventory should show:
- resource identity and owner;
- resource class (CPU/GPU/FPGA/ASIC/DPU/IPU/NPU or other supported class);
- provider/location/region;
- connection state;
- detected state vs executable state;
- capability support;
- capacity and currently available capacity only if measured/reported;
- memory and architecture where supplied;
- last successful health check;
- permission/credential expiry;
- reason for unavailable/gated state.

Actions:
- connect;
- test connection;
- refresh discovery;
- set policy/labels;
- disconnect;
- view executions using resource.

A failed resource connection should not block unrelated CPU or other configured resource paths.

### 7.9 Model providers

Provider screen should support:
- add provider connection;
- server-side secret creation/update/rotation/revocation;
- test connection;
- model discovery where provider supports it;
- model capability and context information only when returned by trusted provider metadata;
- provider-specific quotas and rate limits;
- allowed model list;
- data-sharing and region policy;
- provider health and last test;
- usage by provider/model where actual data exists.

Do not hardcode speculative model catalogs, capability flags, context windows, or prices into the customer UI. Provider metadata must be sourced from the backend/provider adapter and carry retrieval time.

### 7.10 Usage and budgets

Show only trustworthy usage:
- executed request count;
- CPU/GPU or other resource time when measured;
- token usage when returned by provider;
- storage and data transfer when measured;
- provider charges only when actual billing data or documented pricing basis exists;
- configured budgets and remaining limits;
- quota and rate-limit events.

Separate:
- measured usage;
- provider-reported usage;
- estimated cost;
- configured budget;
- unavailable billing data.

Do not turn an estimated cost into an invoice or imply that BOYKA has provider billing integration unless implemented.

### 7.11 Team, settings, audit, and notifications

Include:
- members, invites, role changes;
- API keys/service credentials with one-time secret display;
- notification preferences;
- workspace policies;
- session and device management if supported;
- audit log for security-sensitive actions;
- alert routing and notification history.

Sensitive operations require confirmation and an auditable backend response.

---

## 8. UX states and truthful status model

Every important screen must design all states before implementation.

### 8.1 Required page states

- Initial loading.
- Refreshing existing data.
- Empty (confirmed no records).
- Unavailable (service could not be reached).
- Unauthorized.
- Forbidden.
- Validation error.
- Partial data.
- Stale data with last-updated timestamp.
- Degraded mode.
- In-progress operation.
- Success with backend-confirmed result.
- Failure with actionable error and correlation ID.
- Offline/reconnecting.
- Rate-limited with retry-after when supplied.

Never render an empty state when the API request failed. The current history E2E test already encodes this important rule and it should be applied across all data views.

### 8.2 Canonical execution status

The UI must use a typed status map from shared contracts. Do not collapse all statuses into “success” or “failure”.

Suggested presentation categories (align exact values with the backend):
- Draft
- Validating
- Accepted
- Queued
- Running
- Retrying
- Succeeded
- Partially succeeded
- Verification failed
- Unverified/provisional
- Rejected
- Failed
- Cancel requested
- Cancelled
- Timed out
- Interrupted
- Unknown status

`SUCCEEDED` must not automatically mean “verified” unless the backend contract guarantees that relationship. Display execution status and verification status as separate dimensions.

### 8.3 Verification status

Render verification independently from execution:
- `VERIFIED`
- `PARTIALLY_VERIFIED`
- `UNVERIFIED`
- `CONTRADICTED`
- `REJECTED`
- `INSUFFICIENT_EVIDENCE`
- `HUMAN_REVIEW_REQUIRED`

Show verifier identity, method, version, evidence, and limitations where available. A successful execution can still be unverified. A failed verification must not be styled as a successful verified run.

### 8.4 Measurement provenance

Every metric must have a provenance class:
- `MEASURED`
- `ESTIMATED`
- `SIMULATED`
- `UNAVAILABLE`
- `UNKNOWN`

Show units, measurement interval, source, timestamp, and aggregation method. Never infer exact power, cost, latency, utilization, or savings from absent fields.

---

## 9. Frontend architecture to implement

### 9.1 Architectural boundaries

Recommended layers:

1. **App Router pages/layouts** — route composition, metadata, access boundaries.
2. **Feature modules** — workspaces, projects, applications, workloads, executions, resources, providers, artifacts, usage, team, settings.
3. **Design system** — buttons, inputs, forms, cards, tables, dialogs, menus, tabs, badges, empty states, skeletons, alerts, charts, graph primitives.
4. **Domain hooks** — query/mutation state for each domain.
5. **API client** — typed requests, auth/session, correlation IDs, error normalization, retry policy.
6. **Shared contracts** — generated or imported API schemas and enum/status types.
7. **Telemetry** — frontend errors, performance, interaction events, with secrets and payload data redacted.

Suggested source structure:

```text
app/
  (public)/
    page.tsx
    login/
    legal/
  (authenticated)/
    layout.tsx
    home/
    workspaces/
    projects/
    applications/
    workloads/
    executions/
    resources/
    providers/
    artifacts/
    usage/
    team/
    settings/
    audit/
  api/
    ...thin same-origin BFF routes only...
components/
  ui/
  shell/
  forms/
  tables/
  charts/
  execution-graph/
features/
  auth/
  workspaces/
  projects/
  applications/
  workloads/
  executions/
  resources/
  providers/
  artifacts/
  usage/
  team/
  audit/
lib/
  api/
  auth/
  errors/
  formatting/
  permissions/
  telemetry/
contracts/
```

This is a recommended target structure. It does not need to be implemented as a single large refactor; migrate feature by feature while preserving working behavior.

### 9.2 Data fetching and state

Use a consistent server-state approach (the existing shared API client may be used if it is mature and correctly typed). Avoid duplicating `fetch`, status parsing, and retry logic in every page.

Requirements:
- typed request/response contracts;
- cancellation of stale requests;
- cache invalidation after mutations;
- deduplicated concurrent requests;
- server-driven pagination/filtering/sorting;
- explicit stale-data state;
- retry only for safe/idempotent operations;
- idempotency key for create/submit mutations;
- request/correlation ID surfaced in errors;
- no client-generated canonical state;
- no secrets in browser persistence.

Long-running execution should use server events or WebSocket only if implemented and authorized; otherwise use bounded polling with backoff, jitter, reconnect, and server-side cursor/version support. The run must remain retrievable after a browser refresh.

### 9.3 API client and BFF rules

The browser should call same-origin endpoints. The BFF must:
- authenticate the session;
- resolve tenant and permissions server-side;
- validate path and body size;
- use strict allowlisted upstream origins;
- forward only approved headers;
- set request correlation and idempotency headers;
- apply timeouts and bounded retries only where safe;
- preserve upstream HTTP status and canonical error codes;
- redact secrets and sensitive values;
- avoid logging raw payloads by default;
- never execute workloads or create canonical receipts itself.

Remove local execution from `app/lib/backend.ts` customer paths. Keep only transport, session, validation, and error translation.

### 9.4 Contracts and API versioning

Use `@boyka/contracts` / `@boyka/api-client` consistently if those packages contain the canonical schemas. Do not create parallel local type definitions that drift from backend schemas.

The frontend must have documented contracts for:
- auth/session and organization context;
- workspace/project/app CRUD;
- workload contract and classification;
- graph/plan;
- resources and provider connections;
- execution submission/status/events/cancel;
- results/artifacts;
- receipts and verification;
- usage/budgets;
- team/roles;
- audit log.

Unknown enum values must render safely as “Unknown/unsupported status” and must not crash the page.

---

## 10. Visual design system and interaction standards

### 10.1 Design direction

The current interface uses a dense technical-console style: compact text, bordered cards, tables, monospace values, slate backgrounds, blue action accents, and many engineering labels.

Retain the precision and evidence-oriented character, but make the customer product calmer and more task-oriented:
- clear page title and one-sentence purpose;
- one primary action per page;
- consistent navigation and breadcrumbs;
- readable hierarchy and spacing;
- compact technical detail only where needed;
- advanced JSON/receipt/trace data behind expandable panels;
- clear distinction between configuration, live status, and historical evidence.

Avoid turning every screen into a dashboard of cards. Use tables for inventories/history, forms for configuration, graph canvas for workflow structure, and timeline for execution.

### 10.2 Component standards

Build reusable components with consistent behavior:
- `AppShell`, `TopBar`, `Sidebar`, `Breadcrumbs`
- `PageHeader`, `PageActions`
- `StatusBadge`, `EvidenceBadge`, `ProviderBadge`, `ResourceState`
- `EmptyState`, `ErrorState`, `UnavailableState`, `StaleDataNotice`
- `FormField`, `SchemaEditor`, `ValidationSummary`
- `DataTable`, `FilterBar`, `Pagination`
- `ConfirmDialog`, `Drawer`, `Toast`, `InlineAlert`
- `ExecutionTimeline`, `ExecutionGraph`, `StageCard`
- `ArtifactTable`, `ReceiptViewer`, `LogViewer`
- `MetricWithProvenance`, `UsageBreakdown`
- `PermissionGate` (presentation only; backend still enforces access)

### 10.3 Responsive behavior

- Desktop: persistent navigation, multi-panel workload builder, full tables/graph.
- Tablet: collapsible navigation, stacked inspector panels, horizontally scrollable graph with accessible list fallback.
- Mobile: single-column forms, simplified run timeline, card-based table rows, fixed primary action where appropriate.
- Do not hide critical warnings or verification evidence on small screens.
- Provide a non-visual alternative to graph-only workflows.

### 10.4 Accessibility

Target WCAG 2.2 AA:
- semantic landmarks and headings;
- keyboard-operable navigation and graph controls;
- visible focus;
- correct labels and descriptions;
- field-level errors plus summary;
- screen-reader status announcements;
- non-color status encoding;
- contrast checks;
- reduced motion;
- accessible tables and chart summaries;
- focus trapping/restoration in dialogs;
- zoom and reflow testing.

### 10.5 Localization and formatting

Use locale-aware formatting for dates, numbers, durations, bytes, and currency. Do not hardcode USD as the only possible billing currency. Preserve canonical values in raw evidence views while showing localized presentation in normal UI. Time zone should be explicit in timestamps and user settings.

---

## 11. Security and privacy requirements

The frontend and BFF are part of the security boundary, but the backend remains authoritative.

Required controls:
- authenticated session and CSRF protection appropriate to the auth model;
- tenant context resolved from server-side identity;
- server-side authorization on every data/mutation request;
- secure, HttpOnly, SameSite session cookies where applicable;
- strict content security policy and security headers;
- output encoding and safe rendering of logs/markdown/HTML;
- upload type/size limits and safe download headers;
- no secrets in localStorage/sessionStorage, URLs, client logs, or error reports;
- no provider credential re-display after creation;
- signed/authorized artifact downloads;
- audit logging for provider, resource, user, role, secret, deployment, and execution actions;
- rate limiting and abuse controls at the backend;
- request size and timeout limits;
- safe error messages without stack traces or secret-bearing upstream bodies.

The existing BFF forwards an incoming `x-boyka-tenant` header. This must not be treated as trusted tenant authorization. Derive tenant membership from the authenticated server-side session and ignore or strictly validate any client-provided tenant selector.

The BFF must not accept arbitrary upstream origins from a request. `BOYKA_API_ORIGIN` should be server-only configuration validated at startup and restricted by deployment policy.

---

## 12. Testing strategy and acceptance criteria

### 12.1 Test layers

1. Unit tests for components, formatters, status mapping, permissions, schema validation, and error normalization.
2. API-client tests for authentication, tenant context, idempotency, timeouts, retry behavior, and error preservation.
3. Component tests for loading/empty/error/partial/stale/unauthorized states.
4. Playwright E2E for full customer journeys.
5. Accessibility tests (automated plus keyboard/manual checks).
6. Security tests for tenant isolation, secret redaction, unsafe rendering, upload/download, and session boundaries.
7. Visual regression tests for desktop/tablet/mobile.
8. Production build, typecheck, lint, and deployment smoke tests.

### 12.2 Minimum E2E journeys

**A. First-time onboarding**
- signed-out user cannot access private project data;
- sign-in and organization creation;
- create workspace and project;
- onboarding checklist reflects persisted state after reload.

**B. Non-AI workload**
- create non-AI workload;
- backend classifies it with evidence;
- review plan and resource eligibility;
- execute on an available supported path;
- retrieve output and canonical receipt;
- reopen after browser reload.

**C. BYOK model workload**
- connect provider secret securely;
- test connection;
- choose an actually available model;
- submit a workload;
- show actual provider/model returned by backend;
- enforce budget, region, data policy and no silent provider fallback.

**D. Hybrid workload**
- graph contains AI and non-AI stages;
- data movement and provider boundaries are visible;
- stage-level status and output can be inspected;
- one stage failure is shown accurately.

**E. Resource unavailable**
- unavailable GPU/cloud/provider is shown as unavailable/not configured/not reachable;
- customer can use an authorized alternative if policy permits;
- otherwise explain why execution cannot proceed;
- never synthesize an execution.

**F. Long-running execution**
- job remains visible after 60 seconds;
- browser reload reconnects to persisted run;
- cancellation request and final cancellation state are distinct;
- reconnect/polling does not create duplicate jobs.

**G. Artifact retrieval**
- list, preview, and download actual stored artifacts;
- checksum and metadata are displayed;
- failed download produces no placeholder file.

**H. Tenant isolation**
- one tenant cannot list, inspect, cancel, download, or infer another tenant’s runs, artifacts, providers, or resources;
- UI cannot override the authenticated tenant context.

**I. Failure and degraded states**
- connection refused, timeout, 5xx, malformed response, auth expiry, forbidden, quota exceeded, provider rate limit, and storage unavailable;
- each is distinguishable from an empty dataset;
- no false success, receipt, benchmark, or measurement.

**J. Application lifecycle**
- create app, save version, validate, deploy, inspect actual deployment state, rollback/pause where supported;
- reload preserves the authoritative state.

### 12.3 Acceptance gates

A feature is not complete merely because its page renders. It must pass:

- **Contract gate:** API schema and error behavior are documented and typed.
- **Persistence gate:** state survives browser reload and backend restart where the product promises durability.
- **Authorization gate:** tenant/role tests pass.
- **Truthfulness gate:** no fake success, resource availability, measurement, or verification.
- **Failure gate:** unavailable dependencies produce clear non-success states.
- **Accessibility gate:** keyboard and screen-reader workflows work.
- **Responsive gate:** mobile/tablet/desktop are usable.
- **Operational gate:** telemetry, correlation IDs, and support diagnostics exist.

---

## 13. Prioritized implementation roadmap

### P0 — Correctness and trust (do first)

1. Remove/disable local fallback from canonical V1 execution.
2. Fix status semantics so `SUCCEEDED` is not equated with independent verification.
3. Add network-failure tests for connection refused and timeout, not just HTTP 503.
4. Implement or remove the zero-byte cancel route; do not show a working cancel action until supported.
5. Remove V2 runtime/graph options from V1 customer UI.
6. Remove or isolate simulated execution/hardware screens from customer navigation.
7. Establish authenticated session and server-derived tenant context.
8. Ensure history statistics handle all canonical statuses correctly.
9. Ensure failed history/artifact/receipt requests never render as empty or generate placeholders.

**Exit gate:** no false successful run, no cross-tenant access, and no UI claim of verification/persistence without backend evidence.

### P1 — Core customer workspace

1. Add authenticated application shell and workspace/project selection.
2. Implement Home, Projects, Applications, Workloads, Executions.
3. Build typed API client and shared error/status components.
4. Preserve run submission, monitoring, history, run details, and receipts as feature modules.
5. Add server-driven pagination, filtering, and search.
6. Add workload contract editor and backend-returned classification/analysis.
7. Add accessible execution graph and stage timeline.

**Exit gate:** a customer can create a project/workload, execute an allowed workload, and retrieve the real persisted result and receipt.

### P2 — Providers and resources

1. Provider connection lifecycle and secure secret handling.
2. Model discovery and capability metadata from provider/backend.
3. Customer local/cloud resource connection lifecycle.
4. Resource health, eligibility and failure reasons.
5. Provider/model/resource policies and approvals.
6. AI, non-AI, and hybrid end-to-end experiences.

**Exit gate:** customer can use an authorized provider/resource; unsupported or unavailable infrastructure is reported honestly and does not block unrelated valid paths.

### P3 — Applications and operations

1. Application builder and versioned workflows.
2. Deployment lifecycle, environments and rollback where backend supports it.
3. Artifacts browser and durable downloads.
4. Usage, budgets, quotas and provider usage.
5. Team, roles, audit log and notifications.

**Exit gate:** a customer can build/manage an application, deploy only where supported, inspect real usage, and audit sensitive changes.

### P4 — Product hardening

1. Full accessibility and responsive review.
2. Performance optimization and bundle splitting.
3. Visual regression and browser coverage.
4. Security review and penetration testing.
5. Production telemetry, error budgets, and support diagnostics.
6. Documentation, onboarding, and customer support workflows.

**Exit gate:** all critical journeys pass in a production-like environment with real configured services and no unresolved critical security or truthfulness defects.

---

## 14. Specific changes to the supplied source

This section maps the audit to the current archive.

| Current file | Keep / change | Required action |
|---|---|---|
| `app/page.tsx` | Change | Redirect signed-in users to `/home`; signed-out users to a real public entry/login flow |
| `app/layout.tsx` | Change | Update metadata to customer V1 product; add app shell providers, fonts/theme, security/accessibility structure |
| `app/globals.css` | Refactor | Introduce design tokens and reusable component styling; preserve light/dark support |
| `app/workspace/page.tsx` | Split | Break into route-level pages and feature modules; remove V2 paths and unrelated engineering state |
| `app/lib/backend.ts` | Critical refactor | Remove local execution/receipt/history authority; retain thin authenticated BFF proxy and request validation |
| `app/api/backend-status/route.ts` | Refine | Return structured health with freshness and component status; avoid treating a single capability as full platform health |
| `app/api/compute/jobs/route.ts` | Keep/refine | Validate against shared contract and proxy to canonical backend |
| `app/api/compute/history/route.ts` | Refine | No local fallback; server-side pagination/filtering; preserve upstream error semantics |
| `app/api/compute/runs/[runId]/route.ts` | Keep/refine | Strict authorization and canonical response; no local fallback |
| `app/api/compute/runs/[runId]/cancel/route.ts` | Implement or remove | File is empty in the archive although UI calls it |
| `app/api/compute/v2/graph/jobs/route.ts` | Remove from V1 or implement separately | File is empty and belongs outside the V1 customer runtime |
| `OverviewScreen.tsx` | Rework | Customer dashboard, not engineering/system-only overview |
| `ExecutionPlanScreen.tsx` | Rework | Render real backend analysis and plan; simulation only in a separate labelled sandbox |
| `ExecutionGraphSimulation.tsx` | Isolate | Keep as a clearly labelled simulator or replace with actual persisted graph events |
| `RunDetailsScreen.tsx` | Keep/refine | Expand to full workload/run/artifact/verification/receipt evidence |
| `BenchmarksScreen.tsx` | Keep/refine | Separate reproducible benchmark records from estimates and imported evidence |
| `EngineeringPortalScreen.tsx` | Move | Internal engineering/research route with role-based access |
| `HardwareEngineeringScreen.tsx` | Move | Internal V2/presilicon route; not part of customer V1 |
| `CacheCoherenceSimulation.tsx` | Move | Label as simulation; do not present as actual customer resource telemetry |
| `app/data/*` catalogs | Reclassify | Internal research/evidence data; do not mix with live customer product state |
| `e2e/compute-workspace.spec.ts` | Expand | Add real-network-failure, auth, tenant, long-running, provider, hybrid, artifact, app lifecycle and accessibility journeys |

---

## 15. API contract map required by the target frontend

The current archive visibly proxies a subset of compute endpoints. The target frontend requires documented backend contracts for the following domains. Exact endpoint paths should be finalized with the backend team; these are domain requirements, not assertions that the routes currently exist.

| Domain | Required operations |
|---|---|
| Auth/session | sign in/out, session, refresh, current user, organization membership |
| Workspaces | list, create, read, update, archive, switch context |
| Projects | list, create, read, update, archive |
| Applications | list, create, read, update, version, validate, deploy, pause, resume, rollback |
| Workloads | create, validate, classify, analyze, read, version |
| Graphs/plans | create/update draft, validate graph, analyze, retrieve plan |
| Providers | list, connect, test, discover models, update policy, rotate/revoke secret, disconnect |
| Resources | list, discover, connect, test, inspect, update policy, disconnect |
| Executions | submit, list, get, cancel, retry, stream/poll events |
| Results | retrieve output, stage output, logs, execution trace |
| Artifacts | list, metadata, preview, download, checksum, retention |
| Receipts | retrieve canonical receipt, verify hash/provenance, export |
| Usage | usage summary, detailed usage, quotas, budget settings, alerts |
| Team | list members, invite, change role, revoke |
| Audit | list/filter/export audit events |
| Status | platform health, service health, provider/resource status |

All endpoints must have:
- versioned schemas;
- documented authorization and tenant scope;
- stable error codes;
- pagination/filtering conventions;
- idempotency rules for mutations;
- request/correlation IDs;
- timestamps and freshness semantics;
- explicit state enums;
- no ambiguous null/empty/unavailable behavior.

---

## 16. Definition of “V1 frontend complete”

The frontend is complete only when a real customer can:

1. Sign in and operate inside an authorized tenant/workspace.
2. Create and manage a project and application.
3. Create a non-AI workload and an AI workload using an authorized model provider.
4. Create or inspect a hybrid workflow containing both AI and non-AI stages.
5. Connect a customer resource/provider securely, or see exactly why it is unavailable.
6. Inspect workload classification, constraints, resource eligibility, and execution plan.
7. Submit an execution and monitor its true lifecycle beyond a short page polling window.
8. Retrieve the actual output and stored artifacts.
9. Inspect independent verification separately from execution success.
10. Retrieve the canonical durable receipt and verify its identity/hash.
11. Reopen the run and artifacts after browser reload and backend restart where durability is promised.
12. View usage and budgets without fabricated prices or measurements.
13. Manage team permissions and audit sensitive actions.
14. Experience correct loading, empty, unavailable, partial, forbidden, failed, and degraded states.
15. Complete the core journeys with keyboard navigation and on mobile/tablet/desktop.

No feature is accepted solely because:
- a page exists;
- a component renders;
- a simulation animates;
- a local mock returns a result;
- an API returns HTTP 200 without the expected durable business state;
- a test passes only against a stub;
- a metric is estimated but presented as measured.

---

## 17. Immediate next actions

The most efficient next sequence is:

1. **P0 trust correction:** remove the local fallback from the canonical job endpoint and add tests for connection-refused/timeouts. This is the most serious source-level correctness risk.
2. **Scope correction:** separate V1 customer UI from V2 and internal engineering/hardware material.
3. **Contract alignment:** inspect the canonical backend OpenAPI/contracts and map each existing screen to actual API responses. Do not invent endpoints or response fields.
4. **Authentication/tenant model:** settle the session and tenant authorization contract before building project, provider, and artifact screens.
5. **Core customer journey:** implement authenticated workspace → project → workload → plan → execute → monitor → result/artifact/receipt.
6. **Expand only after that journey is real:** providers/resources, hybrid workflows, application deployment, usage, team, audit.

Do not start by adding more dashboard cards or decorative simulations. First make the customer journey correct, durable, secure, and observable.

---

## 18. Limitations of this audit

- The supplied ZIP contains frontend source and generated Next.js development output, not the complete BOYKA backend source, database schema, or authoritative OpenAPI document.
- The review therefore cannot prove that upstream API endpoints, response fields, authorization, persistence, or provider/resource operations work.
- No live backend or provider was contacted.
- No API key or customer secret was used.
- No npm install/build/lint/typecheck/Playwright command was run as part of this source review.
- Some component content is static data or simulation. This document identifies visible examples but does not claim every static record is false; each must be checked against its source and evidence classification before customer publication.
- The recommended route map, UX, and architecture are target requirements for BOYKA V1, not existing implementation.

**Final assessment:** The archive is a useful technical workspace prototype with valuable execution-history and evidence-oriented UI foundations. It is not yet a complete BOYKA V1 customer frontend. The immediate priority is to eliminate false-success paths and separate the actual V1 product journey from V2 and internal engineering demonstrations; then build the authenticated project/application/workload lifecycle around the authoritative backend.
