globalThis.__BUILD_MANIFEST = {
  "polyfillFiles": [
    "static/chunks/polyfills.js"
  ],
  "devFiles": [
    "static/chunks/fallback/react-refresh.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/fallback/webpack.js",
    "static/chunks/fallback/main-app.js"
  ],
  "rootMainFilesTree": {},
  "pages": {
    "/_app": [
      "static/chunks/fallback/webpack.js",
      "static/chunks/fallback/main.js",
      "static/chunks/fallback/pages/_app.js"
    ],
    "/_error": [
      "static/chunks/fallback/webpack.js",
      "static/chunks/fallback/main.js",
      "static/chunks/fallback/pages/_error.js"
    ]
  }
};
