import { cpSync, existsSync, mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { defineConfig, devices } from '@playwright/test';

const appRoot = resolve(__dirname);
const repoRoot = resolve(appRoot, '../..');
const localPython = join(repoRoot, '.venv', 'Scripts', 'python.exe');
const python = existsSync(localPython) ? `"${localPython}"` : (process.env.PYTHON ?? 'python3');
const standaloneRoot = join(appRoot, '.next', 'standalone', 'apps', 'web');
const standaloneServer = join(standaloneRoot, 'server.js');
const standaloneStatic = join(standaloneRoot, '.next', 'static');
const builtStatic = join(appRoot, '.next', 'static');
if (existsSync(standaloneServer) && existsSync(builtStatic)) {
  mkdirSync(standaloneStatic, { recursive: true });
  cpSync(builtStatic, standaloneStatic, { recursive: true, force: true });
  const publicDir = join(appRoot, 'public');
  if (existsSync(publicDir)) cpSync(publicDir, join(standaloneRoot, 'public'), { recursive: true, force: true });
}
const serviceData = process.env.BOYKA_PLAYWRIGHT_DATA
  ? resolve(repoRoot, process.env.BOYKA_PLAYWRIGHT_DATA)
  : join(repoRoot, 'build', `playwright-service-data-${process.pid}`);

export default defineConfig({
  testDir: './e2e',
  fullyParallel: false,
  forbidOnly: Boolean(process.env.CI),
  retries: 0,
  reporter: 'list',
  use: {
    baseURL: 'http://127.0.0.1:43281',
    trace: 'retain-on-failure',
    launchOptions: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
      ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH }
      : undefined,
    ...devices['Desktop Chrome'],
  },
  webServer: [
    {
      command: `${python} scripts/serve_prototype.py`,
      cwd: repoRoot,
      url: 'http://127.0.0.1:43280/api/health',
      reuseExistingServer: false,
      timeout: 60_000,
      env: {
        BOYKA_DATA: serviceData,
        BOYKA_SERVICE_DATA: serviceData,
        BOYKA_HOST: '127.0.0.1',
        BOYKA_E2E_API_PORT: '43280',
      },
    },
    {
      command: `node "${standaloneServer}"`,
      cwd: appRoot,
      url: 'http://127.0.0.1:43281/workspace',
      reuseExistingServer: false,
      timeout: 60_000,
      env: { BOYKA_API_ORIGIN: 'http://127.0.0.1:43280', NODE_ENV: 'production', PORT: '43281', HOSTNAME: '127.0.0.1' },
    },
  ],
});
