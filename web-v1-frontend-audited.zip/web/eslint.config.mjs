export default [
  {
    ignores: ['.next/**', 'node_modules/**', 'dist/**', 'build/**', '.turbo/**'],
  },
];
